-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2021 at 09:17 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `knowledgeseek`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_data`
--

CREATE TABLE `admin_data` (
  `id` int(255) NOT NULL,
  `username` varchar(1000) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `token` varchar(255) NOT NULL,
  `status` int(6) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_data`
--

INSERT INTO `admin_data` (`id`, `username`, `email`, `password`, `token`, `status`, `created_at`, `updated_at`) VALUES
(1, 'knowledgeseek', 'knowledgeseek21@gmail.com', '$2y$10$wq0DXO.6SYMoDewhzaK6u.0BvZQ4GVgGWYm8mbF64fZ.HA9ZoRN3G', 'b102e7e26da695ee450783865f8ec554', 0, '2021-05-11 12:44:01.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(255) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `category_id` int(255) NOT NULL,
  `title` varchar(500) NOT NULL,
  `discription` longtext NOT NULL,
  `author` varchar(1000) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `image`, `category_id`, `title`, `discription`, `author`, `status`, `created_at`, `updated_at`) VALUES
(3, '10d0ffcad4b68c8a42b2194d43de24ad.jpg', 1, 'titltr rrrrr r rhffhfh  hfhfhj jfjjfjfgjfjfrurff ry rfffgjj j fjsdfjsfsfj h', '<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia,<br />\r\nmolestiae quas vel sint commodi repudiandae consequuntur voluptatum laborum<br />\r\nnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium<br />\r\noptio, eaque rerum! Provident similique accusantium nemo autem. Veritatis<br />\r\nobcaecati tenetur iure eius earum ut molestias architecto voluptate aliquam<br />\r\nnihil, eveniet aliquid culpa officia aut! Impedit sit sunt quaerat, odit,<br />\r\ntenetur error, harum nesciunt ipsum debitis quas aliquid. Reprehenderit,<br />\r\nquia. Quo neque error repudiandae fuga? Ipsa laudantium molestias eos&nbsp;<br />\r\nsapiente officiis modi at sunt excepturi expedita sint? Sed quibusdam<br />\r\nrecusandae alias error harum maxime adipisci amet laborum. Perspiciatis&nbsp;<br />\r\nminima nesciunt dolorem! Officiis iure rerum voluptates a cumque velit&nbsp;<br />\r\nquibusdam sed amet tempora. Sit laborum ab, eius fugit doloribus tenetur&nbsp;<br />\r\nfugiat, temporibus enim commodi iusto libero magni deleniti quod quam&nbsp;<br />\r\nconsequuntur! Commodi minima excepturi repudiandae velit hic maxime<br />\r\ndoloremque. Quaerat provident commodi consectetur veniam similique ad&nbsp;<br />\r\nearum omnis ipsum saepe, voluptas, hic voluptates pariatur est explicabo&nbsp;<br />\r\nfugiat, dolorum eligendi quam cupiditate excepturi mollitia maiores labore&nbsp;<br />\r\nsuscipit quas? Nulla, placeat. Voluptatem quaerat non architecto ab laudantium<br />\r\nmodi minima sunt esse temporibus sint culpa, recusandae aliquam numquam&nbsp;<br />\r\ntotam ratione voluptas quod exercitationem fuga. Possimus quis earum veniam&nbsp;<br />\r\nquasi aliquam eligendi, placeat qui corporis!</p>', 'sasda', 1, '2012-10-21 20:53:30.000000', '2014-10-21 06:42:37.000000'),
(4, '1a89d0568fe9d36b26b346b85448b714.jpg', 1, 'csssdfs', '<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia,<br />\r\nmolestiae quas vel sint commodi repudiandae consequuntur voluptatum laborum<br />\r\nnumquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium<br />\r\noptio, eaque rerum! Provident similique accusantium nemo autem. Veritatis<br />\r\nobcaecati tenetur iure eius earum ut molestias architecto voluptate aliquam<br />\r\nnihil, eveniet aliquid culpa officia aut! Impedit sit sunt quaerat, odit,<br />\r\ntenetur error, harum nesciunt ipsum debitis quas aliquid. Reprehenderit,<br />\r\nquia. Quo neque error repudiandae fuga? Ipsa laudantium molestias eos&nbsp;<br />\r\nsapiente officiis modi at sunt excepturi expedita sint? Sed quibusdam<br />\r\nrecusandae alias error harum maxime adipisci amet laborum. Perspiciatis&nbsp;<br />\r\nminima nesciunt dolorem! Officiis iure rerum voluptates a cumque velit&nbsp;<br />\r\nquibusdam sed amet tempora. Sit laborum ab, eius fugit doloribus tenetur&nbsp;<br />\r\nfugiat, temporibus enim commodi iusto libero magni deleniti quod quam&nbsp;<br />\r\nconsequuntur! Commodi minima excepturi repudiandae velit hic maxime<br />\r\ndoloremque. Quaerat provident commodi consectetur veniam similique ad&nbsp;<br />\r\nearum omnis ipsum saepe, voluptas, hic voluptates pariatur est explicabo&nbsp;<br />\r\nfugiat, dolorum eligendi quam cupiditate excepturi mollitia maiores labore&nbsp;<br />\r\nsuscipit quas? Nulla, placeat. Voluptatem quaerat non architecto ab laudantium<br />\r\nmodi minima sunt esse temporibus sint culpa, recusandae aliquam numquam&nbsp;<br />\r\ntotam ratione voluptas quod exercitationem fuga. Possimus quis earum veniam&nbsp;<br />\r\nquasi aliquam eligendi, placeat qui corporis!</p>\r\n\r\n<p>&nbsp;</p>', 'eeeeeeee', 1, '2014-10-21 06:32:50.000000', '2014-10-21 06:42:46.000000');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `author` varchar(1000) NOT NULL,
  `subject_id` int(255) NOT NULL,
  `book` mediumtext NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `id` int(255) NOT NULL,
  `programe_id` int(255) NOT NULL,
  `branch_name` varchar(5000) NOT NULL,
  `yearorsem_id` int(255) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `programe_id`, `branch_name`, `yearorsem_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Computer Science [CSE]', 2, 1, '2021-08-20 12:03:20.000000', '0000-00-00 00:00:00.000000'),
(2, 1, 'Information Technology [IT]', 2, 1, '2021-08-20 12:04:45.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'aman', 1, '2010-10-21 07:40:16.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `email` varchar(255) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `article_id` int(255) NOT NULL,
  `commented_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `name`, `email`, `comment`, `article_id`, `commented_at`) VALUES
(5, 'himashu', 'asdadasd@gmail.com', 'dasd', 3, '2014-10-21 06:47:03.000000');

-- --------------------------------------------------------

--
-- Table structure for table `comment_reply`
--

CREATE TABLE `comment_reply` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `reply` varchar(255) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `replied_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment_reply`
--

INSERT INTO `comment_reply` (`id`, `name`, `email`, `reply`, `comment_id`, `article_id`, `replied_at`) VALUES
(10, 'cdscsd', 'csdcs@gmail.com', 'cscsc', 4, 3, '2027-10-21 13:46:26.000000'),
(12, 'yo', 'yo@gmil.com', 'yo', 5, 3, '2027-10-21 13:54:08.000000'),
(13, 'n', 'aman21@gmail.com', 'ahhhahhhahahah', 5, 3, '2027-10-21 20:24:04.000000');

-- --------------------------------------------------------

--
-- Table structure for table `contact_data`
--

CREATE TABLE `contact_data` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `message` varchar(5000) NOT NULL,
  `status` int(6) NOT NULL DEFAULT 0,
  `created_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_data`
--

INSERT INTO `contact_data` (`id`, `name`, `email`, `message`, `status`, `created_at`) VALUES
(1, 'aman', 'aman@gmail.com', 'hello', 0, '0000-00-00 00:00:00.000000'),
(2, 'aman pandagre', 'idraksheikh333@gmail.com', 'nnccab', 0, '0000-00-00 00:00:00.000000'),
(3, 'aman', 'aman@gmail.com', 'Cac', 0, '2014-05-21 11:53:13.000000'),
(4, 'aman pandagre', 'aman@gmail.com', 'c', 0, '2014-05-21 11:53:51.000000'),
(5, 'aman pandagre', 'idraksheikh333@gmail.com', 'bdbdb', 0, '2014-05-21 11:55:14.000000'),
(7, 'kapil prajapati', 'kapil@gmail.com', 'hello firends chai pee loo......', 0, '2014-05-21 16:50:35.000000'),
(8, 'sandeep', 'aman@gmail.com', '<script>alert(\"hello\")</script>', 0, '2015-05-21 16:57:45.000000'),
(9, 'aman', 'aman@yahoo.com', 'tedd', 0, '2015-05-21 17:00:45.000000'),
(10, 'knowledge', 'seek@gmail.com', 'hello', 0, '2028-05-21 10:26:14.000000'),
(11, 'knowledge', 'kseek@gmail.com', 'fsrfssvs', 0, '2030-07-21 13:18:09.000000'),
(12, 'knowledge', 'seek@gmail.com', 'xfgjffhffhvhffhgfhkchcyhkcckcykd', 0, '2030-07-21 17:04:15.000000'),
(13, 'sandeep', 'aman@gmail.com', 'i am  sandeep mandloi, going to buy a 35 million dollaes=s=dadk k uajdsj  j fj bs fbj bfjk bf  j jf bjs bl fj fj hihnf; a wfhui', 0, '2023-08-21 12:38:14.000000'),
(14, 'knowledge', 'sandeepmandloi989@gmail.com', 'helloo nnafnanfjkanfafaf', 0, '2023-08-21 14:15:11.000000'),
(15, 'knowledge', 'sandeepmandloi989@gmail.com', 'helloo nnafnanfjkanfafaf', 0, '2023-08-21 14:17:14.000000');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(255) NOT NULL,
  `name` mediumtext NOT NULL,
  `notes` mediumtext NOT NULL,
  `subject_id` int(255) NOT NULL,
  `syllabus_id` int(255) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `name`, `notes`, `subject_id`, `syllabus_id`, `status`, `created_at`, `updated_at`) VALUES
(12, 'aman', 'aman1.pdf', 2, 130, 1, '2021-10-03 19:50:08.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `papers`
--

CREATE TABLE `papers` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `year` bigint(255) NOT NULL,
  `subject_id` int(255) NOT NULL,
  `papers` varchar(10000) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `papers`
--

INSERT INTO `papers` (`id`, `name`, `year`, `subject_id`, `papers`, `status`, `created_at`, `updated_at`) VALUES
(3, 'Maths', 2015, 2, 'Maths_2015.pdf', 1, '2021-07-15 14:59:47.000000', '2013-08-21 11:47:53.000000'),
(4, 'knowledge', 2019, 2, 'knowledge_2019.pdf', 1, '2021-07-22 11:34:49.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `programes`
--

CREATE TABLE `programes` (
  `id` int(255) NOT NULL,
  `programe_name` varchar(5000) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programes`
--

INSERT INTO `programes` (`id`, `programe_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'B.TECH', 1, '2021-10-09 14:29:14.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `semsandyears`
--

CREATE TABLE `semsandyears` (
  `id` int(255) NOT NULL,
  `yos_id` int(255) NOT NULL,
  `sem_year` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semsandyears`
--

INSERT INTO `semsandyears` (`id`, `yos_id`, `sem_year`) VALUES
(1, 2, '1 sem'),
(2, 2, '2 sem'),
(3, 2, '3 sem'),
(4, 2, '4 sem'),
(5, 2, '5 sem'),
(6, 2, '6 sem'),
(7, 2, '7 sem'),
(8, 2, '8 sem'),
(9, 1, '1st year'),
(10, 1, '2nd year'),
(11, 1, '3rd year'),
(12, 1, '4th year'),
(13, 3, '1st year'),
(14, 3, '2nd year'),
(15, 3, '3rd year');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `sub_name` varchar(1000) NOT NULL,
  `subject_code` varchar(255) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `sub_name`, `subject_code`, `status`, `created_at`, `updated_at`) VALUES
(2, 'APPLIED PHYSICS', '(BTPH-101)', 1, '2021-08-10', '0000-00-00'),
(3, 'Introduction to Computer Science and Engineering', '(BTCS-102)', 1, '2021-08-10', '0000-00-00'),
(4, 'Digital Logic and Circuit Design', '(BTEC-104)', 1, '2021-08-10', '0000-00-00'),
(5, 'Principles of \'C\' language', '(BTCS-104)', 1, '2021-08-10', '0000-00-00'),
(6, 'Programming Skills with \'C\'', '(BTCS-108)', 1, '2021-08-10', '0000-00-00'),
(7, 'Web Development Lab-I(HTML & XML)', '(BTIT-307)', 1, '2021-08-10', '0000-00-00'),
(8, 'Software Foundation and Programming ( 1. Clean Coding; 2. Javascript; 3. NodeRed; 4. NodeJS)', '(BTIBM-105)', 1, '2021-08-10', '0000-00-00'),
(9, 'Software Foundation and Programming 1 (with \'C\')', '(BTCS-105)', 1, '2021-08-10', '0000-00-00'),
(10, 'Red Hat Administration-I', '(RH-124)', 1, '2021-08-10', '0000-00-00'),
(11, 'Computer Peripherals and Interfaces', '( BTCS-204 )', 1, '2021-08-10', '0000-00-00'),
(12, 'Mobile Application Development-I', '(BTCSMOB-101)', 1, '2021-08-10', '0000-00-00'),
(13, 'Principles of Electrical Engineering', '(BTCSH-104)', 1, '2021-08-10', '0000-00-00'),
(14, 'Physics for Computing Science', '(BTCSH-105)', 1, '2021-08-10', '0000-00-00'),
(15, 'Business Communication and Value Science – I', '(BTCSH-106)', 1, '2021-08-10', '0000-00-00'),
(16, 'Discrete Mathematics', '(BTCSH-101)', 1, '2021-08-10', '0000-00-00'),
(17, 'Statistics, Probability and Calculus', '(BTCSH-102)', 1, '2021-08-10', '0000-00-00'),
(18, 'Fundamentals of Computer Science', '(BTCSCS-103)', 1, '2021-08-10', '0000-00-00'),
(19, 'Mathematics-II', '( BTMACS-201)', 1, '2021-08-10', '0000-00-00'),
(20, 'Computer Peripherals and Interfaces', '( BTCS-204 )', 1, '2021-08-10', '0000-00-00'),
(21, 'Data Structure and Algorithms', '(BTCS-403)', 1, '2021-08-10', '0000-00-00'),
(22, 'Computer System Organization', '( BTCS-404 )', 1, '2021-08-10', '0000-00-00'),
(23, 'Object Oriented Programming', '( BTCS-305)', 1, '2021-08-10', '0000-00-00'),
(24, 'Programming Skills with \'C++\'', '( BTCS-208 )', 1, '2021-08-10', '0000-00-00'),
(25, 'Communication Skills', '( HUCS-101 )', 1, '2021-08-10', '0000-00-00'),
(26, 'Design Thinking', '( BTIBM-203)', 1, '2021-08-10', '0000-00-00'),
(27, 'Agile Development Methodologies (DevOps + Agile)', '(BTIBM-202)', 1, '2021-08-10', '0000-00-00'),
(28, 'Agile Development Methodologies', '(BTIBM-201)', 1, '2021-08-10', '0000-00-00'),
(29, 'Red Hat Administration-II', '(RH-134)', 1, '2021-08-10', '0000-00-00'),
(30, 'Mobile Application Development-II', '(BTCSMOB-201)', 1, '2021-08-10', '0000-00-00'),
(31, 'Principles of Electronics Engineering', '(BTCSH-110)', 1, '2021-08-10', '0000-00-00'),
(32, 'Fundamentals of Economics', '(BTCSH-111)', 1, '2021-08-10', '0000-00-00'),
(33, 'Business Communication and Value Science – II', '(BTCSH-112)', 1, '2021-08-10', '0000-00-00'),
(34, 'Linear Algebra', '(BTCSH-107)', 1, '2021-08-10', '0000-00-00'),
(35, 'Statistical Methods', '(BTCSH-108)', 1, '2021-08-10', '0000-00-00'),
(36, 'Discrete Structures', '(BTIT-401)', 1, '2021-08-10', '0000-00-00'),
(37, 'Data Communication', '(BTCS-302)', 1, '2021-08-10', '0000-00-00'),
(38, 'Analysis and Design of Algorithms', '( BTIT-305)', 1, '2021-08-10', '0000-00-00'),
(39, 'Principles of Programming Languages', '(BTCS-303)', 1, '2021-08-10', '0000-00-00'),
(40, 'Introduction to Core Java', '(BTIT-309)', 1, '2021-08-10', '0000-00-00'),
(41, 'Technical Presentation Skills', '(BTCS-610)', 1, '2021-08-10', '0000-00-00'),
(42, 'Web Development Lab-II (PHP/JSP)', '( BTIT-407)', 1, '2021-08-10', '0000-00-00'),
(43, 'Cloud Computing: Project Based Learning', '(BTIBM-401)', 1, '2021-08-10', '0000-00-00'),
(44, 'Unix and Shell Programming Lab', '(BTIT-406)', 1, '2021-08-10', '0000-00-00'),
(45, 'Computational Learning (AI)', '(BTAI-301)', 1, '2021-08-10', '0000-00-00'),
(46, 'Object Oriented Programming Using Java', '(BTCS-308)', 1, '2021-08-10', '0000-00-00'),
(47, 'RedHat Administration-III', '(RH254)', 1, '2021-08-10', '0000-00-00'),
(48, 'Introduction to Information Technology', '(BTIT-101)', 1, '2021-08-10', '0000-00-00'),
(49, 'Cyber Ethics and Social Media Analysis(ICS)', '( BTICS-301)', 1, '2021-08-10', '0000-00-00'),
(50, 'Technical Presentation Skills', '(BTCS-610)', 1, '2021-08-10', '0000-00-00'),
(51, 'Mobile App Development III iOS', '(BTCSMOB-301)', 1, '2021-08-10', '0000-00-00'),
(52, 'Object Oriented Programming', '(BTCSCS-203)', 1, '2021-08-10', '0000-00-00'),
(53, 'Computational Statistics', '(BTCSCS-204)', 1, '2021-08-10', '0000-00-00'),
(54, 'Software Engineering', '(BTCSCS-205)', 1, '2021-08-10', '0000-00-00'),
(55, 'Financial Management', '(BTCSMS-206)', 1, '2021-08-10', '0000-00-00'),
(56, 'Formal Language and Automata Theory', '(BTCSCS-201)', 1, '2021-08-10', '0000-00-00'),
(57, 'Computer Organization and Architecture', '(BTCSCS-202)', 1, '2021-08-10', '0000-00-00'),
(58, 'Environment and Energy Studies', '(ML-301)', 1, '2021-08-10', '0000-00-00'),
(59, 'Computer Networks', '(BTIT-502)', 1, '2021-08-10', '0000-00-00'),
(60, 'Operating Systems', '(BTCS-502)', 1, '2021-08-10', '0000-00-00'),
(61, 'Advanced Java Programming', '(BTCS-409)', 1, '2021-08-10', '0000-00-00'),
(62, 'Unix and Shell Programming Lab', '(BTIT-406)', 1, '2021-08-10', '0000-00-00'),
(63, 'Mobile App Development Lab', '(BTIT-306)', 1, '2021-08-10', '0000-00-00'),
(64, 'Advanced Java', '(BTCS-307)', 1, '2021-08-10', '0000-00-00'),
(65, 'Application Development Using Python', '(BTIBM-403)', 1, '2021-08-10', '0000-00-00'),
(66, 'Application Development and deployment using IOT', '(BTIBMC-701)', 1, '2021-08-10', '0000-00-00'),
(67, 'Database Management Systems', '( BTCS-405)', 1, '2021-08-10', '0000-00-00'),
(68, 'Advanced Java Programming', '(BTCS-409)', 1, '2021-08-10', '0000-00-00'),
(69, 'Red Hat Application Development I - Java EE', '(JB-183)', 1, '2021-08-10', '0000-00-00'),
(70, 'System Programming', '(BTCS-410)', 1, '2021-08-10', '0000-00-00'),
(71, 'Mobile Application Development IV Android', '(BTCSMOB-401)', 1, '2021-08-10', '0000-00-00'),
(72, 'Database Management Systems', '(BTCSCS-210)', 1, '2021-08-10', '0000-00-00'),
(73, 'Software Design with UML', '(BTCSCS-211)', 1, '2021-08-10', '0000-00-00'),
(74, 'Introduction to Innovation, IP Management and Entrepreneurship', '(BTCSIIE-212)', 1, '2021-08-10', '0000-00-00'),
(75, 'Business Communication and Value Science – III', '(BTCSIIE-213)', 1, '2021-08-10', '0000-00-00'),
(76, 'Operations Research', '(BTCSMS-214)', 1, '2021-08-10', '0000-00-00'),
(77, 'Operating Systems', '(BTCSCS-209)', 1, '2021-08-10', '0000-00-00'),
(78, 'Computer Graphics and Multimedia', '(BTCS-503)', 1, '2021-08-10', '0000-00-00'),
(79, 'Software Engineering and Project Management', '(BTCS-504)', 1, '2021-08-10', '0000-00-00'),
(80, 'Artificial Intelligence', '(BTCS-511)', 1, '2021-08-10', '0000-00-00'),
(81, 'CYBER AND NETWORK SECURITY', '(BTIT-603)', 1, '2021-08-10', '0000-00-00'),
(82, 'WIRELESS COMMUNICATION NETWORKS', '(BTIT-511)', 1, '2021-08-10', '0000-00-00'),
(83, 'MANAGEMENT INFORMATION SYSTEM', '(BTIT-513)', 1, '2021-08-10', '0000-00-00'),
(84, 'INFORMATION STORAGE AND MANAGEMENT', '(BTIT-611)', 1, '2021-08-10', '0000-00-00'),
(85, 'ENTERPRISE RESOURCE PLANNING', '(BTIT-712)', 1, '2021-08-10', '0000-00-00'),
(86, 'Programming with Python', '(BTCS-407)', 1, '2021-08-10', '0000-00-00'),
(87, 'Scripting Languages', '(BTCS-607)', 1, '2021-08-10', '0000-00-00'),
(88, 'Big Data Technologies', '(BTIBMB-601)', 1, '2021-08-10', '0000-00-00'),
(89, 'Predictive Analytics', '(BTIBDA-501)', 1, '2021-08-10', '0000-00-00'),
(90, 'Micro services Architecture and Implementation', '(BTIBM-601)', 1, '2021-08-10', '0000-00-00'),
(91, 'Predictive Modelling', '(BTIBMA-501)', 1, '2021-08-10', '0000-00-00'),
(92, 'Cloud Computing', '(BTCS-701)', 1, '2021-08-10', '0000-00-00'),
(93, 'Computer Architecture and Microprocessor', '(BTCS-509)', 1, '2021-08-10', '0000-00-00'),
(94, 'RedHat Open Stack and Ansible', '(CLDO-507)', 1, '2021-08-10', '0000-00-00'),
(95, 'Network Security And Cryptography', '(BTICS-501)', 1, '2021-08-10', '0000-00-00'),
(96, 'Ethical Hacking Lab-1', '(BTICS-502)', 1, '2021-08-10', '0000-00-00'),
(97, 'Theory of Computation', '(BTCS-501)', 1, '2021-08-10', '0000-00-00'),
(98, 'Internet of Things', '(BTCS-602)', 1, '2021-08-10', '0000-00-00'),
(99, 'Cloud Computing', '(BTCS-701)', 1, '2021-08-10', '0000-00-00'),
(100, 'Data Science', '(BTCS-608)', 1, '2021-08-10', '0000-00-00'),
(101, 'Simulation and Modeling', '(BTCS-612)', 1, '2021-08-10', '0000-00-00'),
(102, 'Software Testing and Quality Assurance', '(BTCS-613)', 1, '2021-08-10', '0000-00-00'),
(103, 'Block Chain', '(BTCS-618)', 1, '2021-08-10', '0000-00-00'),
(104, 'Robotics', '(BTCS-617)', 1, '2021-08-10', '0000-00-00'),
(105, 'IT WorkshopSciLab/MATLAB', '(BTIT-608)', 1, '2021-08-10', '0000-00-00'),
(106, 'Minor Project', '(BTCS-606)', 1, '2021-08-10', '0000-00-00'),
(107, 'Object Oriented Analysis and Design', '(BTIT-604)', 1, '2021-08-10', '0000-00-00'),
(108, 'Micro services Architecture and Implementation', '(BTIBM-601)', 1, '2021-08-10', '0000-00-00'),
(109, 'Big Data Engineering - Spark & Scala', '(BTIBMB-602)', 1, '2021-08-10', '0000-00-00'),
(110, 'Big Data Technologies (Hadoop)', '(BTIBMC-602)', 1, '2021-08-10', '0000-00-00'),
(111, 'Artificial Intelligence', '(BTIBMC-601)', 1, '2021-08-10', '0000-00-00'),
(112, 'CYBER AND NETWORK SECURITY', '(BTIT-603)', 1, '2021-08-10', '0000-00-00'),
(113, 'Introduction to container Kubernete and RedHat OpenShift and JBOSS', '(DOJB-603)', 1, '2021-08-10', '0000-00-00'),
(114, 'Ethical Hacking Lab-II', '(BTICS-602)', 1, '2021-08-10', '0000-00-00'),
(115, 'Concepts of System Security', '(BTICS-601)', 1, '2021-08-10', '0000-00-00'),
(116, 'Human Values and Professional Ethics', '(BBAI-501)', 1, '2021-08-10', '0000-00-00'),
(117, 'Compiler Design', '( BTCS-601)', 1, '2021-08-10', '0000-00-00'),
(118, 'OBJECT ORIENTED ANALYSIS AND DESIGN', '( BTIT-604)', 1, '2021-08-10', '0000-00-00'),
(119, 'BIG DATA AND HADOOP', '(BTCS-702)', 1, '2021-08-10', '0000-00-00'),
(120, 'Next Generation Telecommunication Networks', '(BTCC-703)', 1, '2021-08-10', '0000-00-00'),
(121, 'Soft computing', '(BTCS-711)', 1, '2021-08-10', '0000-00-00'),
(122, 'Quantum Computing', '(BTCS-715)', 1, '2021-08-10', '0000-00-00'),
(123, 'Virtual Reality', '(BTCS-716)', 1, '2021-08-10', '0000-00-00'),
(124, 'Project', '(BTCS-706)', 1, '2021-08-10', '0000-00-00'),
(125, 'Computer Graphics and Multimedia', '(BTCS-503)', 1, '2021-08-10', '0000-00-00'),
(126, 'Mobile and Cloud Security', '(BTICS-701)', 1, '2021-08-10', '0000-00-00'),
(127, 'Cyber Investigation and Digital Forensic', '(BTICS-702)', 1, '2021-08-10', '0000-00-00'),
(128, 'DISTRIBUTED SYSTEM', '(BTIT-713)', 1, '2021-08-10', '0000-00-00'),
(162, 'aman', '', 1, '2021-10-09', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `subjects_details`
--

CREATE TABLE `subjects_details` (
  `id` int(255) NOT NULL,
  `subject_id` int(255) NOT NULL,
  `branch_id` int(255) NOT NULL,
  `sem_year_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects_details`
--

INSERT INTO `subjects_details` (`id`, `subject_id`, `branch_id`, `sem_year_id`) VALUES
(2, 2, 1, 1),
(3, 3, 1, 1),
(4, 4, 1, 1),
(5, 5, 1, 1),
(6, 6, 1, 1),
(7, 7, 1, 1),
(8, 8, 1, 1),
(9, 9, 1, 1),
(10, 10, 1, 1),
(11, 11, 1, 1),
(12, 12, 1, 1),
(13, 13, 1, 1),
(14, 14, 1, 1),
(15, 15, 1, 1),
(16, 16, 1, 1),
(17, 17, 1, 1),
(18, 18, 1, 1),
(19, 19, 1, 2),
(20, 20, 1, 2),
(21, 21, 1, 2),
(22, 22, 1, 2),
(24, 24, 1, 2),
(25, 25, 1, 2),
(26, 26, 1, 2),
(27, 27, 1, 2),
(28, 28, 1, 2),
(29, 29, 1, 2),
(30, 30, 1, 2),
(31, 31, 1, 2),
(32, 32, 1, 2),
(33, 33, 1, 2),
(34, 34, 1, 2),
(35, 35, 1, 2),
(36, 36, 1, 3),
(37, 37, 1, 3),
(38, 38, 1, 3),
(39, 39, 1, 3),
(40, 40, 1, 3),
(41, 41, 1, 3),
(42, 42, 1, 3),
(43, 43, 1, 3),
(44, 44, 1, 3),
(45, 45, 1, 3),
(46, 46, 1, 3),
(47, 47, 1, 3),
(48, 8, 1, 3),
(49, 49, 1, 3),
(50, 50, 1, 3),
(51, 51, 1, 3),
(52, 52, 1, 3),
(53, 53, 1, 3),
(54, 54, 1, 3),
(55, 55, 1, 3),
(56, 56, 1, 3),
(57, 57, 1, 3),
(58, 58, 1, 4),
(59, 59, 1, 4),
(60, 60, 1, 4),
(61, 61, 1, 4),
(62, 62, 1, 4),
(63, 63, 1, 4),
(64, 64, 1, 4),
(65, 65, 1, 4),
(66, 66, 1, 4),
(67, 67, 1, 4),
(68, 68, 1, 4),
(69, 69, 1, 4),
(70, 70, 1, 4),
(71, 71, 1, 4),
(72, 72, 1, 4),
(73, 73, 1, 4),
(74, 74, 1, 4),
(75, 75, 1, 4),
(76, 76, 1, 4),
(77, 77, 1, 4),
(78, 78, 1, 5),
(79, 79, 1, 5),
(80, 80, 1, 5),
(81, 81, 1, 5),
(82, 82, 1, 5),
(83, 83, 1, 5),
(84, 84, 1, 5),
(85, 85, 1, 5),
(86, 86, 1, 5),
(87, 87, 1, 5),
(88, 88, 1, 5),
(89, 89, 1, 5),
(90, 90, 1, 5),
(91, 91, 1, 5),
(92, 92, 1, 5),
(93, 93, 1, 5),
(94, 94, 1, 5),
(95, 95, 1, 5),
(96, 96, 1, 5),
(97, 97, 1, 6),
(98, 98, 1, 6),
(99, 99, 1, 6),
(100, 100, 1, 6),
(101, 101, 1, 6),
(102, 102, 1, 6),
(103, 103, 1, 6),
(104, 104, 1, 6),
(105, 105, 1, 6),
(106, 106, 1, 6),
(107, 107, 1, 6),
(108, 108, 1, 6),
(109, 109, 1, 6),
(110, 110, 1, 6),
(111, 111, 1, 6),
(112, 112, 1, 6),
(113, 113, 1, 6),
(114, 114, 1, 6),
(115, 115, 1, 6),
(116, 116, 1, 7),
(117, 117, 1, 7),
(118, 118, 1, 7),
(119, 119, 1, 7),
(120, 120, 1, 7),
(121, 121, 1, 7),
(122, 122, 1, 7),
(123, 123, 1, 7),
(124, 124, 1, 7),
(125, 125, 1, 7),
(126, 126, 1, 7),
(127, 127, 1, 7),
(128, 7, 2, 1),
(129, 6, 2, 1),
(130, 5, 2, 1),
(131, 4, 2, 1),
(132, 48, 2, 1),
(133, 11, 2, 1),
(135, 25, 2, 2),
(136, 24, 2, 2),
(137, 23, 2, 2),
(138, 22, 2, 2),
(139, 21, 2, 2),
(140, 19, 2, 2),
(141, 2, 2, 2),
(142, 42, 2, 3),
(143, 50, 2, 3),
(144, 40, 2, 3),
(145, 60, 2, 3),
(146, 36, 2, 3),
(147, 37, 2, 3),
(148, 38, 2, 3),
(149, 63, 2, 4),
(150, 62, 2, 4),
(151, 61, 2, 4),
(152, 79, 2, 4),
(153, 67, 2, 4),
(154, 58, 2, 4),
(155, 59, 2, 4),
(156, 87, 2, 5),
(157, 86, 2, 5),
(158, 83, 2, 5),
(159, 85, 2, 5),
(160, 84, 2, 5),
(161, 82, 2, 5),
(162, 78, 2, 5),
(163, 81, 2, 5),
(164, 128, 2, 5),
(165, 80, 2, 5),
(166, 106, 2, 6),
(167, 105, 2, 6),
(168, 103, 2, 6),
(169, 104, 2, 6),
(170, 102, 2, 6),
(171, 101, 2, 6),
(172, 99, 2, 6),
(173, 98, 2, 6),
(174, 100, 2, 6),
(175, 97, 2, 6),
(176, 120, 2, 7),
(177, 121, 2, 7),
(178, 122, 2, 7),
(179, 123, 2, 7),
(180, 118, 2, 7),
(181, 119, 2, 7),
(182, 116, 2, 7),
(183, 117, 2, 7),
(189, 132, 2, 2),
(190, 132, 2, 6);

-- --------------------------------------------------------

--
-- Table structure for table `syllabus`
--

CREATE TABLE `syllabus` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `unit_id` int(255) NOT NULL,
  `subject_id` int(255) NOT NULL,
  `syllabus_detail` varchar(1000) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 1,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `syllabus`
--

INSERT INTO `syllabus` (`id`, `name`, `unit_id`, `subject_id`, `syllabus_detail`, `status`, `created_at`, `updated_at`) VALUES
(2, 'Quantum Physics', 1, 2, '\nIntroduction to Quantum hypothesis, Matter wave concept, Wave Group and Particle\nvelocity and their relations, Uncertainty principle with elementary proof and applications to\nmicroscope and single slit, Compton Effect, Wave function and its physical significance.\nDevelopment of time dependent and time independent Schrodinger wave equation,\nApplications of time independent Schrodinger wave equation.', 1, '2021-08-10', '0000-00-00'),
(3, 'Introduction to Computer Fundamentals:', 1, 3, '\nIntroduction: What is Computer, Objectives, Hardware and software, Block Diagram of\nThe Computer, Functions of the different Units, CPU(Central Processing Unit), Input unit,\nOutput unit, Memory, Storage Devices, Representation of data and information, Computer\nLanguages, Machine language, Assembly language, High level language, Number System\nand Conversion, Classification of Computers, History and Generations of Computer, Types\nof Computers, Characteristics of Computers, Introduction to Free and Open Source\nSoftware, Definition of Computer Virus, Types of Viruses, Use of Antivirus software.\nApplications of Computers: Home, Education and Training, Entertainment, Science,\nMedicine, Engineering etc.', 1, '2021-08-10', '0000-00-00'),
(4, 'Digital Logic and Circuit Design(BTEC-104)', 1, 4, 'Number System & Codes:\nIntroduction to number systems, Binary numbers, Octal & Hexadecimal Numbers, Number\nbase Conversion, Signed binary numbers : 1’s Complement & 2 ’s Complement\nrepresentation and their arithmetic operation, Floating point representation, binary codes,\nBCD,ASCII, EBCDIC, Gray codes, Error detecting and Correcting codes, Hamming codes.\n', 1, '2021-08-10', '0000-00-00'),
(5, 'Principles of \'C\' language (BTCS-104)', 1, 5, 'Introduction to Programming Languages:\nEvolution of Programming Languages, Structured Programming, The Compilation Process,\nObject Code, Source Code, Executable Code, Operating Systems, Interpreters, Linkers, Loaders,\nFundamentals Of Algorithms, Flowcharts.', 1, '2021-08-10', '0000-00-00'),
(6, 'Programming Skills with \'C\' (BTCS-108)', 1, 6, 'Introduction to Programming:\nEvolution of Programming Languages, Structured Programming, The Compilation Process,\nObject Code, Source Code, Executable Code, Operating Systems, Interpreters, Linkers,\nLoaders, Fundamentals of Algorithms, Flow Charts.', 1, '2021-08-10', '0000-00-00'),
(7, 'Web Development Lab-I(HTML & XML) (BTIT-307)', 1, 7, 'Introduction to HTML:\nWhat is HTML, HTML Documents, SGML, Basic structure of an HTML document, creating an\nHTML document, Headers tags, Body tags, Paragraphs formatting, Text Elements, Tag\nElements, Special Character elements, Image tags, HTML Table tags and lists: Numbered list,\nNon- Numbered lists, Definition lists, Anchor tag, Name tag, Hyperlinks – FTP/HTTP/HTTPS,\nLinks with images and buttons, Links to send email messages, Text fonts and styles, background\ncolors/images, Marquee Behavior, Forms related tags. (Action, method, name, inputetc.)', 1, '2021-08-10', '0000-00-00'),
(8, 'Software Foundation and Programming ( 1. Clean Coding; 2. Javascript; 3. NodeRed; 4. NodeJS) (BTIBM-105)', 1, 8, 'Introduction to Clean Coding\nUnderstand the importance of bad and good code.\nUnderstand the importance of meaningful distinct names.\nUsage of domain and function names Usage of exceptions and its error code\nnames/descriptions.\nUnderstand about clean and bad comments.\nUnderstand the process of vertical and horizontal formatting.\nIntroduction to Web-designing\nHtml basic commands, Webpage creation using tags like formatting tags, table, frame\nand form tags. CSS types and properties with examples.', 1, '2021-08-10', '0000-00-00'),
(9, 'Software Foundation and Programming 1 (with \'C\') (BTCS-105)', 1, 9, 'Evaluation of Computing, The Amazing difference Engine, Method of Finite difference,\nEvaluation of Modern Computing, The Abstract Turing Machine, A Simple TM Example,\nVon Newman Architecture, FORTRAN Beginning of Hill, Internet, Where is our world\nHeading Today.\n', 1, '2021-08-10', '0000-00-00'),
(10, 'Red Hat Administration-I (RH-124)', 1, 10, 'Units Not Specified.', 1, '2021-08-10', '0000-00-00'),
(11, 'Computer Peripherals and Interfaces ( BTCS-204 )', 1, 11, 'Introduction to memory and its use, Memory chips and Modules: DIPP, SIPP, SIMM,\nDIMM, SO-DIMM, RIMM, Parity checking and ECC, ROM and its types, RAM and its\ntypes, Trouble shooting of Memory, Advanced Memory technologies: RDRAM, DDRAM,\nPRAM, VRAM.', 1, '2021-08-10', '0000-00-00'),
(12, 'Mobile Application Development-I (BTCSMOB-101)', 1, 12, '\nInstallation of Swift on macOS and Linux ,REPL, Package manager\n, creating a package, Building an Executable,\nWorking with multiple Source File.\n\n\nInstallation of Swift on macOS and Linux ,REPL, Package manager\n, creating a package, Building an Executable,\nWorking with multiple Source File.\nBuilding an Executable, Working with multiple Source File.', 1, '2021-08-10', '0000-00-00'),
(13, 'Principles of Electrical Engineering (BTCSH-104)', 1, 13, 'Concept of Potential difference, Voltage, Current, Fundamental\nLinear Passive and Active Elements to their Functional\nCurrent-Voltage Relation, Terminology and Symbols in Order to\nDescribe Electric Networks, Voltage Source and Current Sources,\nIdeal and Practical Sources, Concept of Dependent and Independent\nSources, Kirchhoff-S Laws and Applications to Network Solutions\nUsing Mesh and Nodal Analysis, Concept of Work, Power, Energy,\nand Conversion of Energy.', 1, '2021-08-10', '0000-00-00'),
(14, 'Physics for Computing Science (BTCSH-105)', 1, 14, 'Periodic Motion-Simple Harmonic Motion-Characteristics of\nSimple harmonic Motion Vibration of Simple Spring Mass System.\nResonance-Definition., Damped harmonic Oscillator –\nHeavy, Critical and Light Damping, Energy Decay in a\nDamped Harmonic oscillator, Quality Factor, Forced\nMechanical and Electrical Oscillators.', 1, '2021-08-10', '0000-00-00'),
(15, 'Business Communication and Value Science – I (BTCSH-106)', 1, 15, 'not Metioned', 1, '2021-08-10', '0000-00-00'),
(16, 'Discrete Mathematics (BTCSH-101)', 1, 16, 'Introduction Of Boolean Algebra, Truth Table, Basic Logic Gate,\nBasic Postulates Of Boolean Algebra, Principle Of Duality,\nCanonical Form, Karnaugh Map. UNIT II Abstract algebra: Set,\nRelation, Group, Ring, Field. UNIT III Combinatorics:\nBasic Counting, Balls And Bins Problems, Generating Functions,\nRecurrence Relations. Proof Techniques, Principle of Mathematical\nInduction, Pigeonhole Principle.', 1, '2021-08-10', '0000-00-00'),
(17, 'Statistics, Probability and Calculus (BTCSH-102)', 1, 17, '\nDefinition of Statistics. Basic objectives. Applications in\nVarious Branches of Science with Examples. Collection of Data:\nInternal and External Data, Primary and Secondary Data. Population\nand Sample, Representative Sample.', 1, '2021-08-10', '0000-00-00'),
(18, 'Fundamentals of Computer Science (BTCSCS-103)', 1, 18, 'Algorithm, and Flowchart for Problem Solving with Sequential Logic\nStructure, Decisions and Loops.\nImperative languages:\nIntroduction to imperative language; syntax and constructs of a\nspecific language (ANSI C) . Types Operator and Expressions with\ndiscussion of variable naming and Hungarian Notation: Variable Names,\nData Type and Sizes (Little Endian Big Endian), Constants, Declarations,\nArithmetic Operators, Relational Operators, Logical Operators,\nType Conversion, Increment Decrement Operators, Bitwise Operators,\nAssignment Operators and Expressions, Precedence and Order of Evaluation,\nProper Variable Naming and Hungarian Notation', 1, '2021-08-10', '0000-00-00'),
(19, 'Mathematics-II ( BTMACS-201)', 1, 19, 'Systems of linear equations and their solutions. Matrices, determinants, rank and inverse.\nLinear transformations. Range space and rank, null space and nullity. Eigenvalues and\neigenvectors. Similarity transformations. Diagonalization of Hermitian matrices.\n', 1, '2021-08-10', '0000-00-00'),
(20, 'Computer Peripherals and Interfaces ( BTCS-204 )', 1, 20, 'Introduction to memory and its use, Memory chips and Modules: DIPP, SIPP, SIMM,\nDIMM, SO-DIMM, RIMM, Parity checking and ECC, ROM and its types, RAM and its\ntypes, Trouble shooting of Memory, Advanced Memory technologies: RDRAM, DDRAM,\nPRAM, VRAM.', 1, '2021-08-10', '0000-00-00'),
(21, 'Data Structure and Algorithms (BTCS-403)', 1, 21, 'Overview of Data structures, Types of data structures,\nPrimitive and Non Primitive data structures and Operations,\nIntroduction to Algorithms & complexity notations. Characteristic\nof Array, One Dimensional Array, Operation with Array, Two Dimensional Arrays,\nThree or Multi-Dimensional Arrays, Sparse matrix, Drawbacks of linear arrays.\nStrings, Array of Structures, Pointer and one dimensional Arrays, Pointers and\nTwo Dimensional Arrays, Pointers and Strings, Pointer and Structure.', 1, '2021-08-10', '0000-00-00'),
(22, 'Computer System Organization ( BTCS-404 )', 1, 22, 'Brief History of computers, Von Newman architecture,\nComputer components, CPU, Memory, I/O, System Bus, registers,\nProgram Counter, Accumulator, Register Transfer Language, Instruction Cycle,\nInstruction formats and addressing modes of basic computer. Basic arithmetic\noperations: addition, subtraction, multiplication, division, floating point\narithmetic.', 1, '2021-08-10', '0000-00-00'),
(23, 'Object Oriented Programming ( BTCS-305)', 1, 23, 'Abstract data types, Objects and classes, Attributes and Methods, Objects as software units,\nEncapsulation and Information hiding, Objects instantiations and interactions, Object lifetime,\nStatic and dynamic objects, global and local objects, Metaclass, Modeling the real world objects.', 1, '2021-08-10', '0000-00-00'),
(24, 'Programming Skills with \'C++\' ( BTCS-208 )', 1, 24, 'Object Oriented Programming: Concept of Object Oriented Programming - Data hiding,\nData encapsulation, Class and Object, Abstract class and Concrete class, Polymorphism\n(Implementation of polymorphism using Function overloading an example in C++);\nInheritance, Advantages of Object Oriented Programming over earlier programming\nmethodologies.', 1, '2021-08-10', '0000-00-00'),
(25, 'Communication Skills ( HUCS-101 )', 1, 25, 'Nature, Meaning, Definition,Verbal and Non Verbal Communication Barriers to\nCommunication.', 1, '2021-08-10', '0000-00-00'),
(26, 'Design Thinking ( BTIBM-203)', 1, 26, 'Define business process management (BPM), List and describe the\nphases in the BPM lifecycle procedure, Define process modeling.,\nDescribe how to use IBM Business Process Manager to accomplish\nprocess modeling goals, Explain how to create and modify process\napplications in the Process Center, Create a process application,\nExplain case management, Describe the purpose and function of Blue\nworks Live, List and describe the core notation elements that are\nused in IBM Process Designer, Create a business process definition (BPD)\nfrom the process and nested process tasks and responsible, Explain\nhow to create and modify process models with the Designer view of\nthe IBM Process Designer.', 1, '2021-08-10', '0000-00-00'),
(27, 'Agile Development Methodologies (DevOps + Agile) (BTIBM-202)', 1, 27, 'What is a Project: Project Definition, Project vs Operations,Project, Program and Portfolio\nRelationship,Project Features,Project Phases, Project Execution Methodologies: Waterfall\nModel,V-Model,Agile,Agile vs Waterfall. Agile Deep Dive: Agile Methodology Overview,\nAgile Manifesto Introduction and Guiding Principles, Agile Team Roles, Agile Frameworks.\nDevOps Fundamentals: Introduction to DevOps, Introduction to Continuous\nIntegration/Continuous Delivery/Continuous Deployment, DevOps Tools-Git, Maven,\nDocker: Git, Maven, Docker.', 1, '2021-08-10', '0000-00-00'),
(28, 'Agile Development Methodologies (BTIBM-201)', 1, 28, 'What is a project? , Definition of Project, Project vs\nOperations, Relationship between Project, Program, Portfolio\nFeatures of Project, Measuring Project Success, Phases of a Project,\nProject Execution Methodologies, Waterfall Model, How does Waterfall work?\nWhere is Waterfall model suitable? Advantages, Disadvantages of Waterfall\nModel, V Model, How does V-Model work? Where is V-model suitable? Advantages,\nDisadvantages of V-Model , Agile, How does Agile works? Where is Agile\nsuitable, Advantages, Disadvantages of Agile, Agile Methodology Overview,\nIntroduction to Agile Manifesto & Guiding Principles, Roles within Agile Team,\nAgile vs Waterfall, Agile Frameworks, Extreme Programming (XP),Rational Unified\nProcess (RUP), Feature Drive Development (FDD),Test Driven Development (TDD),\nScrum, Kanban, Introduction, Git Installation, Git Quick Start, Text Editor\nInstallation, Basic Git Commands, Visual Merge/Diff Tool\nInstallation.\n', 1, '2021-08-10', '0000-00-00'),
(29, 'Red Hat Administration-II (RH-134)', 1, 29, 'not Metioned', 1, '2021-08-10', '0000-00-00'),
(30, 'Mobile Application Development-II (BTCSMOB-201)', 1, 30, 'Defining and Calling Functions, Function Parameters and Return Values: Functions Without\nReturn Values, Functions with Multiple Return Values, Optional Tuple Return Types Function\nArgument Labels and Parameter Names: Specifying Argument Labels, Omitting Argument\nLabels, Default Parameter Values, Variadic Parameters, Function Types, Function Types as\nParameter Types.', 1, '2021-08-10', '0000-00-00'),
(31, 'Principles of Electronics Engineering (BTCSH-110)', 1, 31, 'Crystalline material: Mechanical properties, Energy band theory, Fermi levels; Conductors,\nSemiconductors & Insulators: electrical properties, band diagrams. Semiconductors: intrinsic\n& extrinsic, energy band diagram, P&N-type semiconductors, drift & diffusion carriers.', 1, '2021-08-10', '0000-00-00'),
(32, 'Fundamentals of Economics (BTCSH-111)', 1, 32, 'Principles of Demand and Supply — Supply Curves of Firms — Elasticity of Supply; Demand\nCurves of Households — Elasticity of Demand; Equilibrium and Comparative Statics (Shift of a\nCurve and Movement along the Curve);', 1, '2021-08-10', '0000-00-00'),
(33, 'Business Communication and Value Science – II (BTCSH-112)', 1, 33, 'not Metioned', 1, '2021-08-10', '0000-00-00'),
(34, 'Linear Algebra (BTCSH-107)', 1, 34, 'Introduction to Matrices and Determinants; Solution of Linear Equations; Cramer\'s rule;\nInverse of a Matrix. UNIT II Vectors and linear combinations; Rank of a matrix; Gaussian\nelimination; LU Decomposition; Solving Systems of Linear Equations using the tools of\nMatrices.', 1, '2021-08-10', '0000-00-00'),
(35, 'Statistical Methods (BTCSH-108)', 1, 35, 'Random sampling. Sampling from finite and infinite populations. Estimates and standard error\n(sampling with replacement and sampling without replacement), Sampling distribution of\nsample mean, stratified random sampling.', 1, '2021-08-10', '0000-00-00'),
(36, 'Discrete Structures (BTIT-401)', 1, 36, '\nDefinition Of Sets, Venn Diagrams, Complements,\nCartesian Products, Power Sets,\nCounting Principle, Cardinality and Countability\n(Countable And Uncountable Sets),\nProofs of Some General Identities on Sets, Pigeonhole\nPrinciple. Relation: Definition, Types\nof Relation, Composition of Relations, Domain and Range\nof a Relation, Pictorial\nRepresentation of Relation, Properties of Relation,\nPartial Ordering Relation. Function:\nDefinition and Types of Function, Composition of\nFunctions, Recursively Defined Functions.', 1, '2021-08-10', '0000-00-00'),
(37, 'Data Communication (BTCS-302)', 1, 37, 'Data Communication Components, Types of Connections, Transmission Modes, Network\nDevices, Topologies, Protocols and Standards, OSI Model, Transmission Media, Bandwidth, Bit\nRate, Bit Length, Baseband and Broadband Transmission, Attenuation, Distortion, Noise,\nThroughout, Delay and Jitter.', 1, '2021-08-10', '0000-00-00'),
(38, 'Analysis and Design of Algorithms ( BTIT-305)', 1, 38, 'Algorithms, Analyzing Algorithms, Asymptotic Notations, Heap and Heap Sort,Brief Review of\nGraphs, Sets and Disjoint Set Union, Sorting and Searching Algorithms and their Analysis in\nterms of Space and Time Complexity. Divide and Conquer: General Method, Binary Search,\nMerge Sort, Quick Sort, Selection Sort, Strassen’s Matrix Multiplication Algorithms.', 1, '2021-08-10', '0000-00-00'),
(39, 'Principles of Programming Languages (BTCS-303)', 1, 39, 'Reasons for Studying, Concepts of Programming Languages,\nProgramming Domains,Language\nEvaluation Criteria, Influences on Language Design,\nLanguage Categories, Programming\nParadigms – Imperative, Object Oriented,\nFunctional Programming , Logic Programming.\nProgramming Language Implementation – Compilation\nand Virtual Machines, Programming\nEnvironments.\n', 1, '2021-08-10', '0000-00-00'),
(40, 'Introduction to Core Java (BTIT-309)', 1, 40, 'Basic History of Java and its Features, JVM, JRE and JDK, its Libraries and Functionalities,\nWhy Java? Installing Java, Java Classes and Objects, Variables and Data Types Conditional\nand Looping Constructs, Arrays.', 1, '2021-08-10', '0000-00-00'),
(41, 'Technical Presentation Skills (BTCS-610)', 1, 41, 'No Syllabus Provided', 1, '2021-08-10', '0000-00-00'),
(42, 'Web Development Lab-II (PHP/JSP) ( BTIT-407)', 1, 42, 'Identify Relationship Between Apache, Mysql and PHP, Steps to Install and Test Web\nServer,Configure Apache to Use PHP, Create Simple PHP Page Using PHP Structure and\nSyntax, Use ofPHP Variables, Data Types and PHP Operators, Apply Control Structures in\nProgramming, Steps toCreate User Defined Functions.', 1, '2021-08-10', '0000-00-00'),
(43, 'Cloud Computing: Project Based Learning (BTIBM-401)', 1, 43, 'CLOUD COMPUTING LANDSCAPE\n• Cloud impact in our lives\n• Cloud enterprise adoption\n• Cloud services\n• Summary & resources\nCLOUD INDUSTRY ADOPTION\n• Drivers for Digital Transformation\n• Cloud Impact in Banking\n• Cloud Impact in Education\n• Summary & resources', 1, '2021-08-10', '0000-00-00'),
(44, 'Unix and Shell Programming Lab (BTIT-406)', 1, 44, 'The UNIX Operating System, The UNIX Architecture, Features of UNIX, Internal and\nExternal Commands, Command Structure. General purpose utilities: cal, date, echo, printf, bc,\nscript, passwd, path, who, uname, tty, stty, pwd, cd, mkdir, rmdir,od.', 1, '2021-08-10', '0000-00-00'),
(45, 'Computational Learning (AI) (BTAI-301)', 1, 45, 'Probabilistic Reasoning, Prior, Likelihood and Posterior, Probabilistic Inference in Structured\nDistributions, Belief Networks: Conditional independence, d-Separation, d-Connection and\ndependence, Markov equivalence in belief networks, Belief networks - limited impressibility.', 1, '2021-08-10', '0000-00-00'),
(46, 'Object Oriented Programming Using Java (BTCS-308)', 1, 46, 'Object-Oriented Approach State the advantages of an object-oriented approach to software\ndevelopment, Describe essential object-oriented concepts and terminology, Describe the\nfundamentals of object-oriented programming', 1, '2021-08-10', '0000-00-00'),
(47, 'RedHat Administration-III (RH254)', 1, 47, 'Syllabus not specified', 1, '2021-08-10', '0000-00-00'),
(48, 'Introduction to Information Technology (BTIT-101)', 1, 48, 'Introduction, Type of Data, Simple model of Computer, Organization of CPU, Register, Bus\nArchitecture, Instruction Set, Memory & Storage Systems, I/O Devices, and System &\nApplication Software. Introduction to Operating System: Function, Types, Management of File,\nProcess & Memory.', 1, '2021-08-10', '0000-00-00'),
(49, 'Cyber Ethics and Social Media Analysis(ICS) ( BTICS-301)', 1, 49, '\nIntroduction to the Legal Perspectives of Cybercrimes and\nCyber security, Cybercrime and the Legal Landscape around the World,\nWhy Do We Need Cyber laws, The Indian IT Act, Challenges to Indian\nLaw and Cybercrime Scenario in India, Consequences of Not Addressing\nthe Weakness in Information Technology Act, Digital Signatures and the\nIndian IT Act, Cybercrime and Punishment, Cyber law, Technology and\nStudents: Indian Scenario.', 1, '2021-08-10', '0000-00-00'),
(50, 'Technical Presentation Skills (BTCS-610)', 1, 50, 'No Syllabus Provided', 1, '2021-08-10', '0000-00-00'),
(51, 'Mobile App Development III iOS (BTCSMOB-301)', 1, 51, 'Introduction to iOS, Mobile application development, Overview of iOS platform, setting up\nXcode & tools, MVC design pattern. Interface Builder Basics: Common system views, Interface\nBuilder Storyboards, project options, default project, create a new project with label and a\ngreet function.', 1, '2021-08-10', '0000-00-00'),
(52, 'Object Oriented Programming (BTCSCS-203)', 1, 52, 'Types Operator and Expressions, Scope and Lifetime, Constants, Pointers, Arrays, and\nReferences, Control Flow, Functions and Program Structure, Namespaces, error handling,\nInput and Output (C-way), Library Functions (string, math, stdlib), Command line arguments,\nPre-processor directive', 1, '2021-08-10', '0000-00-00'),
(53, 'Computational Statistics (BTCSCS-204)', 1, 53, 'Multivariate Normal Distribution Functions, Conditional Distribution and its relation to\nregression model, Estimation of parameters. Multiple Linear Regression Model: Standard\nmultiple regression models with emphasis on detection of collinearity, outliers, non-normality\nand autocorrelation, Validation of model assumptions.', 1, '2021-08-10', '0000-00-00'),
(54, 'Software Engineering (BTCSCS-205)', 1, 54, 'Programming in the small vs. programming in the large; software project failures and\nimportance ofsoftware quality and timely availability; engineering approach to software\ndevelopment; role ofsoftware engineering towards successful execution of large software\nprojects; emergence of softwareengineering as a discipline.', 1, '2021-08-10', '0000-00-00'),
(55, 'Financial Management (BTCSMS-206)', 1, 55, 'Introduction to Financial Management - Goals of the firm - Financial Environments. Time\nValue of Money : Simple and Compound Interest Rates, Amortization, Computing more that\nonce ayear, Annuity Factor.', 1, '2021-08-10', '0000-00-00'),
(56, 'Formal Language and Automata Theory (BTCSCS-201)', 1, 56, 'Alphabet, languages and grammars, productions and derivation, Chomsky hierarchy of languages.', 1, '2021-08-10', '0000-00-00'),
(57, 'Computer Organization and Architecture (BTCSCS-202)', 1, 57, 'CPU, memory, input-output subsystems, control unit. Instruction set architecture of a CPU:\nRegisters, instruction execution cycle, RTL interpretation of instructions, addressing modes,\ninstruction set. Outlining instruction sets of some common CPUs.', 1, '2021-08-10', '0000-00-00'),
(58, 'Environment and Energy Studies (ML-301)', 1, 58, 'Environmental Pollution & Control: Classification of pollution,\nAir Pollution: Primary and secondary pollutants, Automobile and\nindustrial pollution, Ambient air quality standards. Water pollution:\nSources and types, Impacts of modern agriculture, degradation of soil.\nNoise Pollution: Sources and Health hazards, standards, Solid Waste management\ncomposition and characteristics of e - Waste and its management.\nPollution control technologies: Wastewater Treatment methods: Primary,\nSecondary and Tertiary.', 1, '2021-08-10', '0000-00-00'),
(59, 'Computer Networks(BTIT-502)', 1, 59, '\nDefinitions, Goals, components, Architecture, Classifications &\nTypes. Layered Architecture: Protocol hierarchy, Design Issues,\nInterfaces and Services, Connection Oriented &\nConnectionless Services, Service primitives, Design issues &\nits functionality. ISOOSI Reference\nModel: Principle, Model, TCP/IP model overview, Descriptions\nof various layers and its comparison with TCP/IP.\nNetwork standardization.', 1, '2021-08-10', '0000-00-00'),
(60, 'Operating Systems (BTCS-502)', 1, 60, 'Introduction and Need of operating system, Layered Architecture/Logical Structure of\nOperating system, Type of OS(Multiprogramming , Time Sharing, Real Time ,Networked,\nDistributed, Clustered, Hand Held), Operating system as Resource Manager and Virtual\nMachine, OS Services, BIOS, System Calls/Monitor Calls, Firmware- BIOS, Boot Strap Loader.\nThreads- processes versus threads, threading, concepts, models, kernel & user level threads,\nthread usage, benefits, multithreading models.', 1, '2021-08-10', '0000-00-00'),
(61, 'Advanced Java Programming (BTCS-409)', 1, 61, 'J2EE Event Handling & GUI Design Event handling, AWT: Windows, Graphics, Text, AWT\nControls, Layout Managers, and Menus, Images, GUI Programming with Swing, Exploring\nSwing, Swing Menu', 1, '2021-08-10', '0000-00-00'),
(62, 'Unix and Shell Programming Lab (BTIT-406)', 1, 62, 'The UNIX Operating System, The UNIX Architecture, Features of UNIX, Internal and\nExternal Commands, Command Structure. General purpose utilities: cal, date, echo, printf, bc,\nscript, passwd, path, who, uname, tty, stty, pwd, cd, mkdir, rmdir,od.', 1, '2021-08-10', '0000-00-00'),
(63, 'Mobile App Development Lab (BTIT-306)', 1, 63, 'Introduction to mobile Devices and Administrative,Mobile Devices vs. Desktop devices - ARM\nand Intel Architectures - Power Management - Screen Resolution - Touch interfaces -\nApplication development - App Store, Google Play, Windows Store - Development\nEnvironments Introduction: XCode , Eclipse , PhoneGAP, etc - Native vs. web applications.', 1, '2021-08-10', '0000-00-00'),
(64, 'Advanced Java (BTCS-307)', 1, 64, 'Java Networking :Network Basics and Socket overview, TCP/IP client sockets, URL, TCP/IP\nserver sockets, Datagrams, java.net package Socket, ServerSocket, InetAddress, URL, URL\nConnection.', 1, '2021-08-10', '0000-00-00'),
(65, 'Application Development Using Python (BTIBM-403)', 1, 65, 'Application Development Using Python (BTIBM-403)', 1, '2021-08-10', '0000-00-00'),
(66, 'Application Development and deployment using IOT (BTIBMC-701)', 1, 66, 'What is Python?, Advantages and disadvantages, Downloading and installing, Which version of\nPython Running Python Scripts and using the interpreter interactively.', 1, '2021-08-10', '0000-00-00'),
(67, 'Database Management Systems ( BTCS-405)', 1, 67, 'Introduction:\nConcept & Overview of DBMS, Purpose of Database Systems,\nArchitecture of DBMS, Data\nModels and its type, Schema and Instances, Data Independence,\nDBA and its function. Entity-Relationship Model:\nEntities, Attributes and its types, Mapping Cardinalities, Keys,\nEntity Relationship Diagram, Weak entity set and Strong entity\nset and Extended E-R features ( Generalization ,\nSpecialization, Aggregation) ,\nER Diagram to Relational Table conversion.', 1, '2021-08-10', '0000-00-00'),
(68, 'Advanced Java Programming (BTCS-409)', 1, 68, 'J2EE Event Handling & GUI Design Event handling, AWT: Windows, Graphics, Text, AWT\nControls, Layout Managers, and Menus, Images, GUI Programming with Swing, Exploring\nSwing, Swing Menu', 1, '2021-08-10', '0000-00-00'),
(69, 'Red Hat Application Development I - Java EE (JB-183)', 1, 69, 'No Syllabus Provided', 1, '2021-08-10', '0000-00-00'),
(70, 'System Programming (BTCS-410)', 1, 70, 'Introduction to System Programming, Need of System Programming, Compiling with GCC,\nAutomating the Process with GNU, Debugging with GNU Debugger, Linux Kernel, Obtaining\nthe Kernel Source, The Kernel Source Tree, Building the Kernel.', 1, '2021-08-10', '0000-00-00'),
(71, 'Mobile Application Development IV Android (BTCSMOB-401)', 1, 71, 'Android overview, features, history and versions, API levels, Installation of Android Studio,\nconfiguring Android studio and Create Virtual Device, Dalvik Virtual Machine.', 1, '2021-08-10', '0000-00-00'),
(72, 'Database Management Systems (BTCSCS-210)', 1, 72, 'Introduction to Database. Hierarchical, Network and Relational Models. Database system\narchitecture: Data Abstraction, Data Independence, Data DefinitionLanguage (DDL), Data\nManipulation Language (DML).', 1, '2021-08-10', '0000-00-00'),
(73, 'Software Design with UML (BTCSCS-211)', 1, 73, 'Introduction to on Object Oriented Technologies and the UML Method.\n• Software development process: The Waterfall Model vs. The Spiral Model.\n• The Software Crisis, description of the real world using the Objects Model.\n• Classes, inheritance and multiple configurations.\n• Quality software characteristics.\n• Description of the Object Oriented Analysis process vs. the Structure Analysis Model.\nIntroduction to the UML Language.\n• Standards.\n• Elements of the language.\n• General description of various models.\n• The process of Object Oriented software development.\n• Description of Design Patterns.\n• Technological Description of Distributed Systems.', 1, '2021-08-10', '0000-00-00'),
(74, 'Introduction to Innovation, IP Management and Entrepreneurship (BTCSIIE-212)', 1, 74, 'What and Why? Innovation as a core business process, Sources of innovation, Knowledge push\nvs. need pull innovations. Class Discussion- Is innovation manageable or just a random\ngambling activity?', 1, '2021-08-10', '0000-00-00'),
(75, 'Business Communication and Value Science – III (BTCSIIE-213)', 1, 75, 'No Syllabus Provided', 1, '2021-08-10', '0000-00-00'),
(76, 'Operations Research (BTCSMS-214)', 1, 76, 'Origin of OR and its definition. Concept of optimizing performance measure,\nTypes of OR problems,Deterministic vs. Stochastic optimization,\nPhases of OR problem approach – problem formulation,building mathematical\nmodel, deriving solutions, validating model, controlling and\nimplementingsolution.', 1, '2021-08-10', '0000-00-00'),
(77, 'Operating Systems (BTCSCS-209)', 1, 77, 'Concept of Operating Systems (OS), Generations of OS, Typesof OS, OS Services, Interrupt\nhandling andSystem Calls, Basic architectural concepts of an OS, Concept of Virtual Machine,\nResource Manager view, process view and hierarchical view of an OS.\nProcesses:\nDefinition, Process Relationship, Different states of a Process, Process Statetransitions, Process\nControl Block (PCB), Context switching.\nThread:\nDefinition, Various states, Benefits of threads, Types of threads, Concept ofmultithreads.', 1, '2021-08-10', '0000-00-00'),
(78, 'Computer Graphics and Multimedia (BTCS-503)', 1, 78, 'What is Computer Graphics?, Where Computer Generated pictures are used, Elements of\nPictures created in Computer Graphics Graphics display devices,Graphics input primitives and\nDevices.Introduction to openGL:- Getting started Making pictures, Drawing basic\nprimitivesSimple interaction with mouse and keyboard', 1, '2021-08-10', '0000-00-00'),
(79, 'Software Engineering and Project Management (BTCS-504)', 1, 79, 'Software Engineering, Software Process, A Generic Process Model, Process Assessment and\nImprovement, Prescriptive Process Models- Waterfall Model, Incremental Models,\nEvolutionary Models, Concurrent Models, Specialized Process Model, Unified Process, Personal\nand Team process Models, Process technology, Agile development.', 1, '2021-08-10', '0000-00-00'),
(80, 'Artificial Intelligence (BTCS-511)', 1, 80, 'Concept of AI, history, current status, scope, agents, environments, Problem Formulations,\nReview of tree and graph structures, State space representation, Search graph and Search tree.', 1, '2021-08-10', '0000-00-00'),
(81, 'CYBER AND NETWORK SECURITY (BTIT-603)', 1, 81, 'Computer Security Concepts,The OSI Security Architecture,\nSecurity Attacks, Security Services, Security mechanism,\nFundamental Security Design Principles, Attack Surface and\nAttack trees, A Model for Network Security. Introduction to\nCyber crime, Cyber crime and Information Security, Classification\nof Cyber crimes, Cyber crime: The Legal Perspective,\nCyber crime: An Indian Perspective.', 1, '2021-08-10', '0000-00-00'),
(82, 'WIRELESS COMMUNICATION NETWORKS (BTIT-511)', 1, 82, 'Evolution of mobile communications, Mobile Radio System around the world, Types of\nWireless communication System, Comparison of Common wireless system, Trend in Cellular\nradio and personal communication. Second generation Cellular Networks, Third Generation\n(3G) Wireless Networks ,Wireless Local Loop(WLL),Wireless Local Area network(WLAN),', 1, '2021-08-10', '0000-00-00'),
(83, 'MANAGEMENT INFORMATION SYSTEM (BTIT-513)', 1, 83, 'Introduction, Modern Organization-IT enabled- NetworkedDispersed- Knowledge\nOrganization, Information Systems in Organizations- what are information systems?, Brief\nhistory of computing- ENIAC: Way to commercial computers- Advent of artificial intelligence advent of personal computing-Free Software Movement- Advent of Internet, The role of\ninternet- Internet and Web: they are different-the internet changes everything', 1, '2021-08-10', '0000-00-00'),
(84, 'INFORMATION STORAGE AND MANAGEMENT (BTIT-611)', 1, 84, 'Digital data and its types, Information storage, Key characteristics of data center, Evolution of\ncomputing platforms. Introduction to storage technology: Data Proliferation, evolution of\nvarious storage technologies, Overview of storage infrastructure components, Information life\nCycle Management, Data categorization.', 1, '2021-08-10', '0000-00-00'),
(85, 'ENTERPRISE RESOURCE PLANNING (BTIT-712)', 1, 85, '1. Enterprise Resource Planning –Introduction\n2. Need of ERP\n3. Advantages of ERP 4. Growth of ERP', 1, '2021-08-10', '0000-00-00'),
(86, 'Programming with Python (BTCS-407)', 1, 86, 'The basic elements of Python, Branching programs, Strings and Input, Iteration. Functions,\nScoping and Abstraction: Functions and Scoping, Specifications, Recursion, Global variables,\nModules, Files.', 1, '2021-08-10', '0000-00-00'),
(87, 'Scripting Languages (BTCS-607)', 1, 87, 'Introduction of scripting languages, need of scripting, characteristics of scripting languages,\nuses of scripting languages, Introduction of client side scripting languages like JavaScript,\nVBScript, HTML5 (Structure), CSS3 (Designing), AJAX, jQuery, Server side scripting\nlanguages like PHP, ASP.NET (C# OR Visual Basic), C++ , Java and JSP, Python, Ruby on\nRails.', 1, '2021-08-10', '0000-00-00'),
(88, 'Big Data Technologies (BTIBMB-601)', 1, 88, 'Introduction to Big Data Traditional way of working in IT, Traditional IT Challenges, Future\nTrend in IT, What is Cloud Computing Cloud Characteristics, service and Delivery models,\nCloud Computing helps overcome IT challenges, Traditional On-premises Core IT, Cloud\nService, IBM Cloud – IAAS, PAAS and SAAS,IBM cloud Infrastructure (Iaas) Offerings,IBM\nCloud Platform as a service offerings, Cloud Delivery models,Private Cloud,Public Cloud', 1, '2021-08-10', '0000-00-00'),
(89, 'Predictive Analytics (BTIBDA-501)', 1, 89, 'Use Cases Analytics Overview, Domains, Roles, Data Analytics in Practice, Methodologies,\nMethods, Integrated Environment for Analytics projects, Cloud Based Analytics Lifecycle,\nAnalytics capabilities on the cloud.', 1, '2021-08-10', '0000-00-00'),
(90, 'Micro services Architecture and Implementation (BTIBM-601)', 1, 90, 'Motivation for Micro services, What is monolithic application? Domain Driven Design, Edge\nService, Dealing with complexity, Micro services Security, API management and gateways, the\nfuture of Micro services, Micro services Governance, Summary of Micro services.', 1, '2021-08-10', '0000-00-00'),
(91, 'Predictive Modelling (BTIBMA-501)', 1, 91, 'Define Data Analytics with real time uses Introduction of Analytics, Different Job role in\nanalytics, Data Analytics in Practice, Methods of Analytics Process, Integrated Environment for\nAnalytics projects, Lifecycle of Cloud Based Analytics.', 1, '2021-08-10', '0000-00-00'),
(92, 'Cloud Computing (BTCS-701)', 1, 92, 'Overview of Cloud Computing Introduction- Evolution, Shift from distributed computing to\ncloud computing; principles and characteristics of cloud computing- IaaS, PaaS, SaaS; service\noriented computing and cloud environment, Advantages, Service & Deployment Models,\nInfrastructure, and Consumer View, Functioning of Cloud Computing, Cloud Architecture,\nCloud Storage, Cloud Services, Industrial Applications.', 1, '2021-08-10', '0000-00-00'),
(93, 'Computer Architecture and Microprocessor (BTCS-509)', 1, 93, 'Von Newman architecture, Computer components, CPU, Memory, I/O, System Bus, registers,\nProgram Counter, Accumulator, Register Transfer Language, Instruction Cycle, Instruction\nformats and addressing modes of basic computer. Basic arithmetic operations: addition,\nsubtraction, multiplication, division, floating point arithmetic.', 1, '2021-08-10', '0000-00-00'),
(94, 'RedHat Open Stack and Ansible (CLDO-507)', 1, 94, 'not syllabus configured', 1, '2021-08-10', '0000-00-00'),
(95, 'Network Security And Cryptography (BTICS-501)', 1, 95, 'Introduction, Need for Security, Security in Networks : Threats in networks, Network Security\nControls – Architecture, Attacks on Computers & Computer Security, Content Integrity,\nStrong Authentication, Access Controls, Wireless Security, Honey pots.', 1, '2021-08-10', '0000-00-00'),
(96, 'Ethical Hacking Lab-1 (BTICS-502)', 1, 96, 'Computer Security Concepts, The OSI Security Architecture, Security Attacks, Security\nServices, Security mechanism, Fundamental Security Design Principles, Attack Surface and\nAttack trees, A Model for Network Security. Introduction to Cybercrime, Cybercrime and\nInformation Security, Classification of Cybercrimes', 1, '2021-08-10', '0000-00-00'),
(97, 'Theory of Computation (BTCS-501)', 1, 97, 'Alphabets, Strings and Languages; Automata and Grammars, Deterministic finite Automata\n(DFA)-Formal Definition, Simplified notation: State transition graph, Transition table,\nLanguage of DFA, Nondeterministic finite Automata (NFA), NFA with epsilon transition,\nLanguage of NFA, Equivalence of NFA and DFA, Minimization of Finite Automata,\nDistinguishing one string from other, Myhill-Nerode Theorem.', 1, '2021-08-10', '0000-00-00'),
(98, 'Internet of Things (BTCS-602)', 1, 98, 'Architectural Overview, Design principles and needed capabilities, IoT Applications, Sensing,\nActuation, Basics of Networking, M2M and IoT Technology FundamentalsDevices and\ngateways, Data management, Business processes in IoT, Everything as a Service(XaaS), Role of\nCloud in IoT, Security aspects in IoT.', 1, '2021-08-10', '0000-00-00'),
(99, 'Cloud Computing (BTCS-701)', 1, 99, 'Overview of Cloud Computing Introduction- Evolution, Shift from distributed computing to\ncloud computing; principles and characteristics of cloud computing- IaaS, PaaS, SaaS; service\noriented computing and cloud environment, Advantages, Service & Deployment Models,\nInfrastructure, and Consumer View, Functioning of Cloud Computing, Cloud Architecture,\nCloud Storage, Cloud Services, Industrial Applications.', 1, '2021-08-10', '0000-00-00'),
(100, 'Data Science (BTCS-608)', 1, 100, 'Concept of Data Science, Traits of Big data, Web Scraping, Analysis vs Reporting.', 1, '2021-08-10', '0000-00-00'),
(101, 'Simulation and Modeling (BTCS-612)', 1, 101, '\nIntroduction to simulation & modeling, advantages anddisadvantages\nof simulation, application areas in communication, computer and\nsoftwaredesign, systems and systems environment, components of a\nsystem, discrete and continuoussystems, model of a system, types\nof models, discrete-event simulation, steps in a simulationstudy.\nSimulation Examples Simulation of queueing systems, on-demand and\ninventorysystems, simulation for reliability\nanalysis, Introduction to GPSS.', 1, '2021-08-10', '0000-00-00'),
(102, 'Software Testing and Quality Assurance (BTCS-613)', 1, 102, 'Basic Testing Vocabulary, Quality Assurance versus Quality Control, The Cost of Quality,\nSoftware Quality Factors, Software Defect, The Multiple Roles of the Software Tester(People\nRelationships), Scope of Testing, Testing Constraints, Various software development Life cycles\n(SDLC), Independent Testing, QA Process, Levels of Testing, The ―V‖ Concept of Testing.', 1, '2021-08-10', '0000-00-00'),
(103, 'Block Chain (BTCS-618)', 1, 103, 'Overview of Block chain, Public Ledgers, Bitcoin, Smart Contracts, Block in a Block chain,\nTransactions, Distributed Consensus, Public vs Private Block chain, Understanding Crypto\ncurrency to Block chain, Permissioned Model of Block chain, Overview of Security aspects of\nBlock chain. Basic Crypto Primitives: Cryptographic Hash Function, Properties of a hash\nfunction, Hash pointer and Merkle tree, Digital Signature, Public Key Cryptography, A basic\ncryptocurrency.', 1, '2021-08-10', '0000-00-00'),
(104, 'Robotics (BTCS-617)', 1, 104, 'Types and components of a robot, Classification of robots, closedloop and open-loop control\nsystems.Kinematics systems; Definition of mechanisms and manipulators, Social issues and\nsafety.', 1, '2021-08-10', '0000-00-00'),
(105, 'IT WorkshopSciLab/MATLAB (BTIT-608)', 1, 105, 'About SCILAB/MATLAB, SCILAB/MATLAB System, Starting and Quitting\nSCILAB/MATLAB. EXPRESSIONS: Variables Numbers, Operators Functions, Expressions.', 1, '2021-08-10', '0000-00-00'),
(106, 'Minor Project (BTCS-606)', 1, 106, 'Not Specified Syllabus', 1, '2021-08-10', '0000-00-00'),
(107, 'Object Oriented Analysis and Design (BTIT-604)', 1, 107, 'About Object Orientated Technology, Development and OO Modeling History. Modeling\nConcepts: Modeling design Technique, Three models, Class Model, State model and Interaction\nmodel.', 1, '2021-08-10', '0000-00-00'),
(108, 'Micro services Architecture and Implementation (BTIBM-601)', 1, 108, 'Understand JavaScript and DOM and BOM , Understand Server side Application, Understand\nNoSQL (MongoDb), Deployment of Nodejs application', 1, '2021-08-10', '0000-00-00'),
(109, 'Big Data Engineering - Spark & Scala (BTIBMB-602)', 1, 109, 'Introduction to Big Data and Analytics Introduction to\nbig data, Big data overview, IBM 4’v,\nDescribing the functions and features of HDP,\nDeveloping and understanding of the complete\nopen-source Hadoop ecosystem, Understanding the\npurpose of Apache Ambari in the HDP\nstack, Exploring some of the directory structure\non the Linux system, Describing the nature of\nthe Hadoop Distributed File System (HDFS),\nExplaining the function of the NameNode and\nDataNodes in an Hadoop cluster, Explaining how\nfiles are stored and blocks (\"splits\") are\nreplicated, Filing access and basic commands with\nHDFS, Describing the MapReduce model v1,\nListing the limitations of Hadoop 1 and MapReduce 1,\nMapper class and Reducer class,\nDescribing the YARN model, Comparing Hadoop 2/YARN with\nHadoop 1, Run MapReduce\nand YARN jobs, Understanding the overall architecture of\nAmbari, Listing the functions of the\nmain components of Ambari, Explaining how to start and\nstop services from Ambari Web\nConsole, Managing Hadoop ', 1, '2021-08-10', '0000-00-00'),
(110, 'Big Data Technologies (Hadoop) (BTIBMC-602)', 1, 110, 'Develop an understanding of the complete open-source Hadoop ecosystem and its near term\nfuture directions, compare and evaluate the major Hadoop distributions and their ecosystem\ncomponents both their strengths and their limitations, hands-on experience with key\ncomponents of various big data ecosystem components and roles in building a complete big\ndata, solution to common business problems.', 1, '2021-08-10', '0000-00-00'),
(111, 'Artificial Intelligence (BTIBMC-601)', 1, 111, 'AI LANDSCAPE AI impact in the world today, History and Evolution of AI, AI Explained, AI\nTechnologies, Applications of A.I. Summary & Resources', 1, '2021-08-10', '0000-00-00'),
(112, 'CYBER AND NETWORK SECURITY (BTIT-603)', 1, 112, 'Computer Security Concepts,The OSI Security Architecture, Security Attacks, Security\nServices, Security mechanism, Fundamental Security Design Principles, Attack Surface and\nAttack trees, A Model for Network Security. Introduction to Cyber crime, Cyber crime and\nInformation Security, Classification of Cyber crimes, Cyber crime: The Legal Perspective,\nCyber crime: An Indian Perspective.', 1, '2021-08-10', '0000-00-00'),
(113, 'Introduction to container Kubernete and RedHat OpenShift and JBOSS (DOJB-603)', 1, 113, 'No Syllabus Specified', 1, '2021-08-10', '0000-00-00'),
(114, 'Ethical Hacking Lab-II (BTICS-602)', 1, 114, 'Introduction, Functionalities, Uses, features of Wire shark, color coding in wire shark,\ninstallation. Concepts of network traffic, filters used in wore shark.', 1, '2021-08-10', '0000-00-00'),
(115, 'Concepts of System Security (BTICS-601)', 1, 115, 'Definition of System Security, Goals, characteristics and importance of system security,\nprinciple of easiest penetration, Three pillars of security CIA (Confidentiality, Integrity and\nAvailability), basic introduction of attacks, threat, vulnerability, risk, system policy, security\nconcepts and relationship, system security threats.', 1, '2021-08-10', '0000-00-00'),
(116, 'Human Values and Professional Ethics (BBAI-501)', 1, 116, 'Unit I: Human Value\n1. Definition, Essence, Features and Sources\n2. Sources and Classification\n3. Hierarchy of Values\n4. Values Across Culture', 1, '2021-08-10', '0000-00-00'),
(117, 'Compiler Design ( BTCS-601)', 1, 117, '\nCompiler, Compilers analysis of the source program, Phases of a compiler,\nCousins of the Compiler, Grouping of Phases and Compiler\nconstruction tools, Lexical Analysis, Role of Lexical Analyzer,\nInput Buffering and Specification of Tokens.', 1, '2021-08-10', '0000-00-00'),
(118, 'OBJECT ORIENTED ANALYSIS AND DESIGN ( BTIT-604)', 1, 118, 'About Object Orientated Technology, Development and OO Modeling History. Modeling\nConcepts: Modeling design Technique, Three models, Class Model, State model and Interaction\nmodel.', 1, '2021-08-10', '0000-00-00'),
(119, 'BIG DATA AND HADOOP (BTCS-702)', 1, 119, 'Introduction about big data ,Describe details Big data: definition and taxonomy , explain Big\ndata value for the enterprise , Setting up the demo environment ,Describe Hadoop Architecture\n, Hadoop Distributed File System, MapReduce& HDFS , First steps with the Hadoop , Deep to\nunderstand the fundamental of MapReduce', 1, '2021-08-10', '0000-00-00'),
(120, 'Next Generation Telecommunication Networks (BTCC-703)', 1, 120, 'Basic history of Mobile Computing Architecture for mobile computing, Three tier architecture,\ndesign considerations for mobile computing, mobile computing through internet, Wireless\nnetwork architecture, Applications, Security, Concerns and Standards, Benefits, Future.\nEvolution of mobile computing.', 1, '2021-08-10', '0000-00-00'),
(121, 'Soft computing (BTCS-711)', 1, 121, 'Introduction to Soft Computing, Historical Development, Definitions, advantages and\ndisadvantages, solution of complex real life problems, Soft Computing and its Techniques, Soft\nComputing verses Hard Computing. Applications of Soft Computing in the Current industry.', 1, '2021-08-10', '0000-00-00'),
(122, 'Quantum Computing (BTCS-715)', 1, 122, 'Motivation for studying Quantum Computing, Major players in the industry (IBM, Microsoft,\nRigetti, D-Wave etc.), Origin of Quantum Computing, Overview of major concepts in Quantum\nComputing: Qubits and multi-qubits states, Bra-ket notation, Bloch Sphere representation,\nQuantum Superposition, Quantum Entanglement.', 1, '2021-08-10', '0000-00-00'),
(123, 'Virtual Reality (BTCS-716)', 1, 123, '\n\nVirtual Reality and Virtual Environment: Introduction, Computer\ngraphics, Real time computer graphics, Flight Simulation, Virtual\nenvironment requirement, benefits of virtual reality, Historical development\nof VR, Scientific Landmark. 3D Computer Graphics: Introduction, The Virtual\nworld space, positioning the virtual observer, the perspective projection,\nhuman vision, stereo perspective projection, 3D clipping, Colour theory,\nSimple 3D modelling, Illumination models, Reflection models, Shading algorithms,\nRadiosity, Hidden Surface Removal, Realism-Stereographic image.', 1, '2021-08-10', '0000-00-00'),
(124, 'Project (BTCS-706)', 1, 124, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(125, 'Computer Graphics and Multimedia (BTCS-503)', 1, 125, 'What is Computer Graphics?, Where Computer Generated pictures are used, Elements of\nPictures created in Computer Graphics Graphics display devices,Graphics input primitives and\nDevices.Introduction to openGL:- Getting started Making pictures, Drawing basic\nprimitivesSimple interaction with mouse and keyboard', 1, '2021-08-10', '0000-00-00'),
(126, 'Mobile and Cloud Security (BTICS-701)', 1, 126, 'Cloud Benefits, Business scenarios, Cloud Computing Evolution, cloud vocabulary, Essential\nCharacteristics of Cloud Computing, Cloud deployment models, Cloud Service Models, Multi Tenancy, Approaches to create a barrier between the Tenants, cloud computing vendors, Cloud\nComputing threats, Cloud Reference Model, The Cloud Cube Model, Security for Cloud\nComputing, How Security Gets Integrated.', 1, '2021-08-10', '0000-00-00'),
(127, 'Cyber Investigation and Digital Forensic (BTICS-702)', 1, 127, 'Computer Forensics Fundamentals, Benefits of Computer Forensics, Computer Crimes,\nComputer Forensics Evidence and the Courts, Legal Concerns and Privacy Issues', 1, '2021-08-10', '0000-00-00'),
(128, 'DISTRIBUTED SYSTEM (BTIT-713)', 1, 128, 'Introduction, Examples of Distributed Systems, Resource Sharing and the Web, Challenges.\nSystem Models: Introduction, Architectural Models- Software Layers, System Architecture,\nVariations, Interface and Objects, Design Requirements for Distributed Architectures,\nFundamental Models- Interaction Model, Failure Model, Security Model.', 1, '2021-08-10', '0000-00-00'),
(130, 'APPLIED PHYSICS(BTPH-101)', 2, 2, 'Solid State Physics:\nFree electron model, Qualitative Analysis of Kronig Penney Model, ffective mass, Fermi\nlevel for Intrinsic and Extrinsic semiconductors, P-N junction diode, Zener diode, Tunnel\ndiode, Photodiode, Solar- cells, Hall Effect, Introduction to Superconductivity, Meissner\neffect, Type I & II Superconductors', 1, '2021-08-10', '0000-00-00');
INSERT INTO `syllabus` (`id`, `name`, `unit_id`, `subject_id`, `syllabus_detail`, `status`, `created_at`, `updated_at`) VALUES
(131, 'Introduction to Computer Science and Engineering(BTCS-102)', 2, 3, 'The Operating System:The Graphical User Interface (GUI), Definition of Operating System, Objective, Types and\nfunctions of Operating Systems, Windows Operating System, Installing MS Windows,\nWorking with Windows Operating System, System Tools and Applications in windows, MSDOS (Disk Operating System), Basic DOS commands, Switching Between DOS and\nWindows, Comparison of DOS and Windows, System Tools and Applications in MS-DOS,\nOther Operating Systems Unix, Linux etc.', 1, '2021-08-10', '0000-00-00'),
(132, 'Digital Logic and Circuit Design(BTEC-104)', 2, 4, 'Boolean algebra and Logic gates:\nIntroduction, Logic operations, Axioms and laws of Boolean algebra, Demorgan’s theorem,\nBoolean functions, Canonical and standard forms. Logic gates and their applications,\nuniversal gates, NAND-NOR implementation of logic functions. Minimization techniques\nfor logic functions-K-map, Tabular / Quine McCluskey method.', 1, '2021-08-10', '0000-00-00'),
(133, 'Principles of \'C\' language (BTCS-104)', 2, 5, 'Introduction to \'C\' Language:\nCharacter Set.Variables and Identifiers, Built-In Data Types. Variable Definition, Arithmetic\nOperators and Expressions, Constants And Literals, Simple Assignment Statement, Basic\nInput/Output Statement, Decision Making Within A Program, Conditions, Relational Operators,\nLogical Connectives, If Statement, If-Else Statement, Loops: While Loop, Do While, For Loop.\nNested Loops, Infinite Loops, Switch Statement, Structured Programming.', 1, '2021-08-10', '0000-00-00'),
(134, 'Programming Skills with \'C\' (BTCS-108)', 2, 6, 'Programming using C:\nC data types, int, char, float etc, C Expressions, Arithmetic Operation, Relational and Logic\nOperations, C Assignment Statements, Extension of Assignment of The Operations, CPrimitive Input Output Using getchar and putchar, Exposure to the scanf and printf\nfunctions, C Statements, conditional executing using if, else, Optionally Switch and Break\nStatements may be mentioned.', 1, '2021-08-10', '0000-00-00'),
(135, 'Web Development Lab-I(HTML & XML) (BTIT-307)', 2, 7, 'HTML5:\nIntroduction of HTML5, Browser suppots, Migration from HTML4 to HTML5, New Elements\nin HTML5, HTML5 different parts layout of a web page, HTML5 Graphics: Canvas, SVG,\nHTML Media Tags: Inserting audio files, Inserting video files, Screen control attributes, Media\ncontrol attributes, HTML Object.', 1, '2021-08-10', '0000-00-00'),
(136, 'Software Foundation and Programming ( 1. Clean Coding; 2. Javascript; 3. NodeRed; 4. NodeJS) (BTIBM-105)', 2, 8, 'Objects\nLearn about data abstraction.\nUnderstand the data and object antisymmetric.\nJavascript Basics\nNature of JavaScript language\nUnderstand JavaScript primitive types.\nJavascript objects\nUnderstand Java Script Array Objects\nUnderstand Java Script Date Objects\nUnderstand Java Script Error Objects', 1, '2021-08-10', '0000-00-00'),
(137, 'Software Foundation and Programming 1 (with \'C\') (BTCS-105)', 2, 9, 'Evaluation of Computing, The Amazing difference Engine, Method of Finite difference,\nEvaluation of Modern Computing, The Abstract Turing Machine, A Simple TM Example,\nVon Newman Architecture, FORTRAN Beginning of Hill, Internet, Where is our world\nHeading Today.', 1, '2021-08-10', '0000-00-00'),
(138, 'Red Hat Administration-I (RH-124)', 2, 10, 'Not syllabus Specified', 1, '2021-08-10', '0000-00-00'),
(139, 'Computer Peripherals and Interfaces ( BTCS-204 )', 2, 11, 'Motherboard Controllers and System Resources, I/O System Bus: ISA, MCA, ELSA, VESA\nlocal bus, PCI, AGP, PCIX, Onboard I/O devices, Chipsets, ROM BIOS, ROM POST,\nCMOS settings, Motherboard Form factor: AT and ATX Motherboard, LPX and NLX\nform factor.', 1, '2021-08-10', '0000-00-00'),
(140, 'Mobile Application Development-I (BTCSMOB-101)', 2, 12, 'Installation of Xcode ,Working with Xcode, create a simple program and execute it using Xcode\n, Working with swift playgrounds , create a simple program and execute it using swift\nplaygrounds.', 1, '2021-08-10', '0000-00-00'),
(141, 'Principles of Electrical Engineering (BTCSH-104)', 2, 13, 'Current-Voltage Relations of the Electric Network by Mathematical Equations to Analyze the\nNetwork (Thevenin’s Theorem, Norton\'s Theorem, Maximum Power Transfer Theorem)\nSimplifications of Networks using Series-Parallel, Star/Delta Transformation. Superposition\nTheorem.', 1, '2021-08-10', '0000-00-00'),
(142, 'Physics for Computing Science (BTCSH-105)', 2, 14, 'Theory of Interference FringesTypes of Interference-Fresnel’s Prism-Newton’s Rings,\nDiffraction-Two kinds of DiffractionDifference between Interference and Diffraction-Fresnel’s\nHalf Period Zone and Zone PlateFraunhofer Diffraction at Single Slit-Plane Diffraction\nGrating. Temporal and Spatial Coherence.\nPolarization of light: Polarization - Concept of Production of Polarized Beam of Light from two\nSHM Acting at Right Angle; Plane, Elliptical and Circularly Polarized Light, Brewster’s Law,\nDouble Refraction.', 1, '2021-08-10', '0000-00-00'),
(143, 'Business Communication and Value Science – I (BTCSH-106)', 2, 15, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(144, 'Discrete Mathematics (BTCSH-101)', 2, 16, 'Abstract algebra: Set,\nRelation, Group, Ring, Field.', 1, '2021-08-10', '0000-00-00'),
(145, 'Statistics, Probability and Calculus (BTCSH-102)', 2, 17, 'Classification and Tabulation of Univariate Data, Graphical Representation, Frequency Curves.\nDescriptive Measures - Central Tendency and Dispersion. Bivariate Data. Summarization,\nMarginal and Conditional Frequency Distribution.', 1, '2021-08-10', '0000-00-00'),
(146, 'Fundamentals of Computer Science (BTCSCS-103)', 2, 18, 'Statements and Blocks, If-Else-If, Switch, Loops – While, do, For, Break and Continue, Goto\nLabels, structured and un- structured programming', 1, '2021-08-10', '0000-00-00'),
(147, 'Mathematics-II ( BTMACS-201)', 2, 19, 'Ordinary Differential Equations: First order linear and nonlinear ordinary differential\nequations, exactness and integrating factors. Ordinary linear differential equations of n-th\norder, solutions of homogeneous and non-homogeneous equations. Operator method.\nMethod of undetermined coefficients and variation of parameters.', 1, '2021-08-10', '0000-00-00'),
(148, 'Computer Peripherals and Interfaces ( BTCS-204 )', 2, 20, 'Motherboard Controllers and System Resources, I/O System Bus: ISA, MCA, ELSA, VESA\nlocal bus, PCI, AGP, PCIX, Onboard I/O devices, Chipsets, ROM BIOS, ROM POST,\nCMOS settings, Motherboard Form factor: AT and ATX Motherboard, LPX and NLX', 1, '2021-08-10', '0000-00-00'),
(149, 'Data Structure and Algorithms (BTCS-403)', 2, 21, 'Linked List as an ADT, Linked List Vs. Arrays, Dynamic Memory Allocation & De allocation for a Linked List, Types of Linked List: Circular & Doubly Linked List. Linked\nList operations: All possible insertions and deletion operations on all types of Linked list\nReverse a Single Linked List; Divide a singly linked list into two equal halves, Application of\nLinked List.\n', 1, '2021-08-10', '0000-00-00'),
(150, 'Computer System Organization ( BTCS-404 )', 2, 22, 'Control unit operations - Address Sequencing & Micro operations, Hardwired control unit,\nMicro and Nano programmed control unit, Control Memory, Micro Instruction formats,\nMicro program sequencer, Microprogramming.', 1, '2021-08-10', '0000-00-00'),
(151, 'Object Oriented Programming ( BTCS-305)', 2, 23, 'Relationshipsbetween classes, Association of objects, Types of Association, Recursive\nAssociation, Multiplicities, Navigability, Namedassociation, Aggregation of objects. Types of\nAggregation, Delegation, Modeling Association and Aggregation.', 1, '2021-08-10', '0000-00-00'),
(152, 'Programming Skills with \'C++\' ( BTCS-208 )', 2, 24, 'Tokens , Keywords, Identifiers and Constants, C++ data types,\nVariables: Declaration, Dynamic initialization of variables,\nReference variables. Operators in C++ : Scope\nresolution operator, Member Deferencing Operators,\nMemory Management Operators,\nManipulators, Type cast operators,\nExpressions and Control Structures.\nFunctions: The main() function,\nFunction Prototyping, Call by reference,\nReturn by reference, Inline\nfunction, Function Overloading', 1, '2021-08-10', '0000-00-00'),
(153, 'Communication Skills ( HUCS-101 )', 2, 25, 'Grammar and usage- Parts of Speech, Tenses, S-V Agreement, Preposition, Article.', 1, '2021-08-10', '0000-00-00'),
(154, 'Design Thinking ( BTIBM-203)', 2, 26, 'MODELING PROCESS List and describe gateways as they are used in IBM Process\nDesigner, List and describe intermediate event types that are used in IBM Process Designer,\nModel a business process escalation path with an attached timer intermediate event,\nDescribe the Playback 0 validation goals and requirements, Validate that a process model\nmeets Playback 0 goals and Requirements, Describe IBM Business Process Manager\nproduct components, Identify the integrations with other IBM products.', 1, '2021-08-10', '0000-00-00'),
(155, 'Agile Development Methodologies (DevOps + Agile) (BTIBM-202)', 2, 27, 'Scrum: Scrum Foundation, Scrum Team, Roles of Scrum Team, Sprints. Scrum Artifacts:\nProduct Backlog, Sprit Backlog,Sprint Burndown chart, Impediment List,Product\nIncrement.', 1, '2021-08-10', '0000-00-00'),
(156, 'Agile Development Methodologies (BTIBM-201)', 2, 28, 'Scrum – Deep Dive, Foundations of Scrum, Scrum Diagram, Scrum Team, Roles in Scrum\nTeam, Sprints, Definition of Ready, Scrum Artifacts, Product Backlog, Sprint Backlog,\nSprint Burndown chart, Impediments List, Product Increment, Scrum Ceremonies, Sprint\nPlanning, Daily Scrum Meeting, Product Backlog Refinement (PBR)/Grooming, Sprint\nReview / Demonstration meeting, Sprint Retrospective, Maven, Introduction, Simple\nSoftware Setup, Maven Project Creation and Key Concepts, Jira Introduction, How to\nCreate Scrum & Kanban Boards.', 1, '2021-08-10', '0000-00-00'),
(157, 'Red Hat Administration-II (RH-134)', 2, 29, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(158, 'Mobile Application Development-II (BTCSMOB-201)', 2, 30, 'Closure Expressions, Inferring Type From Context, Implicit Returns from Single-Expression\nClosures, Shorthand Argument Names, Operator Methods, Trailing Closures, Capturing\nValues, Escaping Closures.Enumeration : Enumeration , Enumeration with Switch Statement,\nIterating Enumeration Cases , Associated Values, Raw Values, Recursive Enumerations.', 1, '2021-08-10', '0000-00-00'),
(159, 'Principles of Electronics Engineering (BTCSH-110)', 2, 31, 'Formation of PNP / NPN junctions; transistor mechanism and principle of transistors, CE, CB,\nCC configuration, transistor characteristics: cut-off active and saturation mode, transistor\naction, injection efficiency, base transport factor and current amplification factors for CB and\nCE modes. Biasing and Bias stability: calculation of stability factor', 1, '2021-08-10', '0000-00-00'),
(160, 'Fundamentals of Economics (BTCSH-111)', 2, 32, 'Consumers’ and Producers’ Surplus — Price Ceilings and Price Floors; Consumer Behaviour\n— Axioms of Choice — Budget Constraints and Indifference Curves; Consumer’s Equilibrium\n— Effects of a Price Change, Income and Substitution Effects —Derivation of a Demand Curve;', 1, '2021-08-10', '0000-00-00'),
(161, 'Business Communication and Value Science – II (BTCSH-112)', 2, 33, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(162, 'Linear Algebra (BTCSH-107)', 2, 34, 'Vectors and linear combinations; Rank of a matrix; Gaussian\nelimination; LU Decomposition; Solving Systems of Linear Equations using the tools of\nMatrices.', 1, '2021-08-10', '0000-00-00'),
(163, 'Statistical Methods (BTCSH-108)', 2, 35, 'Scatter diagram. Linear regression and correlation. Least squares method. Rank correlation.\nMultiple regression & multiple correlation, Analysis of variance (one way, two way with as well\nas without interaction). Estimation: Point estimation, criteria for good estimates (un-biasedness,\nconsistency), Methods of estimation including maximum likelihood estimation.', 1, '2021-08-10', '0000-00-00'),
(164, 'Discrete Structures (BTIT-401)', 2, 36, 'Proposition Logic, Basic Logic, Logical Connectives, Truth Tables, Tautologies,\nContradiction, Normal Forms (Conjunctive and Disjunctive), Modus Ponens and Modus\nTollens, Validity, Predicate Logic, Universal and Existential Quantification. Notion of\nProof: Proof by Implication, Converse, Inverse, Contrapositive, Negation, and\nContradiction, Direct Proof, Proof by Using Truth Table, Proof by Counter Example', 1, '2021-08-10', '0000-00-00'),
(165, 'Data Communication (BTCS-302)', 2, 37, 'Data Communication (BTCS-302)', 1, '2021-08-10', '0000-00-00'),
(166, 'Analysis and Design of Algorithms ( BTIT-305)', 2, 38, 'Unipolar, Polar, Bipolar, Line and Block Codes. Multiplexing: Introduction and History, FDM,\nTDM, WDM, Synchronous and Statistical TDM.Synchronous and Asynchronous transmission,\nSerial and Parallel Transmission.', 1, '2021-08-10', '0000-00-00'),
(167, 'Principles of Programming Languages (BTCS-303)', 2, 39, 'Introduction, Primitive, Character, User Defined, Array, Associative, Record, Union, Pointer\nand Reference Types, Design and Implementation Uses Related to these Types. Names,\nVariable, Concept of Binding, Type Checking, Strong Typing, Type Compatibility, Named\nConstants, Variable Initialization.', 1, '2021-08-10', '0000-00-00'),
(168, 'Introduction to Core Java (BTIT-309)', 2, 40, 'Constructors, Inheritance, Packages and Interfaces, Access Specifier, Enumerations, Auto\nboxing, and Annotations (Metadata) Garbage collection, Nested Classes, Inner Classes', 1, '2021-08-10', '0000-00-00'),
(169, 'Technical Presentation Skills (BTCS-610)', 2, 41, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(170, 'Web Development Lab-II (PHP/JSP) ( BTIT-407)', 2, 42, 'Apply Various Inbuiltvariable(Gettype, Settype, Isset,\nStrval, Floatval, Intval,Print_R), String(Chr,Ord, Strtolower,\nStrtoupeer, Strlen, Ltrim, Rtrim, Trim, Substr, Strcmp,\nStrcasecmp, Ctrops, Strops, Stristr,Str_Replace, Strrev,\nEcho, Print), Math(Abs, Ceil, Floor, Round, Fmod, Min, Max, Pow,\nSqrt, Rand),Date (Date, Getdate, Setdate, Checkdate, Time, Mktime),\nArray(Count, List, In_Array, Current, Next,Previous, End, Each, Sort,\nArray_Merge, Array_Reverse), File Functions(Fopen, Fread, Fwrite,\nFclose)in Programming .', 1, '2021-08-10', '0000-00-00'),
(171, 'Cloud Computing: Project Based Learning (BTIBM-401)', 2, 43, '\nAPI PLATFORM REVOLUTION\n• Cloud Culture of Change\n• API Platforms Landscape\n• APIs driving the Cloud platform revolution\n• Summary & resources', 1, '2021-08-10', '0000-00-00'),
(172, 'Unix and Shell Programming Lab (BTIT-406)', 2, 44, 'The File System, cat, cp, rm, mv, more, file, ls, wc, pg, cmp, comm, diff, gzip, tar, zip, df, du,\nmount, umount, chmod, The vi editor ,security by file Permissions. Networking commands:\nping, telnet, ftp, finger, arp, rlogin. The C compiler, vi editor, compiler options, and run the\nprograms.', 1, '2021-08-10', '0000-00-00'),
(173, 'Computational Learning (AI) (BTAI-301)', 2, 45, 'Distributions, Estimator Bias, Discrete Distributions, Continuous Distributions, Multivariate\nDistributions, Multivariate Gaussian, Exponential Family, TheKullback-Leibler Divergence.\nMixture Models: The Gaussian Mixture Model.', 1, '2021-08-10', '0000-00-00'),
(174, 'Object Oriented Programming Using Java (BTCS-308)', 2, 46, '\n\nJAVA Classes with Object Oriented Approach Create Java classes that\nimplement an object oriented design, Apply Java language constructs\nthat enable and enforce OO-related concepts such as data encapsulation,\nstrict typing and type conversion, inheritance, and polymorphism. Use\nJava syntax to develop applications in Java, Use inheritance and interfaces\nin Java applications, Refactor Java code.', 1, '2021-08-10', '0000-00-00'),
(175, 'RedHat Administration-III (RH254)', 2, 47, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(176, 'Introduction to Information Technology (BTIT-101)', 2, 48, 'Introduction, File Oriented Approach and Database Approach, Data Models, Architecture of\nDatabase System, Introduction and Working of Internet, Introduction to Network Protocol and\nTopologies. Types of Network: ISO-OSI Model, Functions of Different Layers. Internet\nWorking Concepts, Devices, TCP/IP Model, LAN, WAN, Web Browser.', 1, '2021-08-10', '0000-00-00'),
(177, 'Cyber Ethics and Social Media Analysis(ICS) ( BTICS-301)', 2, 49, 'Crime Case Study: Ethics, Legal Developments, Cyber security in Society, Security in cyber\nlaws case studies, General Law and Cyber Law-a Swift Analysis. Private ordering solutions,\nRegulation and Jurisdiction for global Cyber security, Copy Right source of risks, Pirates,\nInternet Infringement, Fair Use, Postings, and Criminal Liability.', 1, '2021-08-10', '0000-00-00'),
(178, 'Technical Presentation Skills (BTCS-610)', 2, 50, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(179, 'Mobile App Development III iOS (BTCSMOB-301)', 2, 51, 'Common system views configuration, Label(UILabel),Image view,Text view,Scroll view, Table\nview, Toolbars(UIToolbar), Navigation bars, tab bars, Controls, Button, Segmented controls,\nSliders, Switches, Date pickers, UIKit User Interface Catalog, Displaying data: Content mode,\nUnexpected Clipping.', 1, '2021-08-10', '0000-00-00'),
(180, 'Object Oriented Programming (BTCSCS-203)', 2, 52, 'Single line comments, Local variable declaration within function scope, function declaration,\nfunction overloading, stronger type checking, Reference variable, parameter passing – value vs\nreference, passing pointer by value or reference, #define constant vs const, Operator new and\ndelete, the typecasting operator,Inline Functions in contrast to macro, default arguments', 1, '2021-08-10', '0000-00-00'),
(181, 'Computational Statistics (BTCSCS-204)', 2, 53, 'Assumptions of Multivariate Regression Models, Parameter estimation, Multivariate Analysis\nof variance and covariance Discriminant Analysis: Statistical background, linear discriminant\nfunction analysis, Estimating linear discriminant functions and their properties.', 1, '2021-08-10', '0000-00-00'),
(182, 'Software Engineering (BTCSCS-205)', 2, 54, '\n\n\nBasic concepts of life cycle models – different models\nand milestones; software project planning\n–identification of activities and resources; concepts of\nfeasibility study; techniques for estimation ofschedule\nand effort; software cost\nestimation models and concepts of software engineeringeconomics;\ntechniques of software project control and reporting;\nintroduction to measurement of software size;\nintroduction to the concepts of risk and its\nmitigation; configuration management.', 1, '2021-08-10', '0000-00-00'),
(183, 'Financial Management (BTCSMS-206)', 2, 55, 'Bond Valuation, Preferred Stock Valuation , Common Stock Valuation,Concept of Yield and\nYTM. Risk & Return: Defining Risk and Return, Using Probability Distributions to Measure\nRisk, Attitudes Toward Risk,Risk and Return in a Portfolio Context, Diversification, The\nCapital Asset Pricing Model (CAPM)\nengineeringeconomics; techniques of software project control and reporting; introduction to\nmeasurement of software size; introduction to the concepts of risk and its mitigation;\nconfiguration management.', 1, '2021-08-10', '0000-00-00'),
(184, 'Formal Language and Automata Theory (BTCSCS-201)', 2, 56, '\nRegular expressions and languages, deterministic finite\nautomata (DFA) and equivalence with\nregular expressions, nondeterministic finite automata\n(NFA) and equivalence with DFA, regular\ngrammars and equivalence with finite automata, properties of regular\nlanguages, Kleene’s theorem, pumping lemma for regular languages,\nMyhill-Nerode theorem and its uses,\nminimization of finite automata.\n', 1, '2021-08-10', '0000-00-00'),
(185, 'Computer Organization and Architecture (BTCSCS-202)', 2, 57, 'Signed number representation, fixed and floating point representations, character\nrepresentation. Computer arithmetic: Integer addition and subtraction, ripple carry adder,\ncarry look-ahead adder, etc. multiplication – shift-and-add, Booth multiplier, carry save\nmultiplier, etc. Division restoring and non-restoring techniques, floating point arithmetic, IEEE\n754 format.', 1, '2021-08-10', '0000-00-00'),
(186, 'Environment and Energy Studies (ML-301)', 2, 58, 'Living and Non - Living resources, water resources: use and over utilization of surface and\nground water, floods and droughts, Dams: benefits and problem, Mineral resources: use and\nexploitation, environmental effects of extracting and using mineral resouces, Land resources:\nForest resources, Energy resources: growing energy needs, renewable energy source, case\nstudies.', 1, '2021-08-10', '0000-00-00'),
(187, 'Computer Networks(BTIT-502)', 2, 59, 'Need, Services Provided, Framing, Flow Control, Error control. Data Link Layer Protocol:\nElementary & Sliding Window protocol: 1-bit, Go-Back-N, Selective Repeat, Hybrid ARQ. Bit\noriented protocols: SDLC, HDLC, BISYNC, LAP and LAPB.', 1, '2021-08-10', '0000-00-00'),
(188, 'Operating Systems (BTCS-502)', 2, 60, 'Process Model, Creation, Termination, States & Transitions,\nHierarchy, Context Switching, Process Implementation, Process Control\nBlock, Basic System calls- Linux & Windows. Basic concepts, classification,\nCPU and I/O bound, CPU scheduler- short, medium, long-term, dispatcher,\nscheduling:- preemptive and non-preemptive, Static and Dynamic Priority\nCriteria/Goals/Performance Metrics, scheduling algorithms- FCFS, SJFS,\nshortest remaining time, Round robin, Priority scheduling, multilevel queue\nscheduling, multilevel feedback queue scheduling', 1, '2021-08-10', '0000-00-00'),
(189, 'Advanced Java Programming (BTCS-409)', 2, 61, 'Java Servlet Overview, Servlet Interface, Request, Servlet context, response, Session,\nDispatching request, Web Application', 1, '2021-08-10', '0000-00-00'),
(190, 'Unix and Shell Programming Lab (BTIT-406)', 2, 62, 'The File System, cat, cp, rm, mv, more, file, ls, wc, pg, cmp, comm, diff, gzip, tar, zip, df, du,\nmount, umount, chmod, The vi editor ,security by file Permissions. Networking commands:\nping, telnet, ftp, finger, arp, rlogin. The C compiler, vi editor, compiler options, and run the\nprograms.', 1, '2021-08-10', '0000-00-00'),
(191, 'Mobile App Development Lab (BTIT-306)', 2, 63, 'Mobile OS Architectures:Comparing and Contrasting architectures of all three – Android, iOS\nand Windows - Underlying OS (Darwin vs. Linux vs. Win 8) - Kernel structure and native level\nprogramming - Runtime (Objective-C vs. Dalvik vs. WinRT) - Approaches to Power\nManagement – Security.', 1, '2021-08-10', '0000-00-00'),
(192, 'Advanced Java (BTCS-307)', 2, 64, 'JDBC Programming :The JDBC Connectivity Model, Database Programming: Connecting to\nthe Database, Creating a SQL Query, Getting the Results, Updating Database Data, Error\nChecking and the SQLException Class, The SQLWarning Class, The Statement Interface,\nPreparedStatement, CallableStatement The ResultSet Interface, Updatable Result Sets, JDBC\nTypes, Executing SQL Queries, ResultSetMetaData, Executing SQL Updates, Transaction\nManagement', 1, '2021-08-10', '0000-00-00'),
(193, 'Application Development Using Python (BTIBM-403)', 2, 65, 'normal, raw and Unicode, String operators and expressions, Math operators and expressions,\nWriting to the screen, Reading from the keyboard and Indenting is significant.', 1, '2021-08-10', '0000-00-00'),
(194, 'Application Development and deployment using IOT (BTIBMC-701)', 2, 66, 'Missing', 1, '2021-08-10', '0000-00-00'),
(195, 'Database Management Systems ( BTCS-405)', 2, 67, 'Relational Model:\nStructure of Relational Databases, Relation , Characteristics of Relations, Domains, Tuples ,\nRelational schema and instance, Relational Algebra, Relational Algebra Operations (select,\nproject, join and its type, union, intersection, set difference, Cartesian product, rename,\ndivision), Extended Relational Algebra Operations (Generalized Projection , Aggregate\nFunctions , Outer Join),\nRelational Calculus:\ntypes of relational calculus, tuple and domain oriented relational calculus, and its operation.', 1, '2021-08-10', '0000-00-00'),
(196, 'Advanced Java Programming (BTCS-409)', 2, 68, 'Java Servlet Overview, Servlet Interface, Request, Servlet context, response, Session,\nDispatching request, Web Application', 1, '2021-08-10', '0000-00-00'),
(197, 'Red Hat Application Development I - Java EE (JB-183)', 2, 69, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(198, 'System Programming (BTCS-410)', 2, 70, 'Process, Running a New Process, Process Termination, User & Groups, Sessions and Process\nGroups, Daemons, Process Scheduling, Process Priorities, Multithreading, Threading Models,\nConcurrency, Parallelism, and Races, Synchronization.', 1, '2021-08-10', '0000-00-00'),
(199, 'Mobile Application Development IV Android (BTCSMOB-401)', 2, 71, 'Android Resources, Activities, Activity Life Cycle, Services, Intent, Types of Intent, layouts,\nBuilding a basic app , Android Studio folder structure and Useful files ,Edit code , Creating an\nAndroid Virtual Device, Run the app in the emulator.', 1, '2021-08-10', '0000-00-00'),
(200, 'Database Management Systems (BTCSCS-210)', 2, 72, 'Entity-relationship model, network model, relational and object orienteddata models, integrity\nconstraints, data manipulation operations. Relational query languages: Relational algebra,\nTuple and domain relational calculus,SQL3, DDL and DML constructs, Open source and\nCommercial DBMS - MYSQL,ORACLE, DB2, SQL server.', 1, '2021-08-10', '0000-00-00'),
(201, 'Software Design with UML (BTCSCS-211)', 2, 73, 'Requirements Analysis Using Case Modeling\n• Analysis of system requirements.\n• Actor definitions.\n• Writing a case goal.\n• Use Case Diagrams.\n• Use Case Relationships.\nTransfer from Analysis to Design in the Characterization Stage: Interaction Diagrams.\n• Description of goal.\n• Defining UML Method, Operation, Object Interface, Class.\n• Sequence Diagram.\n• Finding objects from Flow of Events.\n• Describing the process of finding objects using a Sequence Diagram.\n• Describing the process of finding objects using a Collaboration Diagram.', 1, '2021-08-10', '0000-00-00'),
(202, 'Introduction to Innovation, IP Management and Entrepreneurship (BTCSIIE-212)', 2, 74, 'Building an Innovative Organization Creating new products and services, Exploiting open\ninnovation and collaboration, Use of innovation for starting a new venture Class Discussion Innovation: Co-operating across networks vs. ‘go-it-alone’ approach', 1, '2021-08-10', '0000-00-00'),
(203, 'Business Communication and Value Science – III (BTCSIIE-213)', 2, 75, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(204, 'Operations Research (BTCSMS-214)', 2, 76, 'Linear programming – Examples from industrial cases, formulation & definitions, Matrix form.\nImplicit assumptions of LPP. Some basic concepts and results of linear algebra – Vectors,\nMatrices, LinearIndependence/Dependence of vectors, Rank, Basis, System of linear eqns.,\nHyperplane, Convex set,Convex polyhedron, Extreme points, Basic feasible solutions.\nGeometric method: 2-variable case, Special cases – infeasibility, unboundedness, redundancy\n&degeneracy, Sensitivity analysis. Simplex Algorithm – slack, surplus & artificial variables,\ncomputational details, big-M method,identification and resolution of special cases through\nsimplex iterations. Duality – formulation, results, fundamental theorem of duality, dual-simplex\nand primaldualalgorithms.\n\n\n\n', 1, '2021-08-10', '0000-00-00'),
(205, 'Operating Systems (BTCSCS-209)', 2, 77, 'Foundation and Scheduling objectives, Types of Schedulers,\nScheduling criteria:\nCPU utilization, Throughput, Turnaround Time, Waiting Time, Response Time. Scheduling\nalgorithms: Pre-emptive and non-pre-emptive, FCFS, SJF, RR; Multiprocessorscheduling: Real\nTime scheduling: RM and EDF.\n', 1, '2021-08-10', '0000-00-00'),
(206, 'Computer Graphics and Multimedia (BTCS-503)', 2, 78, 'DDA line drawing algorithm, parallel drawing algorithmBresenham’s drawing algorithm with\nexample. Circle and Ellipse generating algorithms:-Mid-point Circle algorithm with example\nMid-point Ellipse algorithmMid-point Ellipse algorithm with example Parametric Cubic\nCurves:- Bezier curvesB-Spline curves Filled Area Primitives:-Scan line polygon fill algorithm,\nPattern fill algorithm Inside-Outside Tests, Boundary fill algorithms, Flood fill algorithms', 1, '2021-08-10', '0000-00-00'),
(207, 'Software Engineering and Project Management (BTCS-504)', 2, 79, 'Requirement Sources and Elicitation Techniques, Analysis Modeling for Function-oriented and\nObject-oriented Software Development, Use case Modeling, System and Software Requirement\nSpecifications, Requirement Validation, Traceability.', 1, '2021-08-10', '0000-00-00'),
(208, 'Artificial Intelligence (BTCS-511)', 2, 80, 'Search Algorithms: Random search, Search with closed and open list, Depth first and\nBreadth first search, Heuristic search, Best first search, A* algorithm, Game Search.', 1, '2021-08-10', '0000-00-00'),
(209, 'CYBER AND NETWORK SECURITY (BTIT-603)', 2, 81, 'Introduction to Cyber offence, How Criminal plan the attack, Social Engineering, Cyber\nstalking, Cyber café and cyber crime, Botnets: The fuel of cybercrime, Attack vector, cloud\ncomputing. Cyber crime: Mobile and Wireless devices, Proliferation of Mobile and Wireless\nDevices, Trends in Mobility, Credit Card Frauds in Mobile and Wireless Computing Era,\nSecurity Challenges Posed by Mobile Devices, Registry Setting for Mobile Devices,\nAuthentication Service Security, Attack on Mobile Phones.', 1, '2021-08-10', '0000-00-00'),
(210, 'WIRELESS COMMUNICATION NETWORKS (BTIT-511)', 2, 82, 'Cellular system, Hexagonal geometry cell and concept of frequency reuse, Channel Assignment\nStrategies Distance to frequency reuse ratio, Channel &co-channel interference reduction\nfactor, S/I ratio consideration and calculation for Minimum Cochannel and adjacent\ninterference, Hand off Strategies, Umbrella Cell Concept, Trunking and Grade of Service,\nImproving Coverage & Capacity in Cellular System-cell splitting, Cell sectorization, Repeaters,\nMicro cell zone concept, Channel antenna system design considerations.', 1, '2021-08-10', '0000-00-00'),
(211, 'MANAGEMENT INFORMATION SYSTEM (BTIT-513)', 2, 83, 'Introduction, Managing in the Internet Era, Managing Information Systems in Organization the IT interaction model, Challenges for the managerwhat information to build?-how much to\nspend on information systems?-what level of capabilities should be created with information\nsystems?-how centralized should the services be?-what security levels are required?-what is\ntechnology road map for the organization?', 1, '2021-08-10', '0000-00-00'),
(212, 'INFORMATION STORAGE AND MANAGEMENT (BTIT-611)', 2, 84, 'Intelligent disk subsystems overview, Contrast of integrands modular array, Component\nArchitecture of Intelligent disk subsystems, Disk physical structure components, properties,\nperformance, and specifications, RAID levels & parity algorithms, hot sparing, Front end to\nhost storage provisioning, mapping and operation.', 1, '2021-08-10', '0000-00-00'),
(213, 'ENTERPRISE RESOURCE PLANNING (BTIT-712)', 2, 85, '1. Business process Reengineering (BPR)\n2. Management Information System (MIS)\n3. Decision Support Systems (DSS) Executive Support Systems (ESS)\n4. Data Warehousing\n5. Data Mining\n6. Online Analytical Processing (OLTP)\n7. Supply Chain Management (SCM)\n8. Customer Relationship Management (CRM)', 1, '2021-08-10', '0000-00-00'),
(214, 'Programming with Python (BTCS-407)', 2, 86, 'Testing, Debugging. Structured Types, Mutability and Higher order Functions: Tuples, Lists\nand Mutability, Functions as Objects, Strings, Tuples and Lists, Dictionaries.', 1, '2021-08-10', '0000-00-00'),
(215, 'Scripting Languages (BTCS-607)', 2, 87, 'Definition, Operators of regular expression and their precedence, Algebraic laws for Regular\nexpressions, Kleen’s Theorem, Regular expression to FA, DFA to Regular expression, Arden\'s\nTheorem, Non Regular Languages, Pumping Lemma for regular Languages. Application of\nPumping Lemma, Closure properties of Regular Languages, Decision properties of Regular\nLanguages, FA with output: Moore and Mealy machine, Equivalence of Moore and Mealy\nMachine, Applications and Limitation of FA.', 1, '2021-08-10', '0000-00-00'),
(216, 'Big Data Technologies (BTIBMB-601)', 2, 88, 'Hadoop and HDFS The basic need for a big data strategy in terms of parallel reading of large\ndata files and internode network speed in a cluster, Hadoop Distributed File System\n(HDFS),function of the Name Node and Data Nodes in an Hadoop cluster, files are stored and\nblocks (\"splits\") are replicated. Hive , Sqoop.', 1, '2021-08-10', '0000-00-00'),
(217, 'Predictive Analytics (BTIBDA-501)', 2, 89, 'Business Understanding, Explore Data, Prepare Data, Understanding Data, Statistics and\nRepresentation Techniques, Data Transformation, Represent and transform Unstructured\nData, Data Transformation Tools.', 1, '2021-08-10', '0000-00-00'),
(218, 'Micro services Architecture and Implementation (BTIBM-601)', 2, 90, 'Introduction to NodeJs, Getting Started with NodeJs, Project Structure, Basic Routing, File\nsystem, View templates Serving static content, Handling HTTP and HTTPS, Connecting to\ndatabase, Mongo DB Installation and Database, Node Js Mongo driver, Performing CRUD\noperations, Connecting Pooling, Connecting Pooling using NodeJS mongo driver, Performing\nCRUD operations, Connecting Pooling, Connecting Pooling using NodeJS mongo driver.\n', 1, '2021-08-10', '0000-00-00'),
(219, 'Predictive Modelling (BTIBMA-501)', 2, 91, 'Data Preparation Phases of Data analytics: Business Understanding, Data Exploring &\nPreparation, Different tools of Statistics, Tools for Data Transformation, Visualization Methods\n& types of Data. CRISP-DM, KDD.', 1, '2021-08-10', '0000-00-00'),
(220, 'Cloud Computing (BTCS-701)', 2, 92, 'Cloud Computing TechnologyClient systems, Networks, server systems and security from\nservices perspectives, security and privacy issues; accessing the cloud with platforms and\napplications; Cloud storage', 1, '2021-08-10', '0000-00-00'),
(221, 'Computer Architecture and Microprocessor (BTCS-509)', 2, 93, 'Address Sequencing & Micro operations, Hardwired control unit, Micro and Nano\nprogrammed control unit, Control Memory, Micro Instruction formats, Micro program\nsequencer, Microprogramming.', 1, '2021-08-10', '0000-00-00'),
(222, 'RedHat Open Stack and Ansible (CLDO-507)', 2, 94, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(223, 'Network Security And Cryptography (BTICS-501)', 2, 95, 'Proxy Servers and Anonymizers, Firewall, Types of firewall, Password Cracking Techniques.\nCryptography: Concepts & Techniques: Introduction, Plaintext & Cipher text, Creaser Cipher,\nSubstitution Techniques, Substitution Boxes (SBoxes), Permutation Cipher, Transposition\nTechniques, Encryption & Decryption, Symmetric & Asymmetric key Cryptography, Key\nRange & Key Size.', 1, '2021-08-10', '0000-00-00'),
(224, 'Ethical Hacking Lab-1 (BTICS-502)', 2, 96, 'Casing the Establishment: What is foot printing, Internet Foot printing, Scanning,\nEnumeration, basic banner grabbing, Enumerating Common Network services .Use of NMAP\nTool. Case study: Network Security Monitoring. Securing permission: Securing file and folder\npermission, Using the encrypting file system, Securing registry permissions. Securing service:\nManaging service permission, Default services in windows 2000 and windows XP. UNIX: The\nQuest for Root, Remote Access vs Local access, Remote access, Local access, after hacking root.', 1, '2021-08-10', '0000-00-00'),
(225, 'Theory of Computation (BTCS-501)', 2, 97, 'Definition, Operators of regular expression and their precedence, Algebraic laws for Regular\nexpressions, Kleen’s Theorem, Regular expression to FA, DFA to Regular expression, Arden\'s\nTheorem, Non Regular Languages, Pumping Lemma for regular Languages. Application of\nPumping Lemma, Closure properties of Regular Languages, Decision properties of Regular\nLanguages, FA with output: Moore and Mealy machine, Equivalence of Moore and Mealy\nMachine, Applications and Limitation of FA.', 1, '2021-08-10', '0000-00-00'),
(226, 'Internet of Things (BTCS-602)', 2, 98, 'Hardware Components- Computing (Arduino, Raspberry Pi), Communication, Sensing,\nActuation, I/O interfaces. Software Components- Programming API’s (using\nPython/Node.js/Arduino) for Communication Protocols-MQTT, ZigBee, Bluetooth, CoAP,\nUDP, TCP.', 1, '2021-08-10', '0000-00-00'),
(227, 'Cloud Computing (BTCS-701)', 2, 99, 'Cloud Computing TechnologyClient systems, Networks, server systems and security from\nservices perspectives, security and privacy issues; accessing the cloud with platforms and\napplications; Cloud storage', 1, '2021-08-10', '0000-00-00'),
(228, 'Data Science (BTCS-608)', 2, 100, 'Toolkits using Python: Matplotlib, NumPy, Scikit-learn, NLTK, Visualizing Data: Bar Charts,\nLine Charts, Scatterplots, Working with data: Reading Files, Scraping the Web, Using APIs\n(Example: Using the Twitter APIs), Cleaning and Munging, Manipulating Data, Rescaling,\nDimensionality Reduction.', 1, '2021-08-10', '0000-00-00'),
(229, 'Simulation and Modeling (BTCS-612)', 2, 101, 'Types of System Simulation, Monte Carlo Method, comparison of analytical and Simulation\nmethods, Markov Model, Numerical Computation techniques for Continuous and Discrete\nModels, Distributed Lag Models, Cobweb Model. Continuous System models, Analog and\nHybrid computers, Digital-Analog Simulators, Continuous system simulation languages, Hybrid\nsimulation, Real Time simulations', 1, '2021-08-10', '0000-00-00'),
(230, 'Software Testing and Quality Assurance (BTCS-613)', 2, 102, 'White box testing techniques - Statement coverage - Branch Coverage - Condition coverage -\nDecision/Condition coverage - Multiple condition coverage - Dataflow coverage - Mutation\ntesting - Automated code coverage analysis', 1, '2021-08-10', '0000-00-00'),
(231, 'Block Chain (BTCS-618)', 2, 103, 'Bitcoin and Block chain: Creation of coins, Payments and double spending, Bitcoin Scripts,\nBitcoin P2P Network, Transaction in Bitcoin Network, Block Mining, Block propagation and\nblock relay. Working with Consensus in Bitcoin: Distributed consensus in open environments,\nConsensus in a Bitcoin network, Proof of Work (PoW) – basic introduction, Hashcash PoW,\nBitcoin PoW, Attacks on PoW and the monopoly problem, Proof of Stake, Proof of Burn and\nProof of Elapsed Time, The life of a Bitcoin Miner, Mining Difficulty, Mining Pool.', 1, '2021-08-10', '0000-00-00'),
(232, 'Robotics (BTCS-617)', 2, 104, 'Kinematic Modelling: Translation and Rotation Representation, Coordinate transformation,\nDH parameters, Jacobian, Singularity, and Statics Dynamic Modelling: Equations of motion:\nEuler-Lagrange formulation', 1, '2021-08-10', '0000-00-00'),
(233, 'IT WorkshopSciLab/MATLAB (BTIT-608)', 2, 105, 'If, else, and else if, switch and case, for, while, continue, break try - catch, return. COMMAND\nWINDOW: The format Function, Suppressing Output, Entering Long Statements, Command\nLine Editing', 1, '2021-08-10', '0000-00-00'),
(234, 'Minor Project (BTCS-606)', 2, 106, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(235, 'Object Oriented Analysis and Design (BTIT-604)', 2, 107, 'Object and class concepts, link and association, Generalization and Inheritance, Advanced class\nmodeling- aggregation, Abstract class meta data, constraints. State Modeling:Event, state,\nTransition and conditions, state diagram, state diagram behavior, concurrency, Relation of\nClass and State models. Interaction Modeling:Use case Models, sequence models, activity\nmodels', 1, '2021-08-10', '0000-00-00'),
(236, 'Micro services Architecture and Implementation (BTIBM-601)', 2, 108, 'Key features of NodeJS, Installation and Configuration, NodeJS Command Line, Sample\nProject using Node Express command prompt, Nodeclipse plugin, Sample Project using\nNodeclipse, Performing CRUD Operations,Key features of MongoDB, Connection Pooling using\nNodeJS Mongo driver,Dockerarchitecture,Virtual machines versus containers, about\ncontainers.', 1, '2021-08-10', '0000-00-00'),
(237, 'Big Data Engineering - Spark & Scala (BTIBMB-602)', 2, 109, 'Apache Spark and Scala Working with Spark RDD with Scala, Listing and describing the\narchitecture and components of the Spark unified stack, Understanding the principles of Spark\nprogramming, Listing and describing the Spark libraries, Launching and using Spark\'s Scala\nand Python shells, Understanding the nature and purpose of Apache Spark in the Hadoop\necosystem, Listing and describing the architecture and components of the Spark unified stack,\nDescribing the role of a Resilient Distributed Dataset (RDD), Understanding the principles of\nSpark programming, Listing and describing the Spark libraries, Launching and using Spark\'s\nScala and Python shells', 1, '2021-08-10', '0000-00-00'),
(238, 'Big Data Technologies (Hadoop) (BTIBMC-602)', 2, 110, 'The basic need for a big data strategy in terms of parallel reading of large data files and\ninternode network speed in a cluster, Hadoop Distributed File System (HDFS), function of the\nNameNode and DataNodes in a Hadoop cluster, files are stored and blocks (\"splits\") are\nreplicated. Hive, Sqoop\n', 1, '2021-08-10', '0000-00-00'),
(239, 'Artificial Intelligence (BTIBMC-601)', 2, 111, 'AI INDUSTRY ADOPTION APPROACHES AI Industry Impact, Autonomous\nVehicles, SmartRobotics, Future Workforce and AI, Applications of AI. Main focus of AI,\nSummary & Resources.', 1, '2021-08-10', '0000-00-00'),
(240, 'CYBER AND NETWORK SECURITY (BTIT-603)', 2, 112, 'Introduction to Cyber offence, How Criminal plan the attack, Social Engineering, Cyber\nstalking, Cyber café and cyber crime, Botnets: The fuel of cybercrime, Attack vector, cloud\ncomputing. Cyber crime: Mobile and Wireless devices, Proliferation of Mobile and Wireless\nDevices, Trends in Mobility, Credit Card Frauds in Mobile and Wireless Computing Era,\nSecurity Challenges Posed by Mobile Devices, Registry Setting for Mobile Devices,\nAuthentication Service Security, Attack on Mobile Phones.', 1, '2021-08-10', '0000-00-00'),
(241, 'Introduction to container Kubernete and RedHat OpenShift and JBOSS (DOJB-603)', 2, 113, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(242, 'Ethical Hacking Lab-II (BTICS-602)', 2, 114, 'System hacking methodology, steganography, steganalysis attacks, and covering tracks.\nDifferent types of Trojans, Trojan analysis, and Trojan countermeasures.', 1, '2021-08-10', '0000-00-00'),
(243, 'Concepts of System Security (BTICS-601)', 2, 115, 'hardware vulnerability, software vulnerability, data vulnerability, Security vulnerability\ndetection tools, and techniques, introduction of primary vulnerabilities in network. Multics:\nFundamentals, multics protection system models, multics reference model, multics security,\nmultics vulnerability analysis.', 1, '2021-08-10', '0000-00-00'),
(244, 'Human Values and Professional Ethics (BBAI-501)', 2, 116, 'Morality\n1. Definition, Moral Behaviour and Systems\n2. Characteristics of Moral Standards\n3. Values Vs Ethics Vs Morality\n4. Impression Formation and Management', 1, '2021-08-10', '0000-00-00'),
(245, 'Compiler Design ( BTCS-601)', 2, 117, 'Syntax Analysis: Role\nof the parser, Writing Grammars, Context-Free Grammars, Top Down parsing, Recursive\nDescent Parsing, Predictive Parsing, Bottom-up parsing, Shift Reduce Parsing, Operator\nPrecedent Parsing, LR Parsers, SLR Parser – Canonical LR Parser – LALR Parser.', 1, '2021-08-10', '0000-00-00'),
(246, 'OBJECT ORIENTED ANALYSIS AND DESIGN ( BTIT-604)', 2, 118, 'Object and class concepts, link and association, Generalization and Inheritance, Advanced class\nmodeling- aggregation, Abstract class meta data, constraints. State Modeling:Event, state,\nTransition and conditions, state diagram, state diagram behavior, concurrency, Relation of\nClass and State models. Interaction Modeling:Use case Models, sequence models, activity\nmodels', 1, '2021-08-10', '0000-00-00'),
(247, 'BIG DATA AND HADOOP (BTCS-702)', 2, 119, 'Hadoop ecosystem, Installing Hadoop Eco System and Integrate With Hive Installation,\nPigInstallation, Hadoop , Zookeeper Installation , Hbase Installation , , Sqoop Installation,\nInstalling Mahout Introduction to Hadoop , Hadoop components: MapReduce/Pig/Hive/HBase,\nLoading data into Hadoop, Getting data from Hadoop.', 1, '2021-08-10', '0000-00-00'),
(248, 'Next Generation Telecommunication Networks (BTCC-703)', 2, 120, 'Next Generation Networks (NGN), Principles and definition of an NGN, The NGN\narchitecture, Outline of technology choices, Network and implementation issues with NGN,\nNumbering & Addressing', 1, '2021-08-10', '0000-00-00'),
(249, 'Soft computing (BTCS-711)', 2, 121, 'Introduction to Fuzzy Logic, Crisp Sets, Fuzzy Sets, Fuzzy Relations, Membership Functions\nand features, Fuzzification, Methods of Membership Value Assignments, Defuzzification and\nmethods, Lambda cuts. Fuzzy Measure, Fuzzy Reasoning, Fuzzy Inference System.', 1, '2021-08-10', '0000-00-00'),
(250, 'Quantum Computing (BTCS-715)', 2, 122, 'Matrix Algebra: basis vectors and orthogonality, inner product and Hilbert spaces, matrices\nand tensors, unitary operators and projectors, Dirac notation, Eigen values and Eigen vectors.', 1, '2021-08-10', '0000-00-00'),
(251, 'Virtual Reality (BTCS-716)', 2, 123, 'Geometric Modelling: Introduction, From 2D to 3D, 3D space curves, 3D boundary\nrepresentation. Geometrical Transformations: Introduction, Frames of reference, Modelling\ntransformations, Instances, Picking, Flying, Scaling the VE, Collision detection. Generic VR\nsystem: Introduction, Virtual environment, Computer environment, VR technology, Model of\ninteraction, VR Systems.', 1, '2021-08-10', '0000-00-00'),
(252, 'Project (BTCS-706)', 2, 124, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(253, 'Computer Graphics and Multimedia (BTCS-503)', 2, 125, 'DDA line drawing algorithm, parallel drawing algorithmBresenham’s drawing algorithm with\nexample. Circle and Ellipse generating algorithms:-Mid-point Circle algorithm with example\nMid-point Ellipse algorithmMid-point Ellipse algorithm with example Parametric Cubic\nCurves:- Bezier curvesB-Spline curves Filled Area Primitives:-Scan line polygon fill algorithm,\nPattern fill algorithm Inside-Outside Tests, Boundary fill algorithms, Flood fill algorithms', 1, '2021-08-10', '0000-00-00'),
(254, 'Mobile and Cloud Security (BTICS-701)', 2, 126, 'Mobile system architectures, Overview of mobile cellular systems, GSM and UMTS Security\narchitecture & Attacks, Vulnerabilities in Cellular Services, Cellular Jamming, Attacks &\nMitigation, Security in Cellular VoIP Services, Mobile application security.', 1, '2021-08-10', '0000-00-00'),
(255, 'Cyber Investigation and Digital Forensic (BTICS-702)', 2, 127, 'Introduction to Digital Forensics, Forensic Software and Hardware, Analysis and Advanced\nTools, Forensic Technology and Practices, Forensic Ballistics and Photography, Face, Iris and\nFingerprint Recognition, Audio Video Analysis, Windows System Forensics, Linux System\nForensics, Network Forensics,Biometric Security.', 1, '2021-08-10', '0000-00-00'),
(256, 'DISTRIBUTED SYSTEM (BTIT-713)', 2, 128, 'System Model, Interprocess Communication, API for internet protocols, External data\nrepresentation and Multicast communication, Network virtualization: Overlay networks. Case\nstudy: MPI Remote Method Invocation and Objects: Remote Invocation, Introduction\nrequestreply protocols, Remote procedure call, Remote method invocation, Case study: Java\nRMI – Group communication, Publish-subscribe systems, Message queue, shared memory\napproaches Distributed objects, Case study: Enterprise Java Beans -from objects to\ncomponents.', 1, '2021-08-10', '0000-00-00'),
(258, 'APPLIED PHYSICS(BTPH-101)', 3, 2, 'Nuclear Physics:\nNuclear Structure & Properties Nuclear models: Liquid drop with semiempirical mass\nformula & shell model. Particle accelerators: Cyclotron, Synchrotron, Betatron. Counters\nand Detectors: Giger-Muller counters, Bainbridge Mass Spectrograph and Auston Mass\nSpectrograph.', 1, '2021-08-10', '0000-00-00'),
(259, 'Introduction to Computer Science and Engineering(BTCS-102)', 3, 3, 'Office Automation Tools-I:\nWord Processing Basics, Elements of word Processing and Working, MS-Office (Word,\nAccess, Outlook, Front page etc), Objectives, Starting MS-Word, MS-Word Screen and its\nComponents, Working with MS-Word, Menu Bar, Creating Documents, Using Templates,\nSaving a documents, Working with documents, Setting up pages of a document, Printing\nDocuments with different options, Using Tables and Columns, Object Linking and\nEmbedding, Hyperlink, Envelopes & Label Creation, Grammar & Spell Check, Mail\nMerge, Macro Creation, Previewing and Printing Documents.', 1, '2021-08-10', '0000-00-00'),
(260, 'Digital Logic and Circuit Design(BTEC-104)', 3, 4, 'Combinational logic:\nArithmetic circuits- Half adder, Full adder, Halfsubtractor, Full subtractor, Parallel and\nSerial adder, BCD adder, Multiplexer, De-multiplexer, Encoder & Decoder.', 1, '2021-08-10', '0000-00-00'),
(261, 'Principles of \'C\' language (BTCS-104)', 3, 5, 'One Dimensional Arrays:\nArray Manipulation; Searching, Insertion, Deletion of an Element from an Array; Finding the\nLargest/Smallest Element in an Array; Two Dimensional Arrays, Addition/Multiplication of Two\nMatrices, Transpose of a Square Matrix, Strings as Array of Characters, Address Operators,\nPointer Type Declaration, Pointer Assignment, Pointer Initialization, Pointer Arithmetic,\nFunctions And Pointers, Arrays And Pointers, Pointer Arrays.', 1, '2021-08-10', '0000-00-00');
INSERT INTO `syllabus` (`id`, `name`, `unit_id`, `subject_id`, `syllabus_detail`, `status`, `created_at`, `updated_at`) VALUES
(262, 'Programming Skills with \'C\' (BTCS-108)', 3, 6, 'Iterations and Subprograms:\nConcept of loops, Example of Loops in C Using for, while and do-while, Optionally continue\nmay be mentioned, One dimensional arrays and example of iterative programs using arrays,\n2-d arrays Use in matrix computations, Concept of Sub-programming, functions Example of\nfunctions, Argument passing mainly for the simple variables.', 1, '2021-08-10', '0000-00-00'),
(263, 'Web Development Lab-I(HTML & XML) (BTIT-307)', 3, 7, 'CSS:\nIntroduction of CSS, CSS Syntax CSS Id & Class. CSS Styling: styling Backgrounds, styling Text,\nstyling Fonts, styling Links, styling Lists, styling Tables. CSS Box Model: Border, Outline,\nMargin, Padding. CSS Advanced: Grouping/Nesting, Dimension, Display, Positioning, Floating,\nAlign, Pseudo-class, Pseudo-element, Navigation Bar, Image Gallery, Image capacity, Image\nSprites, Media Types, and Attribute Selectors.', 1, '2021-08-10', '0000-00-00'),
(264, 'Software Foundation and Programming ( 1. Clean Coding; 2. Javascript; 3. NodeRed; 4. NodeJS) (BTIBM-105', 3, 8, 'Javascript variables and Control statements\nUnderstand how to define JavaScript Variables.\nWork Java Script If statements .\nWork Java Script switch statements.\nWork JavaScript for and while loop statements.\nJavascript Functions\nDeclare a JavaScript function\nCreating custom objects with functions\nAdding functions to prototypes\nSelf-executing functions', 1, '2021-08-10', '0000-00-00'),
(265, 'Software Foundation and Programming 1 (with \'C\') (BTCS-105)', 3, 9, 'Types of Pointer, Pointer Arithmetic, Pointer in function, Call by Value, Call by Reference,\nPointer & amp, Passed 2D Array in Function, Command line Argument, Advantage,\ndisadvantage. Structure & Union File Input & output, Predefined File Object/Streams, FgetC\n& FputC, Printf and Scanf, Common errors Encountered in file handling, Text file Vs. Binary\nFile, Fread and Fwrite.', 1, '2021-08-10', '0000-00-00'),
(266, 'Red Hat Administration-I (RH-124)', 3, 10, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(267, 'Computer Peripherals and Interfaces ( BTCS-204 )', 3, 11, 'Power Supply Functions and Operations, Power Supply Quality and Specifications, Power\nSupply and Form factors, Ventilation and Cooling: Fan, Processor cooling, Temperature\nlimits, Power Problems and procedures, Power protection devices, Back-up power system.', 1, '2021-08-10', '0000-00-00'),
(268, 'Mobile Application Development-I (BTCSMOB-101)', 3, 12, 'Introduction of Swift, features of Swift ,Data types,constant and variables,opertaors ,Type\nAnnotations, Naming Constants and Variables, Printing Constants and Variables, Semicolons,\nIntegers: Integer Bounds ,Int, UInt. Floating-Point Numbers: Double ,Float. Type Safety and\nType Inference. Numeric Literals, Numeric Type Conversion, Integer Conversion, Integer and\nFloating-Point Conversion, Boolean.', 1, '2021-08-10', '0000-00-00'),
(269, 'Principles of Electrical Engineering (BTCSH-104)', 3, 13, 'AC Waveform Definitions, Form Factor, Peak Factor, Study of R-L, R-C,RLC Series Circuit,\nR-L-C Parallel Circuit, Phasor Representation in Polar and Rectangular form, Concept of\nImpedance, Admittance, Active, Reactive, Apparent and Complex Power, Power Factor, 3\nPhase Balanced AC Circuits (⅄-∆&⅄-⅄).', 1, '2021-08-10', '0000-00-00'),
(270, 'Physics for Computing Science (BTCSH-105)', 3, 14, 'Continuity Equation for Current Densities, Maxwell’s Equation in Vacuum and Non Conducting Medium. Quantum Mechanics: Introduction- Planck’s Quantum Theory- Matter\nWaves, De-Broglie Wavelength, Heisenberg’s Uncertainty Principle, Time Independent and\nTime Dependent Schrödinger’s Wave Equation, Physical Significance of Wave Function,\nParticle in a One Dimensional Potential Box, Heisenberg Picture.', 1, '2021-08-10', '0000-00-00'),
(271, 'Business Communication and Value Science – I (BTCSH-106)', 3, 15, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(272, 'Discrete Mathematics (BTCSH-101)', 3, 16, 'Combinatorics: Basic Counting, Balls And Bins\nProblems, Generating Functions, Recurrence Relations. Proof Techniques, Principle of\nMathematical Induction, Pigeonhole Principle.', 1, '2021-08-10', '0000-00-00'),
(273, 'Statistics, Probability and Calculus (BTCSH-102)', 3, 17, 'Concept Of Experiments, Sample Space, Event. Definition of Combinatorial Probability.\nConditional Probability, Bayes Theorem. Probability Distributions: Discrete & Continuous\nDistributions, Binomial, Poisson and Geometric Distributions, Uniform, Exponential, Normal,\nChi-Square, T, F Distributions.', 1, '2021-08-10', '0000-00-00'),
(274, 'Fundamentals of Computer Science (BTCSCS-103)', 3, 18, 'Basics of Functions, Parameter Passing and Returning Type, C main Return as Integer,\nExternal, Auto, Local, Static, Register Variables, Scope Rules, Block Structure, Initialization,\nRecursion, Preprocessor, Standard Library Functions and Return Types', 1, '2021-08-10', '0000-00-00'),
(275, 'Mathematics-II ( BTMACS-201)', 3, 19, 'Introduction to Interpolation; Calculus of Finite Differences; Finite Difference and Divided\nDifference Tables; Newton‐Gregory Polynomial Form; Lagrange Polynomial Interpolation;\nApproximation by Least Square Method. Numerical Differentiation and Integration:\nDiscrete Approximation of Derivatives: Forward and Backward Difference Forms,\nNumerical Integration, Simple Newton‐Cotes Rules: Trapezoidal and Simpson\'s (1/3) Rules;\nWeddle’s Rule.', 1, '2021-08-10', '0000-00-00'),
(276, 'Computer Peripherals and Interfaces ( BTCS-204 )', 3, 20, 'Power Supply Functions and Operations, Power Supply Quality and Specifications, Power\nSupply and Form factors, Ventilation and Cooling: Fan, Processor cooling, Temperature\nlimits, Power Problems and procedures, Power protection devices, Back-up power system.', 1, '2021-08-10', '0000-00-00'),
(277, 'Data Structure and Algorithms (BTCS-403)', 3, 21, 'The Stack as an ADT, Stack operation, Array Representation of Stack, Link Representation\nof Stack, Application of stack – Recursion, Polish Notation . Types of Recursion, problem\nbased on Recursion: Tower of Hanoi. The Queue :The Queue as an ADT, Queue operation,\nArray Representation of Queue, Linked Representation of Queue, Types of Queue :Circular\nQueue & Dequeue, Introduction of Priority Queue, Application of Queues.', 1, '2021-08-10', '0000-00-00'),
(278, 'Computer System Organization ( BTCS-404 )', 3, 22, 'I/O Systems, Modes of data transfer – program controlled, interrupt driven and direct\nmemory access, Interrupt structures, I/O Interface, I/O processor, Introduction to 8085,\n8085 I/O structure, 8085 instruction set and basic programming.', 1, '2021-08-10', '0000-00-00'),
(279, 'Object Oriented Programming ( BTCS-305)', 3, 23, 'Inheritance and Polymorphism, Types of Polymorphism, Static and Dynamic Polymorphism,\nOperator And Method Overloading, Inherited Methods, Redefined Methods, The Protected\nInterface, Abstract Methods and Classes, Public and Protected Properties, Private Operations,\nMultiple Inheritance.', 1, '2021-08-10', '0000-00-00'),
(280, 'Programming Skills with \'C++\' ( BTCS-208 )', 3, 24, 'Introduction, Specifying a Class, Defining Member Functions, C++ Program with Class,\nNesting of Member functions, Private Member Functions, Memory Allocation for Objects,\nStatic Data members, Static Member Functions, Arrays within a Class, Arrays of Objects,\nObjects as Function Arguments, Friendly Functions, Returning Objects. Constructor and\nDestructor: Constructor: Special Characteristics, Declaration and Definition of a\nconstructor, Default Constructor, Overloaded Constructors, Copy Constructor, and\nConstructor with default arguments; Destructor: Special Characteristics, Declaration and\ndefinition of destructor, Operator overloading: Defining Operator Overloading,\nOverloading Unary Operators, and Overloading Binary Operators.', 1, '2021-08-10', '0000-00-00'),
(281, 'Communication Skills ( HUCS-101 )', 3, 25, 'Types of Sentence, Direct - Indirect, Active - Passive voice, Phrases& Clauses. UNIT IV\nBusiness Correspondence: Business Letter, Parts & Layouts of Business Resume and Job\napplication, E-mail writing.', 1, '2021-08-10', '0000-00-00'),
(282, 'Design Thinking ( BTIBM-203)', 3, 26, 'Understand what came before Design Thinking, Identify who did what to bring it about,\nLearn how it built upon previous approaches, Get an overview of the whole approach to\ndesign thinking, Understand the principles, loop, and keys, Determine what is most\nimportant.', 1, '2021-08-10', '0000-00-00'),
(283, 'Agile Development Methodologies (DevOps + Agile) (BTIBM-202)', 3, 27, 'Scrum Ceremonies: Sprint Planning, Daily Scrum Meeting, PBR, Sprint Review. Scrum\nSprint Planning: Sprint Goal,User Stories, Estimate User Stories, Definition of Done. Scrum\nMetrics: Sprint Goal Success, Team Velocity, Sprint Burn Down Charts, Defect Density,\nScrum Scaling, Distributed Scrum Practices, Agile Environments and tools, Scrum vs\nKanban, Xtreme Programming vs Scrum. UNIT–IV Puppet, Jenkins, Junit, Nagios,\nIntroduction of a Use case for CI/CD Pipeline, Problem Solving with DevOps: -More on\nDevOps Tools: Puppet, Jenkins, Junit, Nagios. DevOps Usecase: Introduction of a Use-case\nfor CI/CD Pipeline, Problem Solving with DevOps.', 1, '2021-08-10', '0000-00-00'),
(284, 'Agile Development Methodologies (BTIBM-201)', 3, 28, 'Scrum Sprint Planning , Sprint Goal, User Stories, Estimate User Stories, Definition of\nDone, Kanban Vs Scrum, Xtreme Programming Vs Scrum, DevOps Fundamentals, What is\nDevOps?, A definition of DevOps, Benefits of DevOps approach, Drivers of DevOps,\nUnderstanding the Business Need for DevOps, How is DevOps different from Traditional\nIT?, Issues in traditional application, Recognizing the Business Value of DevOps, Return on\nInvestment, When to adopt / not adopt DevOps?, How is DevOps different from Agile?\nDevOps vs Agile, DevOps Principles , DevOps Lifecycle , Introduction Docker Commands,\nDocker Run, Docker Images, Jenkin Introduction , Jenkins Installation Process, Getting\nStarted with Jenkins.', 1, '2021-08-10', '0000-00-00'),
(285, 'Red Hat Administration-II (RH-134)', 3, 29, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(286, 'Mobile Application Development-II (BTCSMOB-201)', 3, 30, 'Definition Syntax, Structure and Class Instances, Accessing Properties, Memberwise\n,Initializers for Structure Types, Value types or Reference Types. Properties : Stored\nProperties, Lazy Stored Properties, Computed Properties, Property Observers. Global and\nLocal Variables, Type Properties,Type Property Syntax, Querying and Setting Type Properties.', 1, '2021-08-10', '0000-00-00'),
(287, 'Principles of Electronics Engineering (BTCSH-110)', 3, 31, 'Concept of Field Effect Transistors (channel width modulation), Gate isolation types, JFET\nStructure and characteristics, MOSFET Structure and characteristics, depletion and\nenhancement type; CS, CG, CD configurations; CMOS: Basic Principles', 1, '2021-08-10', '0000-00-00'),
(288, 'Fundamentals of Economics (BTCSH-111)', 3, 32, 'Tax and Subsidies — Intertemporal Consumption — Suppliers’ Income Effect; Theory of\nProduction — Production Function and Iso-quants — Cost Minimization; Cost Curves —\nTotal, Average and Marginal Costs — Long Run and Short Run Costs; Equilibrium of a Firm\nUnder Perfect Competition; Monopoly and Monopolistic Competition', 1, '2021-08-10', '0000-00-00'),
(289, 'Business Communication and Value Science – II (BTCSH-112)', 3, 33, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(290, 'Linear Algebra (BTCSH-107)', 3, 34, 'Vector space; Dimension; Basis; Orthogonality; Projections; Gram-Schmidt orthogonalization\nand QR decomposition', 1, '2021-08-10', '0000-00-00'),
(291, 'Statistical Methods (BTCSH-108)', 3, 35, 'Concept & examples, complete sufficiency, their application in estimation.\nTest of hypothesis:\nConcept & formulation, Type I and Type II errors, Neyman Pearson lemma, Procedures of\ntesting.', 1, '2021-08-10', '0000-00-00'),
(292, 'Discrete Structures (BTIT-401)', 3, 36, 'Terminology Graph Representation Graph Isomorphism; Connectedness; Various Graph\nProperties; Euler and Hamiltonian Graph; Shortest Paths Algorithms. Trees: Terminology,\nTree Traversals; Prefix Codes, Spanning Trees, Minimum Spanning Trees.', 1, '2021-08-10', '0000-00-00'),
(293, 'Data Communication (BTCS-302)', 3, 37, 'Correction, Introduction–Block Coding–Hamming Distance, CRC, Flow Control and Error\nControl, Stop and Wait, Error Detection and Error Go Back– N ARQ, Selective Repeat ARQ,\nSliding Window, Piggybacking, Random Access, CSMA/CD,CDMA/CA', 1, '2021-08-10', '0000-00-00'),
(294, 'Analysis and Design of Algorithms ( BTIT-305)', 3, 38, 'Dynamic Programming: General Method,\nOptimal Binary Search Trees, O/1 Knapsack, Traveling Salesperson Problem, All Pairs\nShortest Paths.', 1, '2021-08-10', '0000-00-00'),
(295, 'Principles of Programming Languages (BTCS-303)', 3, 39, 'Arithmetic Relational and Boolean Expressions, Short Circuit Evaluation Mixed Mode\nAssignment, Assignment Statements, Control Structures – Statement Level, Compound\nStatements, Selection, Iteration, Unconditional Statements, Guarded Commands.', 1, '2021-08-10', '0000-00-00'),
(296, 'Introduction to Core Java (BTIT-309)', 3, 40, 'Understanding Threads, Needs of Multi-Threaded Programming, Thread Life Cycle, Thread\nPriorities, Synchronizing Threads, Inter Communication of Threads, The Idea Behind\nException, Exceptions and Errors, Types of Exception, Control Flow in Exceptions, JVM\nReaction to Exceptions, Use of Try, Catch, Finally, Throw, Throws in Exception Handling, In Built and User Defined Exceptions, Checked and Un Checked Exceptions, Generics, Lambda\nExpressions.', 1, '2021-08-10', '0000-00-00'),
(297, 'Technical Presentation Skills (BTCS-610)', 3, 41, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(298, 'Web Development Lab-II (PHP/JSP) ( BTIT-407)', 3, 42, 'Steps to Create an Input Form (Text Fields, Text Areas, Check Boxes, Radio Buttons, List\nBoxes,Password Controls, Hidden Controls, Image Maps, File Uploads, Buttons), Steps to Use\nUsing PHP$_Get And $_Post, $_Request Method for a Given Application, Combining HTML\nand PHP Codes Together on Single Page, Redirecting the User.', 1, '2021-08-10', '0000-00-00'),
(299, 'Cloud Computing: Project Based Learning (BTIBM-401)', 3, 43, 'DATA IN THE CLOUD\n• Where and how will data be used?\n• Why use NoSQL?\n• Attributes of NoSQL databases\n• Summary & resources', 1, '2021-08-10', '0000-00-00'),
(300, 'Unix and Shell Programming Lab (BTIT-406)', 3, 44, 'Types of shells, Shell Functionality, Work Environment, Writing script & executing basic\nscript, Debugging script, Making interactive scripts, Variables (default variables),\nMathematical expressions. Conditional statements: If-else-elif, Test command, Logical\noperators - AND, OR, NOT, Case –esac. Loops: While, For, Until, Break & continue.', 1, '2021-08-10', '0000-00-00'),
(301, 'Computational Learning (AI) (BTAI-301)', 3, 45, 'Learning as Inference, Maximum A Posteriori and Maximum Likelihood, Maximum Likelihood\nfor Undirected models, Properties of Maximum Likelihood, Naive Bayes and Conditional\nIndependence, Bayesian Naive Bayes. Density Estimation: Limit Theorem, Parzen Windows,\nExponential Families, Naive Bayes Estimation using Maximum Likelihood', 1, '2021-08-10', '0000-00-00'),
(302, 'Object Oriented Programming Using Java (BTCS-308)', 3, 46, 'API classes and interfaces Describe and use some of the important API classes and interfaces\navailable in Java, including: Primitive wrapper classes, Classes in the Collections Framework,\nUtility classes, I/O classes, Threads, Exceptions', 1, '2021-08-10', '0000-00-00'),
(303, 'RedHat Administration-III (RH254)', 3, 47, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(304, 'Introduction to Information Technology (BTIT-101)', 3, 48, 'Introduction to Cellular Mobile Systems, Cellular Mobile Telephone Systems, A Basic Cellular\nSystem, Operation of Cellular Systems. Network ServicesTelephone Services, Radio and TV\nBroadcasting, Audio-Visual Conferencing, Video-onDemand.\n', 1, '2021-08-10', '0000-00-00'),
(305, 'Cyber Ethics and Social Media Analysis(ICS) ( BTICS-301)', 3, 49, 'Phenomenology of Social Media, Network Analysis Types of Networks: General Random\nNetworks, Small World Networks, Scale-Free Networks; Examples of Information Networks;\nNetwork Centrality Measures; Strong and Weak ties. Influence and Centrality in Social\nNetworks. Basic of Sentiment Analysis.', 1, '2021-08-10', '0000-00-00'),
(306, 'Technical Presentation Skills (BTCS-610)', 3, 50, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(307, 'Mobile App Development III iOS (BTCSMOB-301)', 3, 51, 'Layout for multiple sizes, Why Auto Layout?, Create alignment constraints, create size\nconstraints, Resolve constraint issues, Safe area layout guide ,resolve constraint warnings,\nConstraints between siblings, Stack views,stack view attributes, Size classes.', 1, '2021-08-10', '0000-00-00'),
(308, 'Object Oriented Programming (BTCSCS-203)', 3, 52, 'Necessity for OOP, Data Hiding, Data Abstraction, Encapsulation, Procedural Abstraction,\nClass and Object.\nMore extensions to C in C++ to provide OOP Facilities:\nScope of Class and Scope Resolution Operator, Member Function of a Class, private, protected\nand public Access Specifier, this Keyword, Constructors and Destructors, friend class, error\nhandling (exception)', 1, '2021-08-10', '0000-00-00'),
(309, 'Computational Statistics (BTCSCS-204)', 3, 53, 'Principal components, Algorithm for conducting principal component analysis, deciding on how\nmany principal components to retain, H-plot.', 1, '2021-08-10', '0000-00-00'),
(310, 'Software Engineering (BTCSCS-205)', 3, 54, 'Internal and external qualities; process and product quality; principles to achieve software\nquality; introduction to different software quality models like McCall, Boehm, FURPS /\nFURPS+, Dromey, ISO – 9126; introduction to Capability Maturity Models (CMM and\nCMMI); introduction to softwarereliability, reliability models and estimation.', 1, '2021-08-10', '0000-00-00'),
(311, 'Financial Management (BTCSMS-206)', 3, 55, 'Operating Leverage, Financial Leverage, Total Leverage, IndifferenceAnalysis in leverage\nstudy Cost of Capital : Concept , Computation of Specific Cost of Capital for Equity -\nPreference – Debt,Weighted Average Cost of Capital – Factors affecting Cost of Capital 4L\nCapital Budgeting : The Capital Budgeting Concept & Process - An Overview, Generating\nInvestment ProjectProposals, Estimating Project, After Tax Incremental Operating Cash\nFlows, Capital Budgeting Techniques,Project Evaluation and Selection - Alternative Methods', 1, '2021-08-10', '0000-00-00'),
(312, 'Formal Language and Automata Theory (BTCSCS-201)', 3, 56, 'Context-free grammars (CFG) and languages (CFL), Chomsky and Greibach normal forms,\nnondeterministic pushdown automata (PDA) and equivalence with CFG, parse trees, ambiguity\nin CFG, pumping lemma for context-free languages, deterministic pushdown automata, closure\nproperties of CFLs.\n', 1, '2021-08-10', '0000-00-00'),
(313, 'Computer Organization and Architecture (BTCSCS-202)', 3, 57, 'CPU control unit design: Hardwired and micro-programmed design approaches, design of a\nsimple hypothetical CPU. Memory system design: Semiconductor memory technologies,\nmemory organization.', 1, '2021-08-10', '0000-00-00'),
(314, 'Environment and Energy Studies (ML-301)', 3, 58, 'Definition, Scope and Importance ecosystem. Classification, Structure and function of an\necosystem, Food chains, food webs and ecological pyramids. Energy flow in the ecosystem,\nBiogeochemical cycles, Bioaccumulation, ecosystem value, devices and carrying capacity, Field\nvisits.', 1, '2021-08-10', '0000-00-00'),
(315, 'Computer Networks(BTIT-502)', 3, 59, 'Overview of MAC Layer, MAC Addressing, Binary Exponential Back-off (BEB) Algorithm,\nDistributed Random Access Schemes/Contention Schemes: for Data Services (ALOHA and\nSlotted- ALOHA), CSMA/CA, CSMA/CD Ethernet, token bus, token ring, (IEEE 802.3, IEEE\n802.4, IEEE 802.5, IEEE 802.11 wireless Communication.', 1, '2021-08-10', '0000-00-00'),
(316, 'Operating Systems (BTCS-502)', 3, 60, 'Introduction to Message Passing, Race Condition, Critical Section Problem, Peterson’s\nSolution, Semaphore, Classical Problems of Synchronization Classical IPC Problems: Reader’s\n& Writer Problem, Dinning Philosopher Problem, Sleeping Barber Problem etc. Deadlock System model, Resource types, Deadlock Problem, Deadlock Characterization, Methods for\nDeadlock Handling, Deadlock Prevention, Deadlock Avoidance: Banker’s algorithm, Deadlock\nDetection, Recovery from Deadlock.', 1, '2021-08-10', '0000-00-00'),
(317, 'Advanced Java Programming (BTCS-409)', 3, 61, 'JDBC Standard Extension 2.0 Introduction to databases (SQL ,No - SQL) Connecting to\nDatabases – JDBC principles – Databases access – Interacting – Database search – Database\nsupport in Web applications MySQL , Model View Controller, JSP , HTML , CSS.', 1, '2021-08-10', '0000-00-00'),
(318, 'Unix and Shell Programming Lab (BTIT-406)', 3, 62, 'Types of shells, Shell Functionality, Work Environment, Writing script & executing basic\nscript, Debugging script, Making interactive scripts, Variables (default variables),\nMathematical expressions. Conditional statements: If-else-elif, Test command, Logical\noperators - AND, OR, NOT, Case –esac. Loops: While, For, Until, Break & continue.', 1, '2021-08-10', '0000-00-00'),
(319, 'Mobile App Development Lab (BTIT-306)', 3, 63, 'Introduction to Android Development Environment, Android/iOS/Win 8 Survival and basic\napps, Mobile frameworks,Tools,Native Level Programming on Android Low-level\nprogramming on (jailbroken) iOS o Windows low level APIs. Study Different Open Source\nFrameworks, Tools And Basic Languages Used For Mobile Development', 1, '2021-08-10', '0000-00-00'),
(320, 'Advanced Java (BTCS-307)', 3, 64, 'Servlet API and Overview : Servlet Model: Overview of Servlet, Servlet Life Cycle, HTTP\nMethods Structure and Deployment descriptor ServletContext and ServletConfig interface,\nAttributes in Servelt, Request Dispacher interface The Filter API: Filter, FilterChain, Filter\nConfig Cookies and Session Management: Understanding state and session, Understanding\nSession Timeout and Session Tracking, URL Rewriting .', 1, '2021-08-10', '0000-00-00'),
(321, 'Application Development Using Python (BTIBM-403)', 3, 65, 'The if and elif statements, While Loops, Using List, Dictionaries, Using the for statement,\nOpening, reading and writing a text file, Using Pandas, the python data analysis library and\ndata frames Grouping, aggregating and applying, merging and joining. Dealing with syntax\nerrors, Exceptions, Handling exceptions with try/excep', 1, '2021-08-10', '0000-00-00'),
(322, 'Application Development and deployment using IOT (BTIBMC-701)', 3, 66, 'IoT Solution Anatomy –\nDevice and Networks: IoT Solution Architecture, Physical Layer (Devices, Hardware, Sensors),\nCommunication layer (IoT networks), Resources', 1, '2021-08-10', '0000-00-00'),
(323, 'Database Management Systems ( BTCS-405)', 3, 67, 'Integrity Constraints:\nNull Values, Domain Constraints, Entity Integrity Constraints Referential Integrity\nConstraints, Key constraints, Triggers.\nRelational Database Design:\nFunctional Dependency, Inference rule, Different Anomalies in designing a Database.\nNormalization , Decomposition, Normal Forms (1NF, 2NF, 3NF, BoyceCodd Normal Form,\nNormalization using Multi-Valued Dependencies, 4NF, Join Dependency, 5NF), Canonical\ncover.', 1, '2021-08-10', '0000-00-00'),
(324, 'Advanced Java Programming (BTCS-409)', 3, 68, 'JDBC Standard Extension 2.0 Introduction to databases (SQL ,No - SQL) Connecting to\nDatabases – JDBC principles – Databases access – Interacting – Database search – Database\nsupport in Web applications MySQL , Model View Controller, JSP , HTML , CSS.', 1, '2021-08-10', '0000-00-00'),
(325, 'Red Hat Application Development I - Java EE (JB-183)', 3, 69, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(326, 'System Programming (BTCS-410)', 3, 70, 'Opening Files, Reading via read(),Writing with write(),Synchronized I/O, Direct I/O, Closing\nFiles, User-Buffered I/O, Reading from a Stream, Writing to a Stream, Seeking a Stream,\nFlushing a Stream, Scatter/Gather I/O, Mapping Files into Memory, I/O Schedulers and I/O\nPerformance.', 1, '2021-08-10', '0000-00-00'),
(327, 'Mobile Application Development IV Android (BTCSMOB-401)', 3, 71, 'UI Widgets , Working with Button class and methods ,Button with Listener, Toast ,Toast Class\nand methods, Custom Toast, ToggleButton, ToggleButton Class and methods, checkbox class\nand methods, custom Checkbox, Radio Button, RadioGroup, Dynamic RadioButton ,Custom\nRadioButton, AlertDailog class and methods,Spinner.', 1, '2021-08-10', '0000-00-00'),
(328, 'Database Management Systems (BTCSCS-210)', 3, 72, 'Domain and data dependency, Armstrong\'s axioms, Functional Dependencies, Normal forms,\nDependency preservation, Lossless design. Query processing and optimization: Evaluation of\nrelational algebra expressions, Queryequivalence, Join strategies, Query optimization\nalgorithms.', 1, '2021-08-10', '0000-00-00'),
(329, 'Software Design with UML (BTCSCS-211)', 3, 73, 'The Logical View Design Stage: The Static Structure Diagrams.\n• The Class Diagram Model.\n• Attributes descriptions.\n• Operations descriptions.\n• Connections descriptions in the Static Model.\n• Association, Generalization, Aggregation, Dependency, Interfacing, Multiplicity.\nPackage Diagram Model.\n• Description of the model.\n• White box, black box.\n• Connections between packagers.\n• Interfaces. • Create Package Diagram.\n• Drill Down.', 1, '2021-08-10', '0000-00-00'),
(330, 'Introduction to Innovation, IP Management and Entrepreneurship (BTCSIIE-212)', 3, 74, 'Entrepreneurship:\n• Opportunity recognition and entry strategies\n• Entrepreneurship as a Style of Management\n• Maintaining Competitive Advantage- Use of IPR to protect Innovation\n', 1, '2021-08-10', '0000-00-00'),
(331, 'Business Communication and Value Science – III (BTCSIIE-213)', 3, 75, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(332, 'Operations Research (BTCSMS-214)', 3, 76, 'TP - Examples, Definitions – decision variables, supply & demand constraints, formulation,\nBalanced & unbalanced situations, Solution methods – NWCR, minimum cost and VAM, test\nfor optimality(MODI method), degeneracy and its resolution. AP - Examples, Definitions –\ndecision variables, constraints, formulation, Balanced &unbalanced situations, Solution method\n– Hungarian, test for optimality (MODI method), degeneracy & its resolution.', 1, '2021-08-10', '0000-00-00'),
(333, 'Operating Systems (BTCSCS-209)', 3, 77, 'Inter-process Communication:\nConcurrent processes, precedence graphs,Critical Section, Race Conditions, Mutual\nExclusion,Hardware Solution, Semaphores, Strict Alternation, Peterson’s Solution, The\nProducer / Consumer Problem, Event Counters, Monitors, Message Passing,Classical IPC\nProblems: Reader’s & Writer Problem, Dinning Philosopher Problem,Barber’s shop problem.\nDeadlocks:\nDefinition, Necessary and sufficient conditions for Deadlock, DeadlockPrevention, Deadlock\nAvoidance: Banker’s algorithm, Deadlock detection and Recovery.\nConcurrent Programming:\nCritical region, conditional critical region, monitors, concurrent languages, communicating\nsequential process (CSP); Deadlocks - prevention, avoidance, detection and recovery.', 1, '2021-08-10', '0000-00-00'),
(334, 'Computer Graphics and Multimedia (BTCS-503)', 3, 78, '2D Geometric Transformations -\nBasic transformation, Matrix representation and Homogeneous Coordinates Composite\ntransformationOthertransformations.Transformation between coordinated systems.Window to\nViewport coordinate transformation,\nClipping operations –\nPoint clipping, Line clipping:-Cohen – Sutherland line clippingLiang – Barsky line\nclippingMidpoint subdivision\nPolygon Clipping-Sutherland –\nHodgeman polygon clippingWeiler – Atherton polygon clipping.3D object representation\nmethods B-REP , sweep representations , CSG\nBasic transformations Translation,Rotation, Scaling\nOther transformations Reflection,Rotation about an arbitrary axis Composite transformations Projections – Parallel\nand Perspective 3D clipping', 1, '2021-08-10', '0000-00-00'),
(335, 'Software Engineering and Project Management (BTCS-504)', 3, 79, 'Design Concepts and Principles, Software Modeling and UML, Architectural Design,\nArchitectural Views and Styles, User Interface Design, Function-oriented Design, SA/SD\nComponent Based Design, Design Metrics.', 1, '2021-08-10', '0000-00-00'),
(336, 'Artificial Intelligence (BTCS-511)', 3, 80, 'Probabilistic Reasoning: Probability, conditional probability, Bayes Rule, Bayesian\nNetworksrepresentation, construction and inference, temporal model, hidden Markov model.', 1, '2021-08-10', '0000-00-00'),
(337, 'CYBER AND NETWORK SECURITY (BTIT-603)', 3, 81, 'Tools and Methods Used in Cyber crime, Proxy Server and Anonymizers, Phishing and Identity\nTheft, Password Cracking, Keylogger and Spyware, Virus and Worms, Trojan Horse and\nBackdoors, Steganography DoS and DDoS Attacks, SQL Injection, Buffer Overflow, Attack on\nWireless Networks.', 1, '2021-08-10', '0000-00-00'),
(338, 'WIRELESS COMMUNICATION NETWORKS (BTIT-511)', 3, 82, 'Tools and Methods Used in Cyber crime, Proxy Server and Anonymizers, Phishing and Identity\nTheft, Password Cracking, Keylogger and Spyware, Virus and Worms, Trojan Horse and\nBackdoors, Steganography DoS and DDoS Attacks, SQL Injection, Buffer Overflow, Attack on\nWireless Networks.', 1, '2021-08-10', '0000-00-00'),
(339, 'MANAGEMENT INFORMATION SYSTEM (BTIT-513)', 3, 83, 'Introduction, data and information- measuring data, information as a resource, information in\norganizational functions, types of information technology, types of information\nsystemstransaction processing systems-management information system.', 1, '2021-08-10', '0000-00-00'),
(340, 'INFORMATION STORAGE AND MANAGEMENT (BTIT-611)', 3, 84, 'JBOD, DAS, NAS, SAN & CAS evolution and comparison, Applications, Elements,\nConnectivity, standards, management, security and limitations of DAS, NAS, CAS & SAN', 1, '2021-08-10', '0000-00-00'),
(341, 'ENTERPRISE RESOURCE PLANNING (BTIT-712)', 3, 85, '1. ERP modules & Vendors Finance Production planning, control & maintenance Sales &\nDistribution Human Resource Management (HRM)\n2. Inventory Control System.\n3. Quality Management ERP Market', 1, '2021-08-10', '0000-00-00'),
(342, 'Programming with Python (BTCS-407)', 3, 86, 'Handling exceptions, Exceptions as a control flow mechanism, Assertions. Classes and Object\noriented Programming: Abstract Data Types and Classes, Inheritance, Encapsulation and\ninformation hiding.', 1, '2021-08-10', '0000-00-00'),
(343, 'Scripting Languages (BTCS-607)', 3, 87, 'Python: Introduction to python languages, python syntax, statements, functions, build-in\nfunctions, methods, module in python, exception handling, integrated web application in\npython- Building small, efficient python web system, web application framework.', 1, '2021-08-10', '0000-00-00'),
(344, 'Big Data Technologies (BTIBMB-601)', 3, 88, 'Introduction to Hortonworks and its components Apache Ambari- The purpose of Apache\nAmbari in the HDP stack, the overall architecture of Ambari and Ambari’s relation to other\nservices and components of a Hadoop cluster, the functions of the main components of Ambari,\ninitiating start and stop services from Ambari Web Console. Overview about Hortonworks Data\nPlatform - HDP -The functions and features of HDP, the IBM value-add components, what IBM\nWatson Studio is, a brief description of the purpose of each of the value-add components', 1, '2021-08-10', '0000-00-00'),
(345, 'Predictive Analytics (BTIBDA-501)', 3, 89, 'Decision-centered visualization, Fundamentals of\nVisualization, Common graphs, Common tools.', 1, '2021-08-10', '0000-00-00'),
(346, 'Micro services Architecture and Implementation (BTIBM-601)', 3, 90, 'Containers and Dockers, Basic Docker commands, Dev versus Ops, The Twelve-Factor App,\nDocker mission, Docker Adoption, Docker basic concept, Docker architecture, Docker typical\nworkflow, Docker shared and layered file systems technology, container ecosystem and\norchestration.', 1, '2021-08-10', '0000-00-00'),
(347, 'Predictive Modelling (BTIBMA-501)', 3, 91, 'Visualization and Presentation of Data: Decision-centered visualization, Fundamentals of\nVisualization, Different Types of Graphs like Bar, scatter, box plot, histogram, Pie chart,\nCommon tools of visualization and representation of data.', 1, '2021-08-10', '0000-00-00'),
(348, 'Cloud Computing (BTCS-701)', 3, 92, 'Working with Cloud Infrastructure as a Service – conceptual model and working, Platform as a\nService – conceptual model and functionalities. Software as a Service –conceptual model and\nworking. Trends in Service provisioning with clouds. Working on Microsoft Azure & IBM\nSmart Cloud.\n', 1, '2021-08-10', '0000-00-00'),
(349, 'Computer Architecture and Microprocessor (BTCS-509)', 3, 93, 'Multiprocessor organization, Instruction level pipelining,Instruction and arithmetic pipelines,\nVector and array processors, GPU. Memory organization: Characteristics of Memory systems,\nInternal and External memories, Memory Hierarchy, High speed Memories: Cache Memory -\nOrganization and mappings, Associative memory,', 1, '2021-08-10', '0000-00-00'),
(350, 'RedHat Open Stack and Ansible (CLDO-507)', 3, 94, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(351, 'Network Security And Cryptography (BTICS-501)', 3, 95, 'Introduction of Block Ciphers, Overview of Symmetric Key Cryptography, DES(Data\nEncryption Standard) algorithm, Double DES Triple DES, AES,IDEA(International Data\nEncryption Algorithm) algorithm.', 1, '2021-08-10', '0000-00-00'),
(352, 'Ethical Hacking Lab-1 (BTICS-502)', 3, 96, 'Introduction to Cyber offence, How Criminal plan the attack, Social Engineering, Cyber\nstalking, Cybercafé and cybercrime, Botnets: The fuel of cybercrime, Attack vector, cloud\ncomputing. Cybercrime: Mobile and Wireless devices, Proliferation of Mobile and Wireless\nDevices, Trends in Mobility, Security Challenges Posed by Mobile Devices, Registry Setting for\nMobile Devices, Authentication Service Security, Attack on Mobile Phones..', 1, '2021-08-10', '0000-00-00'),
(353, 'Theory of Computation (BTCS-501)', 3, 97, 'Definition, Examples, Derivation, Derivation trees, Ambiguity in Grammar, Inherent\nambiguity, Ambiguous to Unambiguous CFG, Useless symbols, Simplification of CFGs, Normal\nforms for CFGs: CNF and GNF, Closure properties of CFLs, Decision Properties of CFLs:\nEmptiness, Finiteness and Membership, Pumping lemma for CFLs.\n', 1, '2021-08-10', '0000-00-00'),
(354, 'Internet of Things (BTCS-602)', 3, 98, 'Solution framework for IoT applications- Implementation of Device integration, Data\nacquisition and integration.', 1, '2021-08-10', '0000-00-00'),
(355, 'Cloud Computing (BTCS-701)', 3, 99, 'Working with Cloud Infrastructure as a Service – conceptual model and working, Platform as a\nService – conceptual model and functionalities. Software as a Service –conceptual model and\nworking. Trends in Service provisioning with clouds. Working on Microsoft Azure & IBM\nSmart Cloud.', 1, '2021-08-10', '0000-00-00'),
(356, 'Data Science (BTCS-608)', 3, 100, 'Linear Algebra: Vectors, Matrices, Statistics: Describing a Single Set of Data, Correlation,\nSimpson’s Paradox, Correlation and Causation, Probability: Dependence and Independence,\nConditional Probability, Bayes’s Theorem, Random Variables, Continuous Distributions, The\nNormal Distribution, The Central Limit Theorem, Hypothesis and Inference: Statistical\nHypothesis Testing, Confidence Intervals, Phacking, Bayesian Inference', 1, '2021-08-10', '0000-00-00'),
(357, 'Simulation and Modeling (BTCS-612)', 3, 101, 'Characteristics of queuing system, Poisson\'s formula, birth-death system, equilibriumof\nqueuing system, analysis of M/M/1 queues. Introduction to multiple server Queue models\nM/M/c Application of queuing theory in manufacturing and computer system, FSM, Petri-net\nModel.', 1, '2021-08-10', '0000-00-00'),
(358, 'Software Testing and Quality Assurance (BTCS-613)', 3, 102, 'Black box testing techniques - Boundary value analysis - Robustness testing - Equivalence\npartitioning -Syntax testing - Finite state testing - Levels of testing – Unit testing- Integration\nTesting', 1, '2021-08-10', '0000-00-00'),
(359, 'Block Chain (BTCS-618)', 3, 103, 'Permissioned Block chain: Permissioned model and use cases, Design issues for Permissioned\nblock chains, Execute contracts, State machine replication, Overview of Consensus models for\npermissioned block chain- Distributed consensus in closed environment, Paxos, RAFT\nConsensus, Byzantine general problem, Byzantine fault tolerant system, Lamport-Shostak Pease BFT Algorithm, BFT over Asynchronous systems.', 1, '2021-08-10', '0000-00-00'),
(360, 'Robotics (BTCS-617)', 3, 104, 'Sensor: Contact and Proximity, Position, Velocity, Force, Tactile etc. Introduction to Cameras,\nCamera calibration, Geometry of Image formation, Euclidean/Similarity /Affine/Projective\ntransformations. Vision applications in robotics.', 1, '2021-08-10', '0000-00-00'),
(361, 'IT WorkshopSciLab/MATLAB (BTIT-608)', 3, 105, 'Entering Matrices sum and transpose, subscripts, colon Operator, magic Function. WORKING\nWITH MATRICES: Generating Matrices, The load Function, M-Files, Concatenation, Deleting\nRows and Columns, Linear Algebra, Arrays Multivariate Data, Scalar Expansion, Logical\nSubscripting, find Function.', 1, '2021-08-10', '0000-00-00'),
(362, 'Minor Project (BTCS-606)', 3, 106, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(363, 'Object Oriented Analysis and Design (BTIT-604)', 3, 107, 'Development Life cycle, Development stages, Domain Analysis-Domain class model, domain\nstate model, domain interaction model, Iterating and analysis. Application Interaction model,\nApplication class model, Application state Model, Adding operation.', 1, '2021-08-10', '0000-00-00'),
(364, 'Micro services Architecture and Implementation (BTIBM-601)', 3, 108, 'A shipping container for code, Benefits of using containers, Docker basic concepts, Docker\nshared and layered file systems technology. Deployment of container, Learn the concept of\nkubernetes, Learn how to run Docker command, Understand pods and cluster Container\necosystem,', 1, '2021-08-10', '0000-00-00'),
(365, 'Big Data Engineering - Spark & Scala (BTIBMB-602)', 3, 109, 'Understanding Data Science and Notebooks Data Scientists overview, Recognizing the iterative\nnature of a data science project, Outlining the benefits of using Data Science Notebooks,\nDescribing the mechanisms and tools used with Data Science Notebooks, Comparing and\ncontrasting the major Notebooks used by Data Scientists, Data and notebooks in Jupyter, How\nnotebooks help data scientists, Essential packages: NumPy, SciPy, Pandas, Scikit-learn, NLTK,\nBeautifulSoup, Data visualizations: matplotlib, PixieDust, Using Jupyter ―Magic‖ commands,\nStart Jupyter - it will open in a web browser, Importing the lab, Exploring the component\npanels', 1, '2021-08-10', '0000-00-00'),
(366, 'Big Data Technologies (Hadoop) (BTIBMC-602)', 3, 110, 'The purpose of Apache Ambari in the HDP stack, the overall architecture of Ambari and\nAmbari’ relation to other services and components of a Hadoop cluster, the functions of the\nmain components of Ambari, initiating start and stop services from Ambari Web Console.\nOverview about Hortonworks Data Platform – HDP: The functions and features of HDP, the\nIBM value-add components, what IBM Watson Studio is, a brief description of the purpose of\neach of the value-add components', 1, '2021-08-10', '0000-00-00'),
(367, 'Artificial Intelligence (BTIBMC-601)', 3, 111, 'FUTURE TRENDS FOR AI Artificial Intelligence Trends, Limits of machine and\nhuman, AI predictions in the next 5 years Summary and Resources.', 1, '2021-08-10', '0000-00-00'),
(368, 'CYBER AND NETWORK SECURITY (BTIT-603)', 3, 112, 'Tools and Methods Used in Cyber crime, Proxy Server and Anonymizers, Phishing and Identity\nTheft, Password Cracking, Keylogger and Spyware, Virus and Worms, Trojan Horse and\nBackdoors, Steganography DoS and DDoS Attacks, SQL Injection, Buffer Overflow, Attack on\nWireless Networks.', 1, '2021-08-10', '0000-00-00'),
(369, 'Introduction to container Kubernete and RedHat OpenShift and JBOSS (DOJB-603)', 3, 113, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(370, 'Ethical Hacking Lab-II (BTICS-602)', 3, 114, 'Introduction, types of sniffing, Packet Sniffing tools and techniques and how to defend against\nSniffing. Network scanning techniques and scanning countermeasures. UNIT–IV ARP and DNS\nPoisoning: Introduction, ARP spoofing, Introduction of MITM, defenses against DNS\nPoisoning.', 1, '2021-08-10', '0000-00-00'),
(371, 'Concepts of System Security (BTICS-601)', 3, 115, 'Introduction: Secure OS, Security Goals, Trust Model, Threat Model, Access Control.\nFundamentals: Protection system, Lampson‘s Access Matrix, Mandatory protection system.', 1, '2021-08-10', '0000-00-00'),
(372, 'Human Values and Professional Ethics (BBAI-501)', 3, 116, '1. Leadership, Characteristics\n2. Leadership in Business (Styles), Types of Leadership (Scriptural, Political, Business and\nCharismatic)\n3. Leadership Behaviour, Leadership Transformation in terms of Shastras (Upanihads,\nSmritis and Manu-smriti).', 1, '2021-08-10', '0000-00-00'),
(373, 'Compiler Design ( BTCS-601)', 3, 117, 'Syntax Directed Definitions, Evaluation Orders for Syntax Directed Definitions, Intermediate\nlanguages, Declarations, Assignment Statements, Boolean Expressions, Case Statements, Three\nAddress code, Back patching, Procedure calls.', 1, '2021-08-10', '0000-00-00'),
(374, 'OBJECT ORIENTED ANALYSIS AND DESIGN ( BTIT-604)', 3, 118, 'Development Life cycle, Development stages, Domain Analysis-Domain class model, domain\nstate model, domain interaction model, Iterating and analysis. Application Interaction model,\nApplication class model, Application state Model, Adding operation.\n', 1, '2021-08-10', '0000-00-00'),
(375, 'BIG DATA AND HADOOP (BTCS-702)', 3, 119, 'Using Hadoop to store data, Learn NoSQL Data Management, Querying big data with Hive,\nIntroduction to the SQL Language , From SQL to HiveQL , Querying big data with Hive,\nIntroduction to HIVE e HIVEQL, Using Hive to query Hadoop files. Moving the Data from\nRDBMS to Hadoop, Moving the Data from RDBMS to Hbase , Moving the Data from RDBMS\nto Hive UNIT IV Machine Learning Libraries for big data analysis, Machine Learning Model\nDeployment, Machine learning tools , Spark & SparkML , H2O , Azure ML.', 1, '2021-08-10', '0000-00-00'),
(376, 'Next Generation Telecommunication Networks (BTCC-703)', 3, 120, 'Wireless n/w. and Technologies Introduction, Different generations. Introduction to 1G, 2G, 3G\nand 4G, Bluetooth, Radio frequency identification(Rfid),Wireless Broadband, Mobile IP:\nIntroduction, Advertisement, Registration, TCP connections, two level addressing, abstract\nmobility management model, performance issue, routing in mobile host, Adhoc networks,\nMobile transport layer: Indirect TCP, Snooping TCP, Mobile TCP, Time out freezing, Selective\nretransmission, transaction oriented TCP. ,IPv6', 1, '2021-08-10', '0000-00-00'),
(377, 'Soft computing (BTCS-711)', 3, 121, 'Neural Network (NN), Biological foundation of Neural Network, Neural Model and Network\nArchitectures, Perceptron Learning, Supervised Hebbian Learning, Back-propagation,\nAssociative Learning, Competitive Networks, Hopfield Network, Computing with Neural\nNetsand applications of Neural Network', 1, '2021-08-10', '0000-00-00'),
(378, 'Quantum Computing (BTCS-715)', 3, 122, 'Architecture of a Quantum Computing platform, Details of q-bit system of information\nrepresentation: Block Sphere, Multi-qubits States, Quantum superposition of qubits (valid and\ninvalid superposition),Quantum Entanglement, Useful states from quantum algorithmic\nperceptive e.g. Bell State, Operation on qubits: Measuring and transforming using gates,\nQuantum Logic gates and Circuit: Pauli, Hadamard, phase shift, controlledgates, Ising,\nDeutsch, swap etc, Programming model for a Quantum Computing Program: Steps performed\non classical computer, Steps performed on Quantum Computer, Moving data between bits and\nqubits.', 1, '2021-08-10', '0000-00-00'),
(379, 'Virtual Reality (BTCS-716)', 3, 123, 'Animating the Virtual Environment: Introduction, The dynamics of numbers, Linear and\nNonlinear interpolation, the animation of objects, linear and non-linear translation, shape &\nobject inbetweening, free from deformation, particle system. Physical Simulation: Introduction,\nObjects falling in a gravitational field, Rotating wheels, Elastic collisions, projectiles, simple\npendulum, springs, Flight dynamics of an aircraft.', 1, '2021-08-10', '0000-00-00'),
(380, 'Project (BTCS-706)', 3, 124, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(381, 'Computer Graphics and Multimedia (BTCS-503)', 3, 125, '2D Geometric Transformations -\nBasic transformation, Matrix representation and Homogeneous Coordinates Composite\ntransformationOthertransformations.Transformation between coordinated systems.Window to\nViewport coordinate transformation,\nClipping operations –\nPoint clipping, Line clipping:-Cohen – Sutherland line clippingLiang – Barsky line\nclippingMidpoint subdivision\nPolygon Clipping-Sutherland –\nHodgeman polygon clippingWeiler – Atherton polygon clipping.3D object representation\nmethods B-REP , sweep representations , CSG\nBasic transformations Translation,Rotation, Scaling\nOther transformations Reflection,Rotation about an arbitrary axis Composite transformations Projections – Parallel\nand Perspective 3D clipping', 1, '2021-08-10', '0000-00-00'),
(382, 'Mobile and Cloud Security (BTICS-701)', 3, 126, 'Android, iOS Mobile platform security models, Detecting Android malware in Android\nmarkets, Reputation and Trust, Intrusion Detection, Vulnerabilities, Analysis of Mobile\ncommerce platform, secure authentication for mobile users, Mobile commerce security,\npayment methods, Mobile Coalition key evolving Digital Signature scheme for wireless mobile\nNetworks.', 1, '2021-08-10', '0000-00-00'),
(383, 'Cyber Investigation and Digital Forensic (BTICS-702)', 3, 127, 'Forensics Investigation Process, Securing the Evidence and Crime Scene, Chain of Custody,\nLaw Enforcement Methodologies, Forensics Evidence, Evidence Sources. Evidence Duplication,\nPreservation, Handling, and Security, Forensics Soundness, Order of Volatility of Evidence,\nCollection of Evidence on a Live System, Court Admissibility of Volatile Evidence\n', 1, '2021-08-10', '0000-00-00'),
(384, 'DISTRIBUTED SYSTEM (BTIT-713)', 3, 128, 'Peer-to-peer Systems Introduction, Napster and its legacy, Peer-to-peer Middleware, Routing\noverlays. Overlay case studies: Pastry, Tapestry, Distributed File Systems, File service\narchitecture, Andrew File system. File System: Features-File model -File accessing models, File\nsharing semantics Naming: Identifiers, Addresses, Name Resolution, Name Space\nImplementation, Name Caches LDAP.', 1, '2021-08-10', '0000-00-00'),
(386, 'APPLIED PHYSICS(BTPH-101)', 4, 2, 'Laser & Fiber Optics:\nStimulated and Spontaneous Emission, Einstein’s A&B Coefficients, Population Inversion,\nPumping, Techniques of Pumping, Optical Resonator, Properties and Applications of Laser,\nRuby, Nd:YAG, He-Ne lasers. Introduction to Optical fibre, Acceptance angle and cone,\nNumerical Aperture, V- Number, Ray theory of propagation through optical fibre, Pulse\ndispersion , applications of optical fibre.', 1, '2021-08-10', '0000-00-00'),
(387, 'Introduction to Computer Science and Engineering(BTCS-102)', 4, 3, 'Office Automation Tools-II:\nSpread Sheet: Introduction to MS-Excel, Starting MS-Excel, Basics of Workbook and\nSpreadsheet, MS-Excel Screen and Its Components, Features of Excel, Elementary Working\nwith MS-Excel, Manipulation of cells, Formatting of Spreadsheet and Cells, Formulas and\nFunctions, Spread sheets for Small accountings, Previewing and Printing a Worksheet.\nPower-point: Introduction to MS-PowerPoint, Starting MS-PowerPoint, Basics of\nPowerPoint, MS PowerPoint Screen and Its Components, Features of PowerPoint,\nElementary, Elementary Working with MS-PowerPoint, Preparation of Slides, Creation of\nPresentation, Providing aesthetics, Slide Manipulation and Slide Show, Presentation of the\nSlides.', 1, '2021-08-10', '0000-00-00'),
(388, 'Digital Logic and Circuit Design(BTEC-104)', 4, 4, 'Sequential logic:\nIntroduction, Latch and Flip Flop- S-R, D, JK and T, State diagram, characteristic\nequation, state table and excitation table, Flip flop conversion, applications of Flip flop,\nCounters, Registers.', 1, '2021-08-10', '0000-00-00'),
(389, 'Principles of \'C\' language (BTCS-104)', 4, 5, 'Top-Down Approach of Problem Solving:\nModular Programming and Functions, Standard Library of C Functions, Prototype of a\nFunction: Foo1lal Parameter List, Return Type, Function Call, Block Structure, Passing\nArguments to a Function: Call by Reference, Call by Value, Recursive Functionsand Arrays as\nFunction Arguments Structure Variables, Initialization, Structure Assignment, Nested Structure,\nStructures and Functions, Structures and Arrays: Arrays of Structures, Structures Containing\nArrays, Unions.', 1, '2021-08-10', '0000-00-00');
INSERT INTO `syllabus` (`id`, `name`, `unit_id`, `subject_id`, `syllabus_detail`, `status`, `created_at`, `updated_at`) VALUES
(390, 'Programming Skills with \'C\' (BTCS-108)', 4, 6, 'Pointers and Strings:\nPointers, Relationship Between Arrays and Pointers Argument passing using Pointers Array\nof Pointers, Passing arrays as Arguments, Strings and C String Library.Structure and\nUnions, Defining C structures, Passing Strings as Arguments Programming Examples.', 1, '2021-08-10', '0000-00-00'),
(391, 'Web Development Lab-I(HTML & XML) (BTIT-307)', 4, 7, 'XML:\nIntroduction of XML, Cross scripting of XML, XML as intermediate language, Difference\nbetween XML and HTML, XML DOM, Tree, Syntax, Elements, Attributes, Namespaces, XPath,XML DTD, Applications, XQuery, XML Schema, XML Parser, XHTML: Introduction of\nXHTML, XHTML rules over the HTML, conversation HTML to XHTML.', 1, '2021-08-10', '0000-00-00'),
(392, 'Software Foundation and Programming ( 1. Clean Coding; 2. Javascript; 3. NodeRed; 4. NodeJS) (BTIBM-105', 4, 8, 'Tokens , Keywords, Identifiers and Constants, C++ data types,Variables: Declaration,\nDynamic initialization of variables, Reference variables. Operators in C++ : Scope\nresolution operator, Member Deferencing Operators, Memory Management Operators,\nManipulators, Type cast operators, Expressions and Control Structures. Functions: The\nmain() function, Function Prototyping, Call by reference, Return by reference, Inline\nfunction, Function Overloading.', 1, '2021-08-10', '0000-00-00'),
(393, 'Software Foundation and Programming 1 (with \'C\') (BTCS-105)', 4, 9, 'Program, Translator, Assembler, Compiler, Interpreter,\nIntroduction to C Language, Getting Started with C, Escape Sequence,\nData types, Comments, Input & output in C, Unformat Console I/O Function,\nConstructor, Loops and Array, Operators, Loops, Decision, Nested Loops,\nBreak Statement, Continue Statement, Accessing Element of Array, Sorted\nArray, Types of Array, Multidimensional Array. FUNCTIONS Function Definition,\nFunction Prototype, Function Calling, Scope of Variable, Functions with Arguments,\nNesting of Function for not allowed, Recursion, Passing Array to the function,\nStorage classes to C, Program with Static, Automatic and External Variable.\n', 1, '2021-08-10', '0000-00-00'),
(394, 'Red Hat Administration-I (RH-124)', 4, 10, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(395, 'Computer Peripherals and Interfaces ( BTCS-204 )', 4, 11, 'Motherboard Controllers and System Resources, I/O System Bus: ISA, MCA, ELSA, VESA\nlocal bus, PCI, AGP, PCIX, Onboard I/O devices, Chipsets, ROM BIOS, ROM POST,\nCMOS settings, Motherboard Form factor: AT and ATX Motherboard, LPX and NLX\nform factor.', 1, '2021-08-10', '0000-00-00'),
(396, 'Mobile Application Development-I (BTCSMOB-101)', 4, 12, 'Installation of Xcode ,Working with Xcode, create a simple program and execute it using Xcode\n, Working with swift playgrounds , create a simple program and execute it using swift\nplaygrounds.', 1, '2021-08-10', '0000-00-00'),
(397, 'Principles of Electrical Engineering (BTCSH-104)', 4, 13, 'Current-Voltage Relations of the Electric Network by Mathematical Equations to Analyze the\nNetwork (Thevenin’s Theorem, Norton\'s Theorem, Maximum Power Transfer Theorem)\nSimplifications of Networks using Series-Parallel, Star/Delta Transformation. Superposition\nTheorem.', 1, '2021-08-10', '0000-00-00'),
(398, 'Physics for Computing Science (BTCSH-105)', 4, 14, 'Theory of Interference FringesTypes of Interference-Fresnel’s Prism-Newton’s Rings,\nDiffraction-Two kinds of DiffractionDifference between Interference and Diffraction-Fresnel’s\nHalf Period Zone and Zone PlateFraunhofer Diffraction at Single Slit-Plane Diffraction\nGrating. Temporal and Spatial Coherence.\nPolarization of light: Polarization - Concept of Production of Polarized Beam of Light from two\nSHM Acting at Right Angle; Plane, Elliptical and Circularly Polarized Light, Brewster’s Law,\nDouble Refraction.', 1, '2021-08-10', '0000-00-00'),
(399, 'Business Communication and Value Science – I (BTCSH-106)', 4, 15, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(400, 'Discrete Mathematics (BTCSH-101)', 4, 16, 'Abstract algebra: Set,\nRelation, Group, Ring, Field.', 1, '2021-08-10', '0000-00-00'),
(401, 'Statistics, Probability and Calculus (BTCSH-102)', 4, 17, 'Mathematical Expectation and its Properties, Moments (Including Variance) and their\nProperties, Interpretation, Moment Generating Function.', 1, '2021-08-10', '0000-00-00'),
(402, 'Fundamentals of Computer Science (BTCSCS-103)', 4, 18, 'Pointers and address, Pointers and Function Arguments, Pointers and Arrays, Address\nArithmetic, character Pointers and Functions, Pointer Arrays, Pointer to Pointer, Multi dimensional array and Row/column major formats, Initialisation of Pointer Arrays, Command\nline arguments, Pointer to functions, Complicated declarations and how they are evaluated.\nStructures: Basic Structures, Structures and Functions, Array of structures, Pointer of\nstructures, Self-referral Structures, Table look up, Typedef, Unions, Bit-fields', 1, '2021-08-10', '0000-00-00'),
(403, 'Mathematics-II ( BTMACS-201)', 4, 19, 'Euler\'s Method for Numerical Solution of ODE; Modified Euler\'s Method; Runge‐Kutta\nMethod (RK2, RK4); Multistep Method: Predictor‐Corrector method.', 1, '2021-08-10', '0000-00-00'),
(404, 'Computer Peripherals and Interfaces ( BTCS-204 )', 4, 20, 'Floppy Disk interface: Controller, Power cable, Control/Data cable, IDE interfaces: ATA\nstandards, Master/Slave Configuration, Data transfer modes, SCSI interface: Bus,\nStandards, Hardware’s, which is better SCSI or IDE, Serial ports, Parallel ports, USB,\nTroubleshooting.', 1, '2021-08-10', '0000-00-00'),
(405, 'Data Structure and Algorithms (BTCS-403)', 4, 21, 'Definitions and Concepts of Binary trees, Types of Binary Tree, Representation of Binary\ntree: Array & Linked List. General tree, forest, Expression Tree. Forest and general tree to\nbinary tree conversion. Binary Search Tree Creation, Operations on Binary Search Trees:\ninsertion, deletion & Search an element, Traversals on Binary SEARCH TREE and\nalgorithms. Height balanced Tree: AVL, B-Tree, 2-3 Tree, B+Tree: Creation, Insertion &\nDeletion.Graph: Definitions and Concepts Graph Representations: Adjacency MATRIX,\nIncidence matrix, Graph TRAVERSAL (DFS & BFS), Spanning Tree and Minimum Cost\nSpanning Tree: Prim’s & Kruskal’s Algorithm.', 1, '2021-08-10', '0000-00-00'),
(406, 'Computer System Organization ( BTCS-404 )', 4, 22, 'Characteristics of Memory systems, Internal and External memories, Memory Hierarchy,\nHigh speed Memories: Cache Memory - Organization and mappings, Associative memory,\nVirtual memory: Segmentation, Paging, Address Translation Virtual to Physical. Secondary\nStorage: Magnetic Disk, Tape, DAT, RAID, Optical memory, CDROM, DVD.', 1, '2021-08-10', '0000-00-00'),
(407, 'Object Oriented Programming ( BTCS-305)', 4, 23, 'Concept of Streams, Cin and Cout Objects, C++ Stream Classes, Unformatted and Formatted\nI/O, Manipulators, File Stream, C++ File Stream Classes, File Management Functions, File\nModes, Binary And Random Files.', 1, '2021-08-10', '0000-00-00'),
(408, 'Programming Skills with \'C++\' ( BTCS-208 )', 4, 24, 'Introduction, Defining Derived Classes, Single inheritance, Multiple inheritance,\nHierarchical inheritance, Multilevel inheritance, Hybrid inheritance, Virtual Base Classes,\nPolymorphism, static and dynamic binding, Constructor in Derived Classes, Pointers to\nDerived Classes, Virtual Functions, Pure Virtual Functions.', 1, '2021-08-10', '0000-00-00'),
(409, 'Communication Skills ( HUCS-101 )', 4, 25, 'Business Correspondence: Business Letter, Parts & Layouts of Business Resume and Job\napplication, E-mail writing.', 1, '2021-08-10', '0000-00-00'),
(410, 'Design Thinking ( BTIBM-203)', 4, 26, 'Learn 7 key habits of effective thinkers design, Avoid common anti-patterns, Optimize for\nsuccess with these habits, Understand the importance of iteration, Learn how to observe,\nreflect, & make, Get ready to drill down & do tomorrow, Understand the importance of\nuser research, Appreciate empathy through listening, Learn key methods of user research.', 1, '2021-08-10', '0000-00-00'),
(411, 'Agile Development Methodologies (DevOps + Agile) (BTIBM-202)', 4, 27, 'Puppet, Jenkins, Junit, Nagios,\nIntroduction of a Use case for CI/CD Pipeline, Problem Solving with DevOps: -More on\nDevOps Tools: Puppet, Jenkins, Junit, Nagios. DevOps Usecase: Introduction of a Use-case\nfor CI/CD Pipeline, Problem Solving with DevOps.', 1, '2021-08-10', '0000-00-00'),
(412, 'Agile Development Methodologies (BTIBM-201)', 4, 28, 'Sprint Goal, Benefits of Sprint Goal, Determine Sprint Goal, Sprint Goal Template, User\nStories, Benefits of writing user stories, Estimate User Stories, What is a Story Point?\nFactors to be consider while estimating stories, Participants in story Point estimation,\nAdvantages of using story points for estimating work , steps to estimate stories Definition of\nDone, Story Definition of Done ,Sprint Definition of Done, Release Definition of Done The\nevolving Definition of Done, Definition of Done common impediments, Sprint Goal Success,\nTeam Velocity, Importance of velocity. Sprint Burn Down Chart Definition, Steps to read\nBurndown chart, Samples Burndown chart, Advantages of using Burndown charts,\nAdvantages of defect density Factors that affect the defect density metrics.\n', 1, '2021-08-10', '0000-00-00'),
(413, 'Red Hat Administration-II (RH-134)', 4, 29, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(414, 'Mobile Application Development-II (BTCSMOB-201)', 4, 30, 'Methods, Instance Methods, self Property, Mutating Method, Type Methods Inheritance: Base\nClass,types of Inheritance, Subclassing, Overriding: Accessing Superclass Methods, Properties,\nand Subscripts, Overriding Methods, Overriding Properties, Overriding Property Getters and\nSetters, Preventing Overrides.', 1, '2021-08-10', '0000-00-00'),
(415, 'Principles of Electronics Engineering (BTCSH-110)', 4, 31, 'Concept (Block diagram), properties, positive and negative feedback, loop gain, open loop gain,\nfeedback factors; topologies of feedback amplifier; effect of feedback on gain, output\nimpedance, input impedance, sensitivities (qualitative), bandwidth stability. Introduction to\nintegrated circuits, operational amplified and its terminal properties; Application of operational\namplifier; inverting and noninverting mode of operation, Adders, Subtractors, Constant-gain\nmultiplier, Voltage follower, Comparator, Integrator, Differentiator', 1, '2021-08-10', '0000-00-00'),
(416, 'Fundamentals of Economics (BTCSH-111)', 4, 32, 'National Income and its Components — GNP, NNP, GDP, NDP; Consumption Function;\nInvestment; Simple Keynesian Model of Income Determination and the Keynesian Multiplier;\nGovernment Sector — Taxes and Subsidies; External Sector — Exports and Imports; Money —\nDefinitions; Demand for Money —Transactionary and Speculative Demand; Supply of Money\n— Bank’s Credit Creation Multiplier; Integrating Money and Commodity Markets — IS.', 1, '2021-08-10', '0000-00-00'),
(417, 'Business Communication and Value Science – II (BTCSH-112)', 4, 33, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(418, 'Linear Algebra (BTCSH-107)', 4, 34, 'Eigenvalues and Eigenvectors; Positive definite matrices; Linear transformations; Hermitian\nand unitary matrices;\n', 1, '2021-08-10', '0000-00-00'),
(419, 'Statistical Methods (BTCSH-108)', 4, 35, 'Comparison with parametric inference, Use of order statistics. Sign test, Wilcoxon signed rank\ntest, Mann-Whitney test, Run test, Kolmogorov-Smirnov test. Spearman’s and Kendall’s test.\nTolerance region.', 1, '2021-08-10', '0000-00-00'),
(420, 'Discrete Structures (BTIT-401)', 4, 36, 'Binary Composition and its Properties Definition of Algebraic Structure; Groyas Semi\nGroup, Monoid Groups, Abelian Group, Properties of Groups, Permutation Groups, Sub\nGroup, Cyclic Group, Rings and Fields (Definition and Standard Results).', 1, '2021-08-10', '0000-00-00'),
(421, 'Data Communication (BTCS-302)', 4, 37, 'Circuit, Message, Packet and Hybrid Switching Techniques.X.25, ISDN.Logical Addressing,\nIpv4, Ipv6, Address Mapping, ARP, RARP, BOOTP and DHCP, User Datagram Protocol,\nTransmission Control Protocol, SCTP.', 1, '2021-08-10', '0000-00-00'),
(422, 'Analysis and Design of Algorithms ( BTIT-305)', 4, 38, 'General Method, 8-Queens Problem, Graph Coloring, Hamiltonian Cycles, Sum of Subsets.\nBranch and Bound: Method, O/1 Knapsack Problem, Traveling Salesperson Problem,\nEfficiency Considerations, Techniques for Algebraic Problems, Some Lower Bounds on Parallel\nComputations.', 1, '2021-08-10', '0000-00-00'),
(423, 'Principles of Programming Languages (BTCS-303)', 4, 39, 'Fundamentals of Sub-Programs, Scope and Lifetime of Variable, Static and Dynamic Scope,\nDesign Issues of Subprograms and Operations, Local Referencing Environments, Parameter\nPassing Methods, Overloaded Sub-Programs, Generic Sub-Programs, Design Issues for\nFunctions Overloading and Overloaded Operators, Co-Routines.', 1, '2021-08-10', '0000-00-00'),
(424, 'Introduction to Core Java (BTIT-309)', 4, 40, 'String Handling, Exploring Java.Lang, Java.Util – The Collection Framework, Exploring\nJava.IO, Exploring Java. NIO.', 1, '2021-08-10', '0000-00-00'),
(425, 'Technical Presentation Skills (BTCS-610)', 4, 41, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(426, 'Web Development Lab-II (PHP/JSP) ( BTIT-407)', 4, 42, 'Use Cookie to Store and Retrieve Data, Use Querystring to Transfer Data, Create Session\nVariable and Handle Session, Starting and Destroying Session Working with Session Variables,\nPassing Session IDs, Handle Runtime Errors Through Exception Handling, Error Types in\nPHP. Database Connectivity Using MYSQL:Concepts and Installation Of Mysql, Mysql\nStructure and Syntax, Types of Mysql Tables and Storage Engines, Mysql Commands,\nIntegration of PHP with Mysql, Connection to the Mysql Database, Creating And Deleting\nMysql Database Using PHP,Updating, Inserting, Deleting Records in the Mysql Database,\nHosting Website (Using “C” Panel,Using FileZillaSoftware)', 1, '2021-08-10', '0000-00-00'),
(427, 'Cloud Computing: Project Based Learning (BTIBM-401)', 4, 43, 'CLOUD AND AI\n• AI Industry Adoption\n• AI Evolution\n• Empowered Cloud Apps with AI Summary & resources CLOUD FOR MULTI-CHANNEL\n• The Need for a Multi-channel platform • Multi-channel platform characteristics\n• Rapid and Intelligent Summary and resources', 1, '2021-08-10', '0000-00-00'),
(428, 'Unix and Shell Programming Lab (BTIT-406)', 4, 44, 'Command line arguments,Positional parameters, Set & shift, IFS. Functions & file\nmanipulations: Processing file line by line, Functions. Regular Expression & Filters: Regular\nexpression, Grep, cut, sort commands, Grep patterns.', 1, '2021-08-10', '0000-00-00'),
(429, 'Computational Learning (AI) (BTAI-301)', 4, 45, 'Learning with Hidden Variables; Hidden Variables and Missing Data, Expectation\nMaximization, Extensions of EM, Optimizing the Likelihood by Gradient Methods.\nOptimization: Optimization Unconstrained Smooth Convex Minimization, Constrained\nOptimization, Stochastic Optimization, Non-convex Optimization', 1, '2021-08-10', '0000-00-00'),
(430, 'Object Oriented Programming Using Java (BTCS-308)', 4, 46, 'Java development tools in Eclipse V3.5 Use the Java development tools in Eclipse V3.5, Debug\nJava programs, Describe Java EE component model and its use in building server- side\napplications, Develop, debug, and test server-side applications.', 1, '2021-08-10', '0000-00-00'),
(431, 'RedHat Administration-III (RH254)', 4, 47, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(432, 'Introduction to Information Technology (BTIT-101)', 4, 48, 'Introduction, Components of Multimedia and Challenges, Video Compression, Video Coding\nTechnology: JPEG, MPEG, and JBIG. Introduction to Cloud Computing: Types, Services,\nModels, Characteristics, Benefits and Challenges, Application, Limitations.', 1, '2021-08-10', '0000-00-00'),
(433, 'Cyber Ethics and Social Media Analysis(ICS) ( BTICS-301)', 4, 49, 'Social Ties and Information Diffusion. Social Ties and Link Prediction, Social Network\nAnalysis and online social networks -Concepts: How Services such as Facebook, LinkedIn,\nTwitter, Couch Surfing, etc. are using SNA to understand their users and improve their\nfunctionality.', 1, '2021-08-10', '0000-00-00'),
(434, 'Technical Presentation Skills (BTCS-610)', 4, 50, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(435, 'Mobile App Development III iOS (BTCSMOB-301)', 4, 51, 'App life Cycle, break down the delegate, Protocols methods: Did Finish Launching, Will Resign\nActive, Did Enter Background, Will Enter Foreground, Did Become Active, Will Terminate.\nView Controller life Cycle: viewDidLoad, viewWillappear , viewDidappear, viewWillDisappear.', 1, '2021-08-10', '0000-00-00'),
(436, 'Object Oriented Programming (BTCSCS-203)', 4, 52, 'Operator overloading, Inheritance – Single and Multiple, Class Hierarchy, Pointers to Objects,\nAssignment of an Object to another Object, Polymorphism through dynamic binding, Virtual\nFunctions, Overloading, overriding and hiding, Error Handling', 1, '2021-08-10', '0000-00-00'),
(437, 'Computational Statistics (BTCSCS-204)', 4, 53, 'Factor analysis model, Extracting common factors, determining number of factors,\nTransformation of factor analysis solutions, Factor scores.', 1, '2021-08-10', '0000-00-00'),
(438, 'Software Engineering (BTCSCS-205)', 4, 54, 'Introduction to Software Requirements Specifications (SRS) and requirement elicitation\ntechniques;techniques for requirement modeling – decision tables, event tables, state transition\ntables, Petri nets;requirements documentation through use cases; introduction to UML,\nintroduction to softwaremetrics and metrics based control methods; measures of code and\ndesign quality.\nObject Oriented Analysis, Design and Construction:\nConcepts -- the principles of abstraction, modularity, specification, encapsulation and\ninformation hiding; concepts of abstract data type; Class Responsibility Collaborator (CRC)\nmodel; quality of design; design measurements; concepts of design patterns; Refactoring; object\noriented construction principles; object oriented metrics.', 1, '2021-08-10', '0000-00-00'),
(439, 'Financial Management (BTCSMS-206)', 4, 55, 'Overview, Working Capital Issues, Financing Current Assets (Short Termand Long Term Mix), Combining Liability Structures and Current Asset Decisions, Estimation of\nWorkingCapital.', 1, '2021-08-10', '0000-00-00'),
(440, 'Formal Language and Automata Theory (BTCSCS-201)', 4, 56, 'Context-sensitive grammars (CSG) and languages, linear bounded automata and equivalence\nwith CSG. Turing machines: The basic model for Turing machines (TM), Turing\nrecognizable(recursively enumerable) and Turing-decidable (recursive) languages and their\nclosure properties, variants of Turing machines, nondeterministic TMs and equivalence with\ndeterministic TMs, unrestricted grammars and equivalence with Turing machines, TMsas\nenumerators.', 1, '2021-08-10', '0000-00-00'),
(441, 'Computer Organization and Architecture (BTCSCS-202)', 4, 57, 'Input-output subsystems, I/O device interface, I/O transfers – program controlled, interrupt\ndriven and DMA, privileged and non-privileged instructions, software interrupts and\nexceptions. Programs and processes – role of interrupts in process state transitions, I/O device\ninterfaces – SCII, USB', 1, '2021-08-10', '0000-00-00'),
(442, 'Environment and Energy Studies (ML-301)', 4, 58, 'Introduction - Definition: genetic, species and ecosystem diversity. Bio-geographical\nclassification of India - Value of biodiversity: consumptive use, productive use, social, ethical,\naesthetic and option values - . Biodiversity at global, National and local levels. - . India as a\nmegadiversity nation - Hot-sports of biodiversity - Threats to biodiversity: habitat loss,\npoaching of wildlife, manwildlife conflicts; Conservation of biodiversity: In-situ and Exsitu\nconservation. National biodiversity act.\n', 1, '2021-08-10', '0000-00-00'),
(443, 'Computer Networks(BTIT-502)', 4, 59, 'Need, Services Provided, Design issues, Routing and congestion in network layer, wired &\nwireless routing protocol examples, Routing algorithms: Least Cost Routing algorithm,\nDijkstra\'s algorithm, Bellman-ford algorithm, Hierarchical Routing, Broadcast Routing, Multi\ncast Routing. IP protocol, IP Addresses, subnetting, Comparative study of IPv4 & IPv6, Mobile\nIP.', 1, '2021-08-10', '0000-00-00'),
(444, 'Operating Systems (BTCS-502)', 4, 60, 'concepts, functions, logical and physical address space, address binding, degree of\nmultiprogramming, swapping, static & dynamic loading- creating a load module, loading, static\n& dynamic linking, shared libraries, memory allocation schemes- first fit, next fit, best fit, worst\nfit and quick fit. Free space management- bitmap, link list/free list. Virtual Memory- concept,\nvirtual address space, paging scheme, pure segmentation and segmentation with paging scheme\nhardware support and implementation details, memory fragmentation, demand paging\n,working set model, page fault frequency, thrashing, page replacement algorithms- optimal,\nFIFO,LRU; Bleady’s anomaly; TLB ( translation look aside buffer).', 1, '2021-08-10', '0000-00-00'),
(445, 'Advanced Java Programming (BTCS-409)', 4, 61, 'ORM and J2EE Frameworks: Introduction to Frameworks:- Struts, Spring basics, Spring AOP\n, Introduction to JavaScript and JQuery', 1, '2021-08-10', '0000-00-00'),
(446, 'Unix and Shell Programming Lab (BTIT-406)', 4, 62, 'Command line arguments,Positional parameters, Set & shift, IFS. Functions & file\nmanipulations: Processing file line by line, Functions. Regular Expression & Filters: Regular\nexpression, Grep, cut, sort commands, Grep patterns.', 1, '2021-08-10', '0000-00-00'),
(447, 'Mobile App Development Lab (BTIT-306)', 4, 63, 'Intents and Service: Android ,Intents and Services , Characteristics of Mobile Applications,\nSuccessful Mobile Development, Storing and Retrieving Data, Synchronization and Replication\nof Mobile Dat, Android Storing and Retrieving Data ,Working with a Content Provider,\nCommunications Via Network and the Web, State Machine, Correct Communications Model', 1, '2021-08-10', '0000-00-00'),
(448, 'Advanced Java (BTCS-307)', 4, 64, 'Java Server Pages : JSP Overview: The Problem with Servlets, Life Cycle of JSP Page, JSP\nProcessing, JSP Application Design with MVC, Setting Up the JSP Environment ,JSP\nDirectives, JSP Action, JSP Implicit Objects JSP Form Processing, JSP Session and Cookies\nHandling, JSP Session Tracking JSP Database Access, JSP Standard Tag Libraries, JSP\nCustom Tag, JSP Expression Language, JSP Exception Handling, JSP XML Processing', 1, '2021-08-10', '0000-00-00'),
(449, 'Application Development Using Python (BTIBM-403)', 4, 65, 'RE Pattern Matching, Parsing Data, Introduction to Regression, Types of Regression, Use\nCases, Exploratory data analysis, Correlation Matrix, Visualization using Metplotlib,\nImplementing linear regression', 1, '2021-08-10', '0000-00-00'),
(450, 'Application Development and deployment using IOT (BTIBMC-701)', 4, 66, 'IoT Solution Anatomy –\nIoT Data Platform: IoT Platform Layer, Data Analytics and applications Layer, Resources', 1, '2021-08-10', '0000-00-00'),
(451, 'Database Management Systems ( BTCS-405)', 4, 67, 'Query Optimization:\nIntroduction, steps of optimization, various algorithms to implement select, project and join\noperations of relational algebra, optimization methods: heuristic based, cost estimation based.\nTransaction Processing, Concurrency Control and Recovery Management:\nTransaction Model properties, State Serializability, Lock base protocols, Two Phase Locking,\nTime Stamping Protocols for Concurrency Control, and Validation Based Protocol, Multiple\nGranularities, Granularity of Data Item. Multi version schemes, Recovery with Concurrent\nTransaction, Recovery technique based on Deferred Update and Immediate Update, Shadow\nPaging, Recovery in Multi Database System and Database Backup and Recovery from\nCatastrophic Failure.', 1, '2021-08-10', '0000-00-00'),
(452, 'Advanced Java Programming (BTCS-409)', 4, 68, 'ORM and J2EE Frameworks: Introduction to Frameworks:- Struts, Spring basics, Spring AOP\n, Introduction to JavaScript and JQuery', 1, '2021-08-10', '0000-00-00'),
(453, 'Red Hat Application Development I - Java EE (JB-183)', 4, 69, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(454, 'System Programming (BTCS-410)', 4, 70, 'Introduction, Interrupt Handlers, Top Halves versus Bottom Halves,Registering an Interrupt\nHandler, Writing an Interrupt Handler, Interrupt Context, Implementing Interrupt Handlers,\nInterrupt Control.', 1, '2021-08-10', '0000-00-00'),
(455, 'Mobile Application Development IV Android (BTCSMOB-401)', 4, 71, 'AutoCompleteTextView, ListView RatingBar, WebView, SeekBar, DatePicker, TimePicker\nanalog and Digital,ProgressBar, ScrollView Vertical and Horizontal,\nImageSwitcher,ImageSlider, TabLayout , Tablayout with FrameLayout, SearchView,\nSearchView on Toolbar , EditText with TextWatcher.', 1, '2021-08-10', '0000-00-00'),
(456, 'Database Management Systems (BTCSCS-210)', 4, 72, 'Indices, B-trees, Hashing. Transaction processing: Concurrency control, ACID property,\nSerializability ofscheduling, Locking and timestamp based schedulers, Multiversion and\noptimisticConcurrency Control schemes, Database recovery.', 1, '2021-08-10', '0000-00-00'),
(457, 'Software Design with UML (BTCSCS-211)', 4, 73, 'Dynamic Model: State Diagram / Activity Diagram.\n• Description of the State Diagram. • Events Handling.\n• Description of the Activity Diagram.\n• Exercise in State Machines. Component Diagram Model.\n• Physical Aspect.\n• Logical Aspect.\n• Connections and Dependencies.\n• User face.\n• Initial DB design in a UML environment.', 1, '2021-08-10', '0000-00-00'),
(458, 'Introduction to Innovation, IP Management and Entrepreneurship (BTCSIIE-212)', 4, 74, 'Entrepreneurship- Financial Planning:\n• Financial Projections and Valuation\n• Stages of financing • Debt, Venture Capital and other forms of Financing Intellectual Property\nRights (IPR)\n• Introduction and the economics behind development of IPR: Business Perspective\n• IPR in India – Genesis and Development\n• International Context\n• Concept of IP Management, Use in marketing', 1, '2021-08-10', '0000-00-00'),
(459, 'Business Communication and Value Science – III (BTCSIIE-213)', 4, 75, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(460, 'Operations Research (BTCSMS-214)', 4, 76, 'Project definition, Project scheduling techniques – Gantt chart, PERT & CPM, Determination\nofcritical paths, Estimation of Project time and its variance in PERT using statistical principles,\nConceptof project crashing/time-cost trade-off. Inventory Control: Functions of inventory and\nits disadvantages, ABC analysis, Concept of inventory costs, Basics ofinventory policy (order,\nlead time, types), Fixed order-quantity models – EOQ, POQ & Quantitydiscount models. EOQ\nmodels for discrete units, sensitivity analysis and Robustness, Special cases ofEOQ models for\nsafety stock with known/unknown stock out situations, models under prescribedpolicy,\nProbabilistic situations.', 1, '2021-08-10', '0000-00-00'),
(461, 'Operating Systems (BTCSCS-209)', 4, 77, 'Basic concept, Logical and Physical address maps, Memoryallocation: Contiguous Memory\nallocation – Fixed and variable partition–Internal and External fragmentation and Compaction.\nVirtual Memory: Basics of Virtual Memory – Hardware and control structures – Localityof\nreference, Page allocation, Partitioning, Paging, Page fault, Working Set, Segmentation,\nDemand paging, PageReplacement algorithms: Optimal, First in First Out (FIFO), Second\nChance (SC), Notrecently used (NRU) and Least Recently used (LRU). I/O Hardware: I/O\ndevices, Device controllers, Direct Memory Access, Principles of I/O.', 1, '2021-08-10', '0000-00-00'),
(462, 'Computer Graphics and Multimedia (BTCS-503)', 4, 78, '3D Geometric Transformations and 3D Viewing Classification of Visible\nSurface Detection algorithm:-\nTranslation,Rotation, Scaling\nOther transformations:-\nReflection,Rotation about an arbitrary axis Composite transformations Projections,Back\nSurface detection method Depth Buffer method Scan line method BSP tree method, Area\nSubdivision method.', 1, '2021-08-10', '0000-00-00'),
(463, 'Software Engineering and Project Management (BTCS-504)', 4, 79, 'Approach: Issues, Validation Testing and Their Criteria, System Testing, Alpha-Beta Testing,\nDebugging, Testing Conventional Applications, Testing Object Oriented Applications ,Testing\nWeb Applications.', 1, '2021-08-10', '0000-00-00'),
(464, 'Artificial Intelligence (BTCS-511)', 4, 80, 'MDP formulation, utility theory, utility functions, value iteration, policy iteration and partially\nobservable MDPs.', 1, '2021-08-10', '0000-00-00'),
(465, 'CYBER AND NETWORK SECURITY (BTIT-603)', 4, 81, 'Cyber crime and the Legal Landscape around the World, Why Do We Need Cyber laws, The\nIndian IT Act, Challenges to Indian Law and Cybercrime Scenario in India, Information\nTechnology Act, Digital Signature and the IT Act, Cybercrime and Punishment. Introduction to\nCyber Forensics, Historical Background of Cyber Forensics, Cyber Forensics and Digital\nEvidence, Forensic Analysis of E-Mail, Digital Forensic Life Cycle, Approaching Computer\nForensic Investigation, Relevance of OSI Model to Computer Forensic, Challenges in Computer\nForensic.', 1, '2021-08-10', '0000-00-00'),
(466, 'WIRELESS COMMUNICATION NETWORKS (BTIT-511)', 4, 82, 'Introduction, Comparisons of multiple Access StrategiesTDMA, CDMA, FDMA, OFDM,\nCSMA Protocols. Mobile Network And Transport Layers :Mobile IP , Dynamic Host\nConfiguration Protocol, Mobile Ad Hoc Routing Protocols, Multicast routing,TCP over\nWireless Networks , Indirect TCP , Snooping TCP, Mobile TCP .Wireless Systems: GSM\nsystem architecture, Radio interface, Protocols, Localization and calling, Handover,\nAuthentication and security in GSM, GSM speech coding, Concept of spread spectrum, CDMA\nforward channels, CDMA reverse channels, Soft hand off, CDMA features, Power control in\nCDMA, Performance of CDMA System, GPRS system architecture.', 1, '2021-08-10', '0000-00-00'),
(467, 'MANAGEMENT INFORMATION SYSTEM (BTIT-513)', 4, 83, 'Introduction, Decision making with MIS-Tactical decisionsoperational\ndecisions-strategic decisions, communication in organizations-\ntypes of communicationexamples of communications in organizations-\ndecision making with communication technology', 1, '2021-08-10', '0000-00-00'),
(468, 'INFORMATION STORAGE AND MANAGEMENT (BTIT-611)', 4, 84, 'memory, network, server, storage & appliances. Data centre concepts & requirements, Backup\nand disaster recovery. Industry Management standards, standard framework applications, Key\nmanagement metrics.', 1, '2021-08-10', '0000-00-00'),
(469, 'ENTERPRISE RESOURCE PLANNING (BTIT-712)', 4, 85, '1. ERP modules & Vendors Finance Production planning, control & maintenance Sales &\nDistribution Human Resource Management (HRM)\n2. Inventory Control System.\n3. Quality Management ERP Market', 1, '2021-08-10', '0000-00-00'),
(470, 'Programming with Python (BTCS-407)', 4, 86, 'Search Algorithms, Sorting Algorithms, Hashtables. Plotting and more about Classes: Plotting\nusing PyLab, Plotting mortgages and extended examples.', 1, '2021-08-10', '0000-00-00'),
(471, 'Scripting Languages (BTCS-607)', 4, 87, 'Introduction to Perl and scripting, scripts, programs, Web scripting and PERL names , values,\nvariable, scalar expression, control structures, arrays, list, hashes, strings, patterns, and regular\nexpression, subroutine.', 1, '2021-08-10', '0000-00-00'),
(472, 'Big Data Technologies (BTIBMB-601)', 4, 88, 'Data Processing and Management - MapReduce and YARN MapReduce model v1, the\nlimitations of Hadoop 1 and MapReduce, review the Java code required to handle the Mapper\nclass the, Reducer class and the program driver needed to access MapReduce, the YARN model,\ncompare Hadoop 2/YARN with Hadoop 1.', 1, '2021-08-10', '0000-00-00'),
(473, 'Predictive Analytics (BTIBDA-501)', 4, 89, 'Overview of modeling techniques, Machine Learning techniques, Accuracy Precision & recall,\nModel Deployment.', 1, '2021-08-10', '0000-00-00'),
(474, 'Micro services Architecture and Implementation (BTIBM-601)', 4, 90, 'what is kubernates strength and architecture, Master & worker node component, kubernate\nbuilding blocks, Deploying Applications on kubernates, Helm, Application center components,\nPoD health checking, Health check and kubectl example, Cloud application component\narchitecture, Benefits of using Kubernetes with IBM container.', 1, '2021-08-10', '0000-00-00'),
(475, 'Predictive Modelling (BTIBMA-501)', 4, 91, 'Model Deployment Introduction of different techniques of modeling and Machine Learning,\nConfusion Matrix: Accuracy, Precision & Recall. Model Selection and Deployment.', 1, '2021-08-10', '0000-00-00'),
(476, 'Cloud Computing (BTCS-701)', 4, 92, 'Using Cloud ServicesCloud collaborative applications and services – case studies with\ncalendars, schedulers and event management; cloud applications in project management.\nAmazon Web Services & applications, AWS EC2, S3, Cloud Analytics, Cloud Open Stack', 1, '2021-08-10', '0000-00-00'),
(477, 'Computer Architecture and Microprocessor (BTCS-509)', 4, 93, 'Introduction to microprocessor, 8085 microprocessor, 8085 Pin Functions, Architecture,\nRegister Set, Flag Classification, ALU and control & timing unit, Memory Interfacing,\nInterfacing Input Output Devices, Memory-Mapped I/O. Timing diagram for I/O and memory\nread/write cycle.8086 MicroprocessorArchitecture of 8086 Microprocessor, pin diagram,\nregisters organization, memory organization, Segments, Interrupts of 8086.', 1, '2021-08-10', '0000-00-00'),
(478, 'RedHat Open Stack and Ansible (CLDO-507)', 4, 94, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(479, 'Network Security And Cryptography (BTICS-501)', 4, 95, 'Overview of Asymmetric key Cryptography, RSA algorithm, Symmetric & Asymmetric key\nCryptography together, Diffie-Hellman Key Exchange, Digital Signature, Basic concepts of\nMessage Digest and Hash Function. Man in Middle Attack,DoS and DDoS Attacks.', 1, '2021-08-10', '0000-00-00'),
(480, 'Ethical Hacking Lab-1 (BTICS-502)', 4, 96, 'Malware threats, penetration testing by creating backdoorsTools and Methods Used in\nCybercrime, Proxy Server and Anonymizers, Phishing and Identity Theft, Password Cracking,\nKeylogger and Spyware, Virus and Worms, Trojan Horse and Backdoors, Steganography DoS\nand DDoS Attacks, SQL Injection, Buffer Overflow, Attack on Wireless Networks.Use of Tool\nNessus .', 1, '2021-08-10', '0000-00-00'),
(481, 'Theory of Computation (BTCS-501)', 4, 97, 'Description and definition, Instantaneous Description, Language of PDA, Acceptance by Final\nstate, Acceptance by empty stack, Deterministic PDA, Equivalence of PDA and CFG, CFG to\nPDA and PDA to CFG.', 1, '2021-08-10', '0000-00-00'),
(482, 'Internet of Things (BTCS-602)', 4, 98, 'Unstructured data storage on cloud/local server, Authentication, authorization of devices.', 1, '2021-08-10', '0000-00-00'),
(483, 'Cloud Computing (BTCS-701)', 4, 99, 'Using Cloud ServicesCloud collaborative applications and services – case studies with\ncalendars, schedulers and event management; cloud applications in project management.\nAmazon Web Services & applications, AWS EC2, S3, Cloud Analytics, Cloud Open Stack', 1, '2021-08-10', '0000-00-00'),
(484, 'Data Science (BTCS-608)', 4, 100, 'Over fitting and train/test splits, Types of Machine learning – Supervised, Unsupervised,\nReinforced learning, Introduction to Bayes Theorem, Linear Regression- model assumptions,\nregularization (lasso, ridge, elastic net), Classification and Regression algorithms- Naïve Bayes,\nK-Nearest Neighbors, logistic regression, support vector machines (SVM), decision trees, and\nrandom forest, Classification Errors, Analysis of Time SeriesLinear Systems Analysis,\nNonlinear Dynamics, Rule Induction, Neural Networks- Learning And Generalization,\nOverview of Deep Learning.', 1, '2021-08-10', '0000-00-00'),
(485, 'Simulation and Modeling (BTCS-612)', 4, 101, 'Verification of Simulation Models, Calibration and Validation of Models, Validation of Model\nAssumptions , Validating Input & Output Transformations, Design of simulation experiments,', 1, '2021-08-10', '0000-00-00'),
(486, 'Software Testing and Quality Assurance (BTCS-613)', 4, 102, 'Functional testing-non-Functional testing-acceptancetestingperformance testing –Factors and\nMethodology for Performance testing, Regression testingMethodology for Regression testing.Five Views of Software Quality, McCall’s Quality Factors and Criteria, Quality Factors,\nQuality Criteria, Relationship between Quality Factors and Criteria, Quality Metrics, Quality\nCharacteristics, Software Quality Standard', 1, '2021-08-10', '0000-00-00'),
(487, 'Block Chain (BTCS-618)', 4, 103, 'Cross border payments, Know Your Customer (KYC), Food Security, Mortgage over Block\nchain, Block chain enabled Trade, We Trade – Trade Finance Network, Supply Chain\nFinancing, Identity on Block chain.', 1, '2021-08-10', '0000-00-00'),
(488, 'Robotics (BTCS-617)', 4, 104, 'Basics of control: Transfer functions, Control laws: P, PD, PID. Non-linear and advanced\ncontrols.', 1, '2021-08-10', '0000-00-00'),
(489, 'IT WorkshopSciLab/MATLAB (BTIT-608)', 4, 105, 'Scripts, Functions, Global Variables, Passing String Arguments to Functions, eval Function,\nFunction Handles, Vectorization , Pre allocation. OTHER DATA STRUCTURE:\nMultidimensional Arrays, Cell Arrays, Characters and Text, Structures', 1, '2021-08-10', '0000-00-00'),
(490, 'Minor Project (BTCS-606)', 4, 106, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(491, 'Object Oriented Analysis and Design (BTIT-604)', 4, 107, '\nEstimating Performance, Making a reuse plan, breaking system into sub systems\nidentifying concurrency, allocation of subsystems, management of data storage,\nHandling Global resources, choosing a software control strategy,\nHandling boundary condition, common Architectural style.', 1, '2021-08-10', '0000-00-00'),
(492, 'Micro services Architecture and Implementation (BTIBM-601)', 4, 108, 'Cloud Application Component Architecture, Benefits of using Kubernetess with IBM\nContainers, About Microservices ,monolithic application, microservice security, api\nmanagement and gateways, the future of microservices, microservices governance', 1, '2021-08-10', '0000-00-00'),
(493, 'Big Data Engineering - Spark & Scala (BTIBMB-602)', 4, 109, 'BigSQL Overview of Big SQL, Understanding how Big SQL fits in the Hadoop architecture,\nStart and stop Big SQL using Ambari and command line, Connecting to Big SQL using\ncommand line, Connecting to Big SQL using IBM Data Server Manager, Starting Hadoop\ncomponents, Executing basic Big SQL statements, Describing and creating Big SQL schemas\nand tables, Describing and listing the Big SQL data types, Working with various Big SQL\nDDLs, Loading data into Big SQL tables using best practices, Creating and dropping simple Big\nSQL table, Creating sample tables, Moving data into HDFS, Loading data into Big SQL tables,\nCreating and working with views, Creating external tables, Describing Big SQL supported file\nformats, Query Big SQL tables using various DMLs, Connecting to Big SQL, Query data with\nBig SQL, Working with the ARRAY type, Working with Big SQL functions, Storing data in an\nalternate file format (Parquet), Configuring the Big SQL Server, Configuring the Big SQL\nScheduler, Backup and rest', 1, '2021-08-10', '0000-00-00'),
(494, 'Big Data Technologies (Hadoop) (BTIBMC-602)', 4, 110, 'MapReduce model v1, the limitations of Hadoop 1 and MapReduce, review the Java code\nrequired to handle the Mapper class, Reducer class and the program driver needed to access\nMapReduce, the YARN model, compare Hadoop 2/YARN with Hadoop 1', 1, '2021-08-10', '0000-00-00'),
(495, 'Artificial Intelligence (BTIBMC-601)', 4, 111, 'MACHINE LEARNING AND DEEP LEARNING Machine Learning Explained, Various\nAlgorithms of Machine Learning, Deep Learning Explained, Deep learning ecosystem,\nExperiments, Explain what neural networks are and why they are important in today’s AI’s\nfield Explain what domain adaptation is and its applications Summary& Resources.', 1, '2021-08-10', '0000-00-00'),
(496, 'CYBER AND NETWORK SECURITY (BTIT-603)', 4, 112, 'Cyber crime and the Legal Landscape around the World, Why Do We Need Cyber laws, The\nIndian IT Act, Challenges to Indian Law and Cybercrime Scenario in India, Information\nTechnology Act, Digital Signature and the IT Act, Cybercrime and Punishment. Introduction to\nCyber Forensics, Historical Background of Cyber Forensics, Cyber Forensics and Digital\nEvidence, Forensic Analysis of E-Mail, Digital Forensic Life Cycle, Approaching Computer\nForensic Investigation, Relevance of OSI Model to Computer Forensic, Challenges in Computer\nForensic.', 1, '2021-08-10', '0000-00-00'),
(497, 'Introduction to container Kubernete and RedHat OpenShift and JBOSS (DOJB-603)', 4, 113, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(498, 'Ethical Hacking Lab-II (BTICS-602)', 4, 114, 'ARP and DNS\nPoisoning: Introduction, ARP spoofing, Introduction of MITM, defenses against DNS\nPoisoning.', 1, '2021-08-10', '0000-00-00'),
(499, 'Concepts of System Security (BTICS-601)', 4, 115, 'ARP and DNS\nPoisoning: Introduction, ARP spoofing, Introduction of MITM, defenses against DNS\nPoisoning.', 1, '2021-08-10', '0000-00-00'),
(500, 'Human Values and Professional Ethics (BBAI-501)', 4, 116, '1. Business Ethics its meaning and definition\n2. Types, Objectives, Sources, Relevance in Business organisations.\n3. Theories of Ethics, Codes of Ethics\nUnit V: Globalization and Ethics\n4. Sources of Indian Ethos & its impact on human behavior\n2. Corporate Citizenship and Social Responsibility – Concept (in Business),\n3. Work Ethics and factors affecting work Ethics.', 1, '2021-08-10', '0000-00-00'),
(501, 'Compiler Design ( BTCS-601)', 4, 117, 'Introduction, Principal Sources of Optimization, Optimization of basic Blocks, DAG\nrepresentation of Basic Blocks - Introduction to Global Data Flow Analysis, Runtime\nEnvironments, Source Language issues, Storage Organization, Storage Allocation strategies,\nAccess to non-local names, Parameter Passing, Error detection and recovery.', 1, '2021-08-10', '0000-00-00'),
(502, 'OBJECT ORIENTED ANALYSIS AND DESIGN ( BTIT-604)', 4, 118, 'Estimating Performance, Making a reuse plan, breaking system into sub systems identifying\nconcurrency, allocation of subsystems, management of data storage, Handling Global resources,\nchoosing a software control strategy, Handling boundary condition, common Architectural\nstyle.', 1, '2021-08-10', '0000-00-00'),
(503, 'BIG DATA AND HADOOP (BTCS-702)', 4, 119, 'Monitoring The HadoopCluster , Monitoring Hadoop Cluster, Monitoring Hadoop Cluster\nwith Nagios, Monitoring Hadoop Cluster, Real Time Example in Hadoop , Apache Log viewer\nAnalysis , Market Basket AlgorithmsBig Data Analysis in Practice , Case Study , Preparation of\nCase Study Report and Presentation , Case Study Presentation', 1, '2021-08-10', '0000-00-00'),
(504, 'Next Generation Telecommunication Networks (BTCC-703)', 4, 120, 'Next Generation Core NetworkThe role of the core network, Enabling Control and\nReconfigurability, Packet Switching (ATM, IP, MPLS, Ethernet), IP Multi-Media System\n(IMS), Principles of control for IP networks, Concept of IMS UNIT–V NGN Service\nAspectsServices on an NGN, Service compatibility with PSTN and IN, Use of APIs and service\nprovider interfaces, Brief review of the principles of mobile networks, Relationship of mobile\ndevelopments to NGN', 1, '2021-08-10', '0000-00-00'),
(505, 'Soft computing (BTCS-711)', 4, 121, 'Genetic Algorithm, Fundamentals, basic concepts, working principle, encoding, fitness function,\nreproduction, Genetic modeling: Inheritance operator, cross over, inversion & deletion,\nmutation operator, Bitwise operator, Generational Cycle, Convergence of GA, Applications &\nadvances in GA, Differences & similarities between GA & other traditional methods.', 1, '2021-08-10', '0000-00-00'),
(506, 'Quantum Computing (BTCS-715)', 4, 122, 'Basic techniques exploited by quantum algorithms, Amplitude amplification, Quantum Fourier\nTransform, Phase Kick-back, Quantum Phase estimation, Quantum Walks, Major Algorithms:\nShor’s Algorithm, Grover’s Algorithm, Deutsch’s Algorithm, Deutsch -Jozsa Algorithm,', 1, '2021-08-10', '0000-00-00'),
(507, 'Virtual Reality (BTCS-716)', 4, 123, 'Introduction, the eye, the ear, the somatic senses. VR Hardware: Introduction, sensor\nhardware, Head-coupled displays, Acoustic hardware, Integrated VR systems. VR Software:\nIntroduction, Modelling virtual world, Physical simulation, VR toolkits, Introduction to VRML', 1, '2021-08-10', '0000-00-00'),
(508, 'Project (BTCS-706)', 4, 124, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(509, 'Computer Graphics and Multimedia (BTCS-503)', 4, 125, '3D Geometric Transformations and 3D Viewing Classification of Visible\nSurface Detection algorithm:-\nTranslation,Rotation, Scaling\nOther transformations:-\nReflection,Rotation about an arbitrary axis Composite transformations Projections,Back\nSurface detection method Depth Buffer method Scan line method BSP tree method, Area\nSubdivision method.', 1, '2021-08-10', '0000-00-00'),
(510, 'Mobile and Cloud Security (BTICS-701)', 4, 126, 'Data Center Operations, Security challenge, Implement Five Principal Characteristics of Cloud\nComputing, Data center Security Recommendations. Encryption and Key Management:\nEncryption for Confidentiality and Integrity, Encrypting data at rest, Key Management\nLifecycle, Cloud Encryption Standards, Recommendations.', 1, '2021-08-10', '0000-00-00'),
(511, 'Cyber Investigation and Digital Forensic (BTICS-702)', 4, 127, 'Sterilizing Evidence Media, Acquiring Forensics Images, Acquiring Live Volatile Data, Data\nAnalysis, Metadata Extraction, File System Analysis, Performing Searches, Recovering Deleted,\nEncrypted, and Hidden files, Internet Forensics, Reconstructing Past Internet Activities and\nEvents, E-mail Analysis, Messenger Analysis: Yahoo, MSN, Gmail Chats.', 1, '2021-08-10', '0000-00-00'),
(512, 'DISTRIBUTED SYSTEM (BTIT-713)', 4, 128, 'Introduction Clocks, events and process states ,Synchronizing physical clocks, Logical time and\nlogical clocks , Global states , Coordination and Agreement, Distributed mutual exclusion,\nElections – Transactions and Concurrency Control– Transactions -Nested transactions – Locks\n– Optimistic concurrency control – Timestamp ordering – Atomic Commit protocols -\nDistributed deadlocks – Replication – Case study – Coda.', 1, '2021-08-10', '0000-00-00'),
(514, 'APPLIED PHYSICS(BTPH-101)', 5, 2, 'Wave Optics:\nIntroduction to Interference, Fresnel\'s Bi-prism, Interference in Thin films, Newton\'s rings\nexperiment, Michelson ’s interferometer and its application, Introduction to Diffraction and\nits Types, Diffraction at single slit, double slit, resolving power, Rayleigh criterion,Resolving power of grating, Concept of polarized light, Double refraction, quarter and half\nwave plate, circularly & elliptically polarized light', 1, '2021-08-10', '0000-00-00'),
(515, 'Introduction to Computer Science and Engineering(BTCS-102)', 5, 3, 'Computer Communication and Internet:\nComputers and Communication: Introduction to Computer Networks, Internet and World\nWide Web, Communication and Collaboration(Electronic Mail), Basic of electronic mail,\nWeb Browsers and Servers, Introduction to HTML, Use of Computer in Commerce,\nInternet Applications, Electronic Data Interchange, Electronic Payment System, Internet\nSecurity, Privacy, Ethical Issues & Cyber Law.', 1, '2021-08-10', '0000-00-00'),
(516, 'Digital Logic and Circuit Design(BTEC-104)', 5, 4, 'Semiconductor Memories and A/D and D/A converters:Semiconductor Memory – RAM, ROM Organization, operation and their Types, PLDPAL, PLA, PROM, FPGA, Analog to Digital (A/D)and Digital to Analog (D/A) converters\nand their types', 1, '2021-08-10', '0000-00-00'),
(517, 'Principles of \'C\' language (BTCS-104)', 5, 5, 'Concept of Files:\nFile Opening in Various Modes and Closing of a File, Reading from a File, Writing onto a File.', 1, '2021-08-10', '0000-00-00'),
(518, 'Programming Skills with \'C\' (BTCS-108)', 5, 6, 'File handling:\nConsole Input Output Functions, Disk Input Output Functions, Data files, Command Line\nArguments, Bitwise Operators, Enumerated Data Types, Type Casting, macros, The C\nPreprocessor, More About library Functions.', 1, '2021-08-10', '0000-00-00'),
(519, 'Web Development Lab-I(HTML & XML) (BTIT-307)', 5, 7, 'Java Script:\nIntroduction to client side scripting, Server side scripting, Java Script Syntax, Variables and\nFunctions, Operators: JavaScript Arithmetic Operators, JavaScript Assignment Operators,\nJavaScript Popup Boxes, JavaScript Window, Events and Objects, JavaScript Function Call,\nValidation in webpages, Introduction of AJAX', 1, '2021-08-10', '0000-00-00');
INSERT INTO `syllabus` (`id`, `name`, `unit_id`, `subject_id`, `syllabus_detail`, `status`, `created_at`, `updated_at`) VALUES
(520, 'Software Foundation and Programming ( 1. Clean Coding; 2. Javascript; 3. NodeRed; 4. NodeJS) (BTIBM-105', 5, 8, 'Installation and Configuration\nInstall NodeJS on command line.\nHands on: Create sample NodeJS + Express project using command line.\nInstall Node eclipse plugin\nHands-on: Create sample NodeJS + Express project using Eclipse\nFile System\nUnderstand__dirname and filename\nUnderstand synchronous vs Asynchronous file read.\nUnderstand View Templates.\nHow to serve static content in NodeJS\nConnecting to the database using NodeJS\nInstall and Setup MongoDB\nNodeJS Mongo Driver\nPerform CRUD Operation\nUnderstand Connection Pooling using NodeJS and Mongo Driver\nHands on Develop Web Application using Node JS and Mongo DB', 1, '2021-08-10', '0000-00-00'),
(521, 'Software Foundation and Programming 1 (with \'C\') (BTCS-105)', 5, 9, 'What is Linux and Why is so popular, What can you do with Linux, What is the Linux\nTechnology Center, Plans for the Future, Installing Linux, PHP What is PHP, Key driver of\nLamp Stack, Getting Started with PHP, PHP Data Object, PHP Deployment platform, What\nis ZEND Core, Features and benefits, What is Ruby, What is Rails, DB2 Application\ndevelopment Partners.', 1, '2021-08-10', '0000-00-00'),
(522, 'Red Hat Administration-I (RH-124)', 5, 10, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(523, 'Computer Peripherals and Interfaces ( BTCS-204 )', 5, 11, 'Magnetic Storage: Reading/Writing, hard disk drives, Floppy disk drives, Optical Storage\ndevices: CD-ROM drive, DVD-ROM drive, Keyboard: layouts, interfaces, Pointing devices,\nMouse, Monitors, Printers, Troubleshooting of device drivers and peripherals.', 1, '2021-08-10', '0000-00-00'),
(524, 'Mobile Application Development-I (BTCSMOB-101)', 5, 12, 'Control Flow: For-In Loops, While Loops: While, Repeat-While. Conditional\nStatements: If-else, Switch, Control Transfer Statements: continue , break , fallthrough , return\n, throw.', 1, '2021-08-10', '0000-00-00'),
(525, 'Principles of Electrical Engineering (BTCSH-104)', 5, 13, 'Introduction To Measuring Devices/Sensors and Transducers (Piezoelectric and Thermo Couple) Related to Electrical Signals, Elementary Methods for the Measurement of Electrical\nQuantities in DC and AC Systems(Current & Single-Phase Power). Electrical Wiring And\nIllumination System: Basic Layout Of The Distribution System, Types of Wiring System\n&Wiring Accessories, Necessity of Earthing, Types of Earthing, Safety Devices & System. For\nFurther Reading - Principle of Batteries, Types, Construction and Application, Magnetic\nMaterial and B-H Curve, Basic Concept of Indicating and Integrating Instruments.', 1, '2021-08-10', '0000-00-00'),
(526, 'Physics for Computing Science (BTCSH-105)', 5, 14, 'Einstein’s Theory of Matter Radiation Interaction and A and B Coefficients; Amplification of\nlight by Population Inversion, Different Types of Lasers: Ruby Laser, CO2 and Neodymium\nLasers; Properties of Laser Beams: Mono-Chromaticity, Coherence, Directionality and\nBrightness, Laser Speckles, Applications of Lasers in Engineering. Fiber Optics and\nApplications, Types of Optical Fibers.', 1, '2021-08-10', '0000-00-00'),
(527, 'Business Communication and Value Science – I (BTCSH-106)', 5, 15, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(528, 'Discrete Mathematics (BTCSH-101)', 5, 16, 'Propositional Calculus - Propositions and Connectives, Syntax; Semantics - Truthassignments\nand Truth Tables, Validity and Satisfiability, Tautology; Adequate Set of Connectives;\nEquivalence and Normal Forms; Compactness and Resolution; Formal Reducibility - Natural\nDeduction System and Axiom System; Soundness and Completeness.', 1, '2021-08-10', '0000-00-00'),
(529, 'Statistics, Probability and Calculus (BTCSH-102)', 5, 17, 'Basic Concepts of Differential and Integral Calculus, Application of Double and Triple Integral.', 1, '2021-08-10', '0000-00-00'),
(530, 'Fundamentals of Computer Science (BTCSCS-103)', 5, 18, 'Standard I/O, Formatted Output – printf, Formated Input – scanf, Variable length argument\nlist, File access including FILE structure, fopen, stdin, sdtout and stderr, Error Handling\nincluding exit, perror and error.h, Line I/O, Related miscellaneous functions Unix system\nInterface: File Descriptor, Low level I/O – read and write, Open, create, close and unlink,\nRandom access – lseek, Discussions on Listing Directory, Storage allocator Programming\nMethod: Debugging, Macro, User Defined Header, User Defined Library Function, Makefile\nUtility.', 1, '2021-08-10', '0000-00-00'),
(531, 'Mathematics-II ( BTMACS-201)', 5, 19, 'Axiomatic construction of the theory of probability, independence, conditional probability,\nand basic formulae, random variables, binomial, Poisson and normal random variable,\nprobability distributions, functions of random variables; mathematical expectations,\nDefinition and classification of random processes, discrete-time Markov chains.', 1, '2021-08-10', '0000-00-00'),
(532, 'Computer Peripherals and Interfaces ( BTCS-204 )', 5, 20, 'Magnetic Storage: Reading/Writing, hard disk drives, Floppy disk drives, Optical Storage\ndevices: CD-ROM drive, DVD-ROM drive, Keyboard: layouts, interfaces, Pointing devices,\nMouse, Monitors, Printers, Troubleshooting of device drivers and peripherals.', 1, '2021-08-10', '0000-00-00'),
(533, 'Data Structure and Algorithms (BTCS-403)', 5, 21, 'Sorting Concept and types of Sorting, Stable & Unstable sorting. Concept of Insertion Sort,\nSelection sort, Bubble sort, Quick Sort, Merge Sort, Heap & Heap Sort, Shell Sort & Radix\nsort. Algorithms and performance of Insertion, selection, bubble, Quick sort & Merge sort.', 1, '2021-08-10', '0000-00-00'),
(534, 'Computer System Organization ( BTCS-404 )', 5, 22, 'Multiprocessor organization, Instruction level pipelining and Superscalar Processors ,\nVector processing, Instruction and arithmetic pipelines, Vector and array processors,\nInterconnection structure and inter-processor communication, GPU.', 1, '2021-08-10', '0000-00-00'),
(535, 'Object Oriented Programming ( BTCS-305)', 5, 23, 'Exception Handling , TypeCasting ,Templates function and class in C++, Comparison Between\nC++ and Java, Features of Java ,Introduction to java, Inheritance, Interface and Abstract class\nin Java.', 1, '2021-08-10', '0000-00-00'),
(536, 'Programming Skills with \'C++\' ( BTCS-208 )', 5, 24, 'C++ Stream Classes, Unformatted I/O Operations, Formatted I/O operations, Classes for\nFile Streams, Opening and Closing a File: open() and close() functions, Manipulators of File\nPointers : seekg(), seekp(),tellg(), tellp() functions, Sequential Input and output Operations :\nput (), get(), write(), read() functions,Error handling File Operations : eof(), fail(), bad(),\ngood().', 1, '2021-08-10', '0000-00-00'),
(537, 'Communication Skills ( HUCS-101 )', 5, 25, 'Importance of Report, Types of Report, Structure of a Report.', 1, '2021-08-10', '0000-00-00'),
(538, 'Design Thinking ( BTIBM-203)', 5, 26, 'Understand how Make fits into the Loop ,Learn how to leverage Observe information,\nLearn Ideation, Storyboarding, & Prototyping, Understand user feedback and the Loop,\nLearn the different types of user feedback, Learn how to carry out getting feedback.', 1, '2021-08-10', '0000-00-00'),
(539, 'Agile Development Methodologies (DevOps + Agile) (BTIBM-202)', 5, 27, 'Advanced DevOps Concepts: Automatic Rollback, Automatic Provisioning. Introduction to\nDevOps on IBM Cloud: What is Cloud, IBM Cloud, DevOps Using IBM Cloud.', 1, '2021-08-10', '0000-00-00'),
(540, 'Agile Development Methodologies (BTIBM-201)', 5, 28, 'Scaling scrum, commonly used scaling frameworks, relationship between sprints and\nprogram increments, scrum@scale, product owner cycle, scrum master cycle, distributed\nscrum practices, distributed agile: good practices of successful teams, meeting faceto-face is\nthe only way to build trust, establish a shared project vision, establish continuous\nintegration (ci) with high test coverage across all teams, establish a synchronization and\ncommunication plan, establish a rigorous norming and chartering plan to achieve high\nquality use short sprints, scrum master at both locations, agile environments & tools, agile\nenvironments, the characteristics of an agile environment, the steps to create an agile\nenvironment, agile methodology tools, sprint ground, kanban vs scrum, differences between\nscrum and kanban, scheduling, extreme programming vs scrum', 1, '2021-08-10', '0000-00-00'),
(541, 'Red Hat Administration-II (RH-134)', 5, 29, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(542, 'Mobile Application Development-II (BTCSMOB-201)', 5, 30, 'Initializers, Default Property Values, Customizing Initialization, Initialization Parameters,\nParameter Names and Argument Labels, Initializer Parameters Without Argument Labels,\nOptional Property Types, Default Initializers, Initializer Delegation for Value Types, Class\nInheritance and Initialization, Initializer Inheritance and Overriding, Automatic Initializer\nInheritance, Failable Initializers, Failable Initializers for Enumerations, Overriding a Failable\nInitializer.', 1, '2021-08-10', '0000-00-00'),
(543, 'Principles of Electronics Engineering (BTCSH-110)', 5, 31, 'Difference between analog and digital signals, Boolean algebra, Basic and Universal Gates,\nSymbols, Truth tables, logic expressions, Logic simplification using K- map, Logic ICs, half and\nfull adder/subtractor, multiplexers, demultiplexers, flip-flops, shift registers, counters.', 1, '2021-08-10', '0000-00-00'),
(544, 'Fundamentals of Economics (BTCSH-111)', 5, 32, 'Business Cycles and Stabilization — Monetary and Fiscal Policy — Central Bank and the\nGovernment; The Classical Paradigm — Price and Wage Rigidities — Voluntary and\nInvoluntary Unemployment', 1, '2021-08-10', '0000-00-00'),
(545, 'Business Communication and Value Science – II (BTCSH-112)', 5, 33, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(546, 'Linear Algebra (BTCSH-107)', 5, 34, 'Singular value decomposition and Principal component analysis; Introduction to their\napplications in Image Processing and Machine Learning.', 1, '2021-08-10', '0000-00-00'),
(547, 'Statistical Methods (BTCSH-108)', 5, 35, 'Stationary, ARIMA Models:Identification, Estimation and Forecasting.', 1, '2021-08-10', '0000-00-00'),
(548, 'Discrete Structures (BTIT-401)', 5, 36, 'Introduction, Ordered Set, Hasse Diagram of Partially, Ordered Set, Isomorphic Ordered\nSet, Well Ordered Set, Properties of Lattices, Bounded and Complemented Lattices.\nCombinatorics: Introduction, Permutation and Combination, Binomial Theorem,\nMultinomial Coefficients Recurrence Relation and Generating Function: Introduction to\nRecurrence Relation and Recursive Algorithms, Linear Recurrence Relations with Constant\nCoefficients, Homogeneous Solutions, Particular Solutions, Total Solutions, Generating\nFunctions, Solution by Method of Generating Functions.', 1, '2021-08-10', '0000-00-00'),
(549, 'Data Communication (BTCS-302)', 5, 37, 'Domain Name Service Protocol, File Transfer Protocol, TELNET, WWW and Hyper Text\nTransfer Protocol, Simple Network Management Protocol, Simple Mail Transfer Protocol, Post\nOffice Protocol v3.', 1, '2021-08-10', '0000-00-00'),
(550, 'Analysis and Design of Algorithms ( BTIT-305)', 5, 38, 'Basic Concepts, Cook’s Theorem, NP Hard Graph and NP Scheduling Problems, Some\nSimplified NP Hard Problems.', 1, '2021-08-10', '0000-00-00'),
(551, 'Principles of Programming Languages (BTCS-303)', 5, 39, 'Abstractions and Encapsulation, Introductions to Data Abstraction, Static and Stack Based\nStorage Management. Heap Based Storage Management. Garbage Collection. Object Oriented\nProgramming in Smalltalk, C++, Java, C#, Php, Perl. Concurrency: Subprogram Level\nConcurrency, Semaphores, Monitors, Massage Passing, Java Threads, C# Threads.', 1, '2021-08-10', '0000-00-00'),
(552, 'Introduction to Core Java (BTIT-309)', 5, 40, 'Introduction to JDBC, JDBC Drivers & Architecture, CRUD Operation using JDBC', 1, '2021-08-10', '0000-00-00'),
(553, 'Technical Presentation Skills (BTCS-610)', 5, 41, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(554, 'Web Development Lab-II (PHP/JSP) ( BTIT-407)', 5, 42, 'Integrating Scripts in JSP, JSP Objects and Components, Configuration and\nTroubleshooting,JSP: Request and Response Objects, Retrievingthe Contents of An HTML\nForm, Retrievinga Query String, Working with Beans, Cookies, Creating and Reading Cookies.\nUsing Application Objects and Event Handling.', 1, '2021-08-10', '0000-00-00'),
(555, 'Cloud Computing: Project Based Learning (BTIBM-401)', 5, 43, 'CLOUD SECURITY\n• Cloud Security landscape\n• Security concerns in microservices\n• OAuth protocol Summary & resources\nDEVOPS FRAMEWORK\n• What is DevOps?\n• DecOps Agile Culture\n• DevOps Lifecycle', 1, '2021-08-10', '0000-00-00'),
(556, 'Unix and Shell Programming Lab (BTIT-406)', 5, 44, 'SED,Scripts, Operation, Addresses, commands, Applications, grep and sed. AWK: Execution,\nFields and Records, Scripts, Operations, Patterns, Actions, Associative Arrays, String\nFunctions, String Functions, Mathematical Functions, User – Defined Functions, Using System\ncommands in awk, Applications, awk and grep, sed and awk.', 1, '2021-08-10', '0000-00-00'),
(557, 'Computational Learning (AI) (BTAI-301)', 5, 45, 'Hypothesis Tests for Two classes, Error Probability in Hypothesis Testing, Upper Bounds on\nthe Bayes Error, Sequential Hypothesis Testing.', 1, '2021-08-10', '0000-00-00'),
(558, 'Object Oriented Programming Using Java (BTCS-308)', 5, 46, 'Servlet & JSP Develop and test servlets, Develop and test JSP pages, Learn how to use JSPs\nand servlets in accordance with the Model/View/Controller(MVC) programming model,\nDevelop, test, and use JSP custom tags', 1, '2021-08-10', '0000-00-00'),
(559, 'RedHat Administration-III (RH254)', 5, 47, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(560, 'Introduction to Information Technology (BTIT-101)', 5, 48, 'Introduction, Different Types of ECommerce with Examples, Advantages and Disadvantages,\nE-Commerce in India, E-Services, E-Commerce Security, Internet Security and Ethics,\nTechnology Issues, Social Issues, Introduction to E-Governance, Challenges, Application,\nAdvantages, Case Study of MP-online and IRCTC.', 1, '2021-08-10', '0000-00-00'),
(561, 'Cyber Ethics and Social Media Analysis(ICS) ( BTICS-301)', 5, 49, 'Privacy in a Networked World, Social Spam and Malicious Behavior, Sybil attack, distributed\ndenial of service attack, Leakage and Linkage of user information and content, predicting the\nfuture with social media, Friendship paradox and detection of contagions.', 1, '2021-08-10', '0000-00-00'),
(562, 'Technical Presentation Skills (BTCS-610)', 5, 50, 'No Syllabus Provided', 1, '2021-08-10', '0000-00-00'),
(563, 'Mobile App Development III iOS (BTCSMOB-301)', 5, 51, 'Gestures, Extensions, Delegation, Protocols, Closures, Handling Touches. Basic iOS\nAnimations: Timer, view based animations, UI dynamics , Alerts, Actions Sheets, Notifications,\nSegues. Persistence and Documents: User defaults, Core data, property list, Archiving and\nCodable, File system, File Manager & CloudKit, Working with the web.', 1, '2021-08-10', '0000-00-00'),
(564, 'Object Oriented Programming (BTCSCS-203)', 5, 52, 'Template concept, class template, function template, template specialization Input and Output:\nStreams, Files, Library functions, formatted output Object Oriented Design and Modelling:\nUML concept, Use case for requirement capturing, Class diagram, Activity diagram and\nSequence Diagram for design, Corresponding C++ code from design', 1, '2021-08-10', '0000-00-00'),
(565, 'Computational Statistics (BTCSCS-204)', 5, 53, 'Introduction, Types of clustering, Correlations and distances, clustering by partitioning\nmethods, hierarchical clustering, overlapping clustering, K-Means Clustering-Profiling and\nInterpreting Clusters.', 1, '2021-08-10', '0000-00-00'),
(566, 'Software Engineering (BTCSCS-205)', 5, 54, 'Introduction to faults and failures; basic testing concepts; concepts of verification and\nvalidation; black box and white box tests; white box test coverage – code coverage, condition\ncoverage, branch coverage; basic concepts of black-box tests – equivalence classes, boundary\nvalue tests, usage of state tables; testing use cases; transaction based testing; testing for non functional requirements – volume, performance and efficiency; concepts of inspection.', 1, '2021-08-10', '0000-00-00'),
(567, 'Financial Management (BTCSMS-206)', 5, 55, 'Cash Management:\nMotives for Holding cash, Speeding Up Cash Receipts, Slowing Down Cash Payouts,Electronic\nCommerce, Outsourcing, Cash Balances to maintain, Factoring. Accounts Receivable\nManagement: Credit & Collection Policies, Analyzing the Credit Applicant, CreditReferences,\nSelecting optimum Credit period. 4L', 1, '2021-08-10', '0000-00-00'),
(568, 'Formal Language and Automata Theory (BTCSCS-201)', 5, 56, 'Church-Turing thesis, universal Turing machine, the universal and diagonalization languages,\nreduction between languages and Rice s theorem, undecidable problems about languages. Basic\nIntroduction to Complexity: Introductory ideas on Time complexity of deterministic and\nnondeterministic Turing machines, P and NP, NP- completeness, Cook’s Theorem, other NP -\nComplete problems.', 1, '2021-08-10', '0000-00-00'),
(569, 'Computer Organization and Architecture (BTCSCS-202)', 5, 57, 'Pipelining:\nBasic concepts of pipelining, throughput and speedup, pipeline hazards. Parallel Processors:\nIntroduction to parallel processors, Concurrent access to memory and cache coherency.\nMemory organization: Memory interleaving, concept of hierarchical memory organization,\ncache memory, cache size vs. block size, mapping functions, replacement algorithms, write\npolicies.', 1, '2021-08-10', '0000-00-00'),
(570, 'Environment and Energy Studies (ML-301)', 5, 58, 'Environmental Policy, Legislation & EIA:\nEnvironmental Protection act, Legal aspects Air Act- 1981, Water Act, Forest Act, Municipal\nsolid waste management and handling rules, biomedical waste management and handling rules,\nhazardous waste management and handling rules. EIA: EIA structure, methods of baseline data\nacquisition. Overview on Impacts of air, water, biological and Socio- economical aspects.\nStrategies for risk assessment, Concepts of Environmental Management Plan(EMP).', 1, '2021-08-10', '0000-00-00'),
(571, 'Computer Networks(BTIT-502)', 5, 59, 'Transport Layer:\nOverview, Design Issues, UDP: Header Format, Per-Segment Checksum, Carrying\nUnicast/Multicast Real-Time Traffic, TCP: Connection Management, Reliability of Data\nTransfers, TCP Flow Control, TCP Congestion Control, TCP Header Format, TCP Timer\nManagement. Session layer: Overview, Authentication, Session layer protocol. Presentation\nlayer: Overview, Data conversion, Encryption and Decryption, Presentation layer protocol\n(LPP, Telnet, X.25 packet Assembler/Disassembler).Application Layer: Overview, WWW and\nHTTP, FTP, SSH.', 1, '2021-08-10', '0000-00-00'),
(572, 'Operating Systems (BTCS-502)', 5, 60, 'File Management:\nConcepts, Naming, Attributes, Operations, Types, Structure, File Organization & Access\n(Sequential, Direct ,Index Sequential) Methods, Memory Mapped Files, Directory Structures\nOne Level, Two Level, Hierarchical/Tree, Acyclic Graph, General Graph, File System\nMounting, File Sharing, Path Name, Directory Operations, Overview Of File System in Linux &\nWindows. Input/output Subsystems- Concepts, Functions/Goals, Input/Output devices- Block\nAnd Character, Spooling, Disk Structure & Operation, Disk Attachment, Disk Storage\nCapacity, Disk Scheduling Algorithm- FCFS, SSTF, Scan Scheduling, C-Scan Schedule.', 1, '2021-08-10', '0000-00-00'),
(573, 'Advanced Java Programming (BTCS-409)', 5, 61, 'Advance J2EE Topic: JavaMail 1.2(Sending and Receiving Mail, Mail body design, different\ncomponents), Java Messaging Service (JMS) 1.0.2 (Architecture, Programming Model,\nConnection, Session, Producer, Consumer), Java API for XML Parsing (JAXP) 1.1\n(Introduction, Parsing and XML, when to use SAX)', 1, '2021-08-10', '0000-00-00'),
(574, 'Unix and Shell Programming Lab (BTIT-406)', 5, 62, 'SED and AWK –\nSED,Scripts, Operation, Addresses, commands, Applications, grep and sed. AWK: Execution,\nFields and Records, Scripts, Operations, Patterns, Actions, Associative Arrays, String\nFunctions, String Functions, Mathematical Functions, User – Defined Functions, Using System\ncommands in awk, Applications, awk and grep, sed and awk.', 1, '2021-08-10', '0000-00-00'),
(575, 'Mobile App Development Lab (BTIT-306)', 5, 63, 'Android Networking and Web , Telephony, Wireless Connectivity and Mobile Apps,\nNotifications and Alarms, Memory Management, Graphics Performance and Multithreading,\nGraphics and UI Performance Android Graphics and MultimediaMobile Agents ,\nLocationMobility and Location Based Packaging and DeployingPerformance Best Practices.', 1, '2021-08-10', '0000-00-00'),
(576, 'Advanced Java (BTCS-307)', 5, 64, 'Java Server Faces2.0 : Introduction to JSF, JSF request processing Life cycle, JSF Expression\nLanguage, JSF Standard Component, JSF Facelets Tag, JSF Convertor Tag, JSF Validation\nTag, JSF Event Handling and Database Access, JSF Libraries: PrimeFaces', 1, '2021-08-10', '0000-00-00'),
(577, 'Application Development Using Python (BTIBM-403)', 5, 65, 'Machine Learning –\nAlgorithm, Algorithms – Random forest, Super vector Machine, Random Forest, Build your\nown model in python, Comparison between random forest and decision tree', 1, '2021-08-10', '0000-00-00'),
(578, 'Application Development and deployment using IOT (BTIBMC-701)', 5, 66, 'Cognitive IoT Solutions IoT Sensor Data and AI, Data Science on the Cloud, Resources IoT Industry Case Studies: IoT\nTrends, IoT in Manufacturing, Global Logistics with IoT, Worker Safety, Industry Predictions,\nResources', 1, '2021-08-10', '0000-00-00'),
(579, 'Database Management Systems ( BTCS-405)', 5, 67, 'Index structures:\nTypes of index (primary, secondary, clustering, partitioning, unique and non index), use and\nPurpose of index, searching via an index.\nSQL: DDL, DML, DQL (column function and grouping, union, multiple queries,\nunion all, sub-query using IN, NOT IN, HAVING, GROUP BY CLAUSE), DCL (grant, revoke),\nTCL (Commit, roll back, save point, set Transaction)\nDistributed database:\nPlanning for distributed database, management-centralized and decentralized Back-up and\nrecovery.', 1, '2021-08-10', '0000-00-00'),
(580, 'Advanced Java Programming (BTCS-409)', 5, 68, 'Advance J2EE Topic: JavaMail 1.2(Sending and Receiving Mail, Mail body design, different\ncomponents), Java Messaging Service (JMS) 1.0.2 (Architecture, Programming Model,\nConnection, Session, Producer, Consumer), Java API for XML Parsing (JAXP) 1.1\n(Introduction, Parsing and XML, when to use SAX)', 1, '2021-08-10', '0000-00-00'),
(581, 'Red Hat Application Development I - Java EE (JB-183)', 5, 69, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(582, 'System Programming (BTCS-410)', 5, 70, 'Timers:\nTime’s Data Structures, POSIX Clocks, Getting & Setting Time, Tuning the System Clock,\nSleeping and Waiting. Memory Management:The Process Address Space, Allocating Dynamic\nMemory, Advanced Memory Allocation, Stack-Based Allocations, Manipulating Memory,\nLocking Memory.', 1, '2021-08-10', '0000-00-00'),
(583, 'Mobile Application Development IV Android (BTCSMOB-401)', 5, 71, 'Android Storage and SQLite:\nStorage:Preferences , Internal Storage and External Storage. SQLite: SQLiteOpenHelper class\nand methods, SQLiteDatabase class and methods.', 1, '2021-08-10', '0000-00-00'),
(584, 'Database Management Systems (BTCSCS-210)', 5, 72, 'Database Security:\nAuthentication, Authorization and access control, DAC, MAC andRBAC models, Intrusion\ndetection, SQL injection. Advanced topics: Object oriented and object relational databases,\nLogical databases, Webdatabases, Distributed databases, Data warehousing and data mining.', 1, '2021-08-10', '0000-00-00'),
(585, 'Software Design with UML (BTCSCS-211)', 5, 73, 'Deployment Model. • Processors.\n• Connections.\n• Components.\n• Tasks. • Threads.\n• Signals and Events.', 1, '2021-08-10', '0000-00-00'),
(586, 'Introduction to Innovation, IP Management and Entrepreneurship (BTCSIIE-212)', 5, 74, 'Types of Intellectual Property\n• Patent- Procedure, Licensing and Assignment, Infringement and Penalty\n• Trademark- Use in marketing, example of trademarks- Domain name\n• Geographical Indications- What is GI, Why protect them?\n• Copyright- What is copyright\n• Industrial Designs- What is design? How to protect? Class Discussion- Major Court battles\nregarding violation of patents between corporate companies', 1, '2021-08-10', '0000-00-00'),
(587, 'Business Communication and Value Science – III (BTCSIIE-213)', 5, 75, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(588, 'Operations Research (BTCSMS-214)', 5, 76, 'Definitions – queue (waiting line), waiting costs, characteristics (arrival, queue, service\ndiscipline) ofqueuing system, queue types (channel vs. phase). Kendall’s notation, Little’s law,\nsteady state behaviour, Poisson’s Process & queue, Models with examples - M/M/1 and its\nperformance measures; M/M/m and its performance measures; brief description aboutsome\nspecial models. Simulation Methodology: Definition and steps of simulation, random number,\nrandom number generator, Discrete EventSystem Simulation – clock, event list, Application in\nScheduling, Queuing systems and Inventory systems.', 1, '2021-08-10', '0000-00-00'),
(589, 'Operating Systems (BTCSCS-209)', 5, 77, 'File Management:\nConcept of File, Access methods, File types, File operation, Directorystructure, File System\nstructure, Allocation methods (contiguous, linked, indexed),Free-space management (bit vector,\nlinked list, grouping), directory implementation(linear list, hash table), efficiency and\nperformance.Disk Management: Disk structure, Disk scheduling - FCFS, SSTF, SCAN, C SCAN, Diskreliability, Disk formatting, Boot-block, Bad blocks. Case study: UNIX OS file\nsystem, shell, filters, shell programming, programming with the standard I/O, UNIX system\ncalls.', 1, '2021-08-10', '0000-00-00'),
(590, 'Computer Graphics and Multimedia (BTCS-503)', 5, 78, 'Multimedia System:\nAn Introduction, Multimedia hardware, Multimedia System Architecture. Data & File Format\nstandards.i.e RTF, TIFF, MIDI, JPEG, DIB, MPEG,Audio: digital audio, MIDI, processing\nsound, sampling, compression. Video: Avi, 3GP,MOV, MPEG , compression standards,\ncompression through spatial and temporal redundancy. Multimedia Authoring .', 1, '2021-08-10', '0000-00-00'),
(591, 'Software Engineering and Project Management (BTCS-504)', 5, 79, 'Need and Types of Maintenance:\nSoftware Configuration Management (SCM), Software Change Management, Version Control,\nChange control and Reporting, Program Comprehension Techniques, Re-engineering, Reverse\nEngineering, Tool Support. Project Management Concepts, Feasilibility Analysis, Project and\nProcess Planning, Resources Allocations, Software efforts, Schedule, and Cost estimations,\nProject Scheduling and Tracking, Risk Assessment and Mitigation, Software Quality\nAssurance(SQA). Project Metrics.', 1, '2021-08-10', '0000-00-00'),
(592, 'Artificial Intelligence (BTCS-511)', 5, 80, 'Reinforcement Learning:\nPassive reinforcement learning, direct utility estimation, adaptive dynamic programming,\ntemporal difference learning, active reinforcement learning- Q learning.', 1, '2021-08-10', '0000-00-00'),
(593, 'CYBER AND NETWORK SECURITY (BTIT-603)', 5, 81, 'Network Access Control and Cloud Security, Transport- Level Security, Wireless Network\nSecurity, Electronic Mail Security, IP Security.', 1, '2021-08-10', '0000-00-00'),
(594, 'WIRELESS COMMUNICATION NETWORKS (BTIT-511)', 5, 82, 'Introduction to Wi-Fi, WiMAX, Zig-Bee Networks, Software Defined Radio, UWB Radio,\nWireless Adhoc Network and Mobile Portability, Security issues and challenges in a Wireless\nnetwork. Application Layer :WAP Model, Mobile Location based services ,WAP Gateway\n,WAP protocols wireless bearers for WAP , WML ,WMLScripts.', 1, '2021-08-10', '0000-00-00'),
(595, 'MANAGEMENT INFORMATION SYSTEM (BTIT-513)', 5, 83, 'Strategy:\nIntroduction, Information goods-properties-technology lock-in and switching costs-network\nexternalities-positive feedback-tippy markets, information systems and competitive strategy value chain, the Role of CIO-information system’s plan-vendor coordination-technology\nupdates-return on investment on technology.', 1, '2021-08-10', '0000-00-00'),
(596, 'INFORMATION STORAGE AND MANAGEMENT (BTIT-611)', 5, 84, 'Information storage on clouds:\nconcept of cloud, cloud computing, storage on cloud, Cloud benefits, Cloud computing\nevolution. Application & services on cloud, cloud service providers, cloud deployment models,\nEssential characteristics of cloud computing.', 1, '2021-08-10', '0000-00-00'),
(597, 'ENTERPRISE RESOURCE PLANNING (BTIT-712)', 5, 85, 'Post implementation of ERP\n2. ERP Case Studies Post implementation review of ERP Packages in Manufacturing\nServices\n', 1, '2021-08-10', '0000-00-00'),
(598, 'Programming with Python (BTCS-407)', 5, 86, 'Dynamic Programming:\nFibonacci sequence revisited, Dynamic programming and the 0/1 Knapsack algorithm, Dynamic\nprogramming and divide and conquer.\n', 1, '2021-08-10', '0000-00-00'),
(599, 'Scripting Languages (BTCS-607)', 5, 87, 'Introduction of Angular JS, Industrial usage of angular JS.benefits of Angular JS, Creation of\nWeb application project using database, scripting, HTML, & CSS.', 1, '2021-08-10', '0000-00-00'),
(600, 'Big Data Technologies (BTIBMB-601)', 5, 88, 'Data Processing and Management- ZooKeeper, Slider, and Knox The challenges posed by\ndistributed applications and how ZooKeeper is designed to handle them, the role of ZooKeeper\nwithin the Apache Hadoop infrastructure and the realm of Big Data management, the generic\nuse cases and some real-world scenarios for ZooKeeper, the ZooKeeper services that are used to\nmanage distributed systems, use the ZooKeeper CLI to interact with ZooKeeper services', 1, '2021-08-10', '0000-00-00'),
(601, 'Predictive Analytics (BTIBDA-501)', 5, 89, 'Machine Learning Algorithms:\nAbout Machine Learning, From Regression to neural nets, Decision tree classifier, Machine\nlearning Framework.', 1, '2021-08-10', '0000-00-00'),
(602, 'Micro services Architecture and Implementation (BTIBM-601)', 5, 90, 'Case Study:\nThe Journey from Monolith Architecture to Micro services; Refactoring A Monolith application\nInto A Cloud-Native App.', 1, '2021-08-10', '0000-00-00'),
(603, 'Predictive Modelling (BTIBMA-501)', 5, 91, 'Deep Dive into ML Introduction of Machine Learning, Types of learning: Supervised,\nUnsupervised & Reinforcement Learning, Types of Regression like Linear & Logistics, Neural\nNetworks, Decision Tree Classifier, XGB Classifier, Different Frameworks of Machine\nLearning.', 1, '2021-08-10', '0000-00-00'),
(604, 'Cloud Computing (BTCS-701)', 5, 92, 'Case studies- Microsoft Azure, Google App Engine, IBM Smart Cloud and Open source clouds,-\nOpen-Nebula, Sales force and Eucalyptus, Cloud Simulation', 1, '2021-08-10', '0000-00-00'),
(605, 'Computer Architecture and Microprocessor (BTCS-509)', 5, 93, 'Addressing Modes and Instruction set:\nAddressing Modes of 8085 Microprocessor, Instruction Format, Opcode and operand,\nClassification of Instructions: Data transfer, Arithmetic, Logical, Rotate, Branch and machine\nControl instructions. Concept of stack and Instruction related to stack. 8085 interrupts, RST,\nRIM, SIM instructions, Subroutines and conditional call instruction,8085 assembly language\nprogramming.', 1, '2021-08-10', '0000-00-00'),
(606, 'RedHat Open Stack and Ansible (CLDO-507)', 5, 94, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(607, 'Network Security And Cryptography (BTICS-501)', 5, 95, 'Internet Security Protocols:\nUser Authentication Basic Concepts, SSL protocol, Authentication Basics, Password,\nAuthentication Token, Certificate based Authentication, Biometric\nAuthentication.Steganography it’simportance.Basics of mail security, Pretty Good Privacy,\nS/MIME.', 1, '2021-08-10', '0000-00-00'),
(608, 'Ethical Hacking Lab-1 (BTICS-502)', 5, 96, 'Hacking Techniques:\nDial-up, PBX, Voicemail and VPN hacking, Preparing to dial up, War-Dialing, Brute-Force\nScripting PBX hacking, Voice mail hacking, VPN hacking, Network Devices: Discovery\nAutonomous System Lookup, Public Newsgroups, Service Detection, Network Vulnerability,\nDetecting Layer 2 Media.', 1, '2021-08-10', '0000-00-00'),
(609, 'Theory of Computation (BTCS-501)', 5, 97, 'Turing machines (TM):\nBasic model, definition and representation, Instantaneous Description, Language acceptance by\nTM, Variants of Turing Machine, TM as Computer of Integer functions, Universal TM,\nChurch’s Thesis, Recursive and recursively enumerable languages, Halting problem,\nIntroduction to undecidability, undecidable problems about TM, NP hard and NP complete\nproblem, Post correspondence problem (PCP), Modified PCP, Introduction to recursive\nfunction theory.', 1, '2021-08-10', '0000-00-00'),
(610, 'Internet of Things (BTCS-602)', 5, 98, 'IoT Case Studies:\nIoT case studies and mini projects based on Industrial automation, Transportation, Agriculture,\nHealthcare, Home Automation', 1, '2021-08-10', '0000-00-00'),
(611, 'Cloud Computing (BTCS-701)', 5, 99, 'Case studies- Microsoft Azure, Google App Engine, IBM Smart Cloud and Open source clouds,-\nOpen-Nebula, Sales force and Eucalyptus, Cloud Simulation', 1, '2021-08-10', '0000-00-00'),
(612, 'Data Science (BTCS-608)', 5, 100, 'Case Studies of Data Science Application:\nWeather forecasting, Stock market prediction, Object recognition, Real Time Sentiment\nAnalysis.', 1, '2021-08-10', '0000-00-00'),
(613, 'Simulation and Modeling (BTCS-612)', 5, 101, 'SIMULATION TOOLS Simulation Tools –\nModel Input – High level computer system simulation – CPU – Memory, Simulation –\nComparison of systems via simulation – Simulation Programming techniques, Development of\nSimulation models, General Purpose Simulation Package-MATLAB, ARENA, EXTEND, Study\nof SIMULA, DYNAMO', 1, '2021-08-10', '0000-00-00'),
(614, 'Software Testing and Quality Assurance (BTCS-613)', 5, 102, 'ADVANCE SOFTWARE TESTING METHOD (OBJECT ORIENTED TESTING):\nSyntax testing - Finite State testing - Levels of testing - Unit, Integration and System Testing.\nChallenges - Differences from testing non-OO Software - Class testing strategies - State-based\nTesting Software quality Assurance: ISO 9000; CMM and Test Management Issues; Quality\nAssurance personnel Issues.', 1, '2021-08-10', '0000-00-00'),
(615, 'Block Chain (BTCS-618)', 5, 103, 'Hyperledger Fabric- Architecture, Identities and Policies, Membership and Access Control,\nChannels, Transaction Validation, Writing smart contract using Hyperledger Fabric, Writing\nsmart contract using Ethereum, Overview of Ripple and Corda.', 1, '2021-08-10', '0000-00-00'),
(616, 'Robotics (BTCS-617)', 5, 104, 'Robot Actuation Systems:\nActuators: Electric, Hydraulic and Pneumatic; Transmission: Gears, Timing Belts and\nBearings, Parameters for selection of actuators.\nControl Hardware and Interfacing: Embedded systems: Architecture and integration with\nsensors, actuators, components, Programming for Robot Applications.', 1, '2021-08-10', '0000-00-00'),
(617, 'IT WorkshopSciLab/MATLAB (BTIT-608)', 5, 105, 'GRAPHICS:\nPlotting Process, Editing Process, Preparing Graphs, Basic Plotting Functions, Mesh & Surface\nPlot, and Image Reading & Writing, Printing graphics. SIMULINK', 1, '2021-08-10', '0000-00-00'),
(618, 'Minor Project (BTCS-606)', 5, 106, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(619, 'Object Oriented Analysis and Design (BTIT-604)', 5, 107, 'Class design:\nOverview of class design, designing algorithms recursing downward, refactoring, design\noptimization, Adjustment of Inheritance, Rectification of Behavior.', 1, '2021-08-10', '0000-00-00'),
(620, 'Micro services Architecture and Implementation (BTIBM-601)', 5, 108, 'Cloud Application Component Architecture, Benefits of using Kubernetess with IBM\nContainers, About Microservices ,monolithic application, microservice security, api\nmanagement and gateways, the future of microservices, microservices governance', 1, '2021-08-10', '0000-00-00'),
(621, 'Big Data Engineering - Spark & Scala (BTIBMB-602)', 5, 109, 'Watson Studio Setting up a project, Working with collaborators, Managing data assets, Sign up\nfor a Watson Studio account, Creating a new project, Managing a project, Adding\ncollaborators, Loading data Managing the object storage, Overview of Jupyter notebooks,\nCreating notebooks, Coding and running notebooks, Sharing and publishing notebooks,\nCreating a notebook, Using notebooks, Working with external data.', 1, '2021-08-10', '0000-00-00'),
(622, 'Big Data Technologies (Hadoop) (BTIBMC-602)', 5, 110, 'ZooKeeper, Slider, and Knox:\nThe challenges posed by distributed applications and how ZooKeeper is designed to handle\nthem, the role of ZooKeeper within the Apache Hadoop infrastructure and the realm of Big\nData management, the generic use cases and some real-world scenarios for ZooKeeper, the\nZooKeeper services that are used to manage distributed systems, use the ZooKeeper CLI to\ninteract with ZooKeeper services', 1, '2021-08-10', '0000-00-00'),
(623, 'Artificial Intelligence (BTIBMC-601)', 5, 111, 'NATURAL LANGUAGE UNDERSTANDING AND COMPUTER VISION NLP Overview,\nNLP Explained, Virtual Agents Overview, Virtual Agents for the Enterprise, Summary and\nResources, Computer Vision Overview, AI Vision through Deep Learning, Computer Vision for\nthe Enterprise, Experiments. Summary and Resources COMPUTER VISION Define computer\nvision, History of computer vision Tools and Service of completed vision, Use cases of computer\nvision. Describe cognitive system, Summary and Resources.', 1, '2021-08-10', '0000-00-00'),
(624, 'CYBER AND NETWORK SECURITY (BTIT-603)', 5, 112, 'Network Access Control and Cloud Security, Transport- Level Security, Wireless Network\nSecurity, Electronic Mail Security, IP Security.', 1, '2021-08-10', '0000-00-00'),
(625, 'Introduction to container Kubernete and RedHat OpenShift and JBOSS (DOJB-603)', 5, 113, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(626, 'Ethical Hacking Lab-II (BTICS-602)', 5, 114, 'SQL Injection:\nIntroduction, working of SQL injection, SQL injection types and attacks, automation tools for\nSQL injection and Prevention techniques from SQL injection.', 1, '2021-08-10', '0000-00-00'),
(627, 'Concepts of System Security (BTICS-601)', 5, 115, 'Smartphone Security:\nIntroduction, importance and characteristics of Smartphone security, Access control in Android\noperating system, Rooting Android devices, Repackaging attacks, Attacks on apps, Whole-disk\nencryption.', 1, '2021-08-10', '0000-00-00'),
(628, 'Human Values and Professional Ethics (BBAI-501)', 5, 116, 'Globalization and Ethics\n4. Sources of Indian Ethos & its impact on human behavior\n2. Corporate Citizenship and Social Responsibility – Concept (in Business),\n3. Work Ethics and factors affecting work Ethics.', 1, '2021-08-10', '0000-00-00'),
(629, 'Compiler Design ( BTCS-601)', 5, 117, 'Code Generation:\nIssues in the design of code generator, The target machine, Runtime Storage management, Basic\nBlocks and Flow Graphs, Next-use Information, A simple Code generator, Peephole\nOptimization.', 1, '2021-08-10', '0000-00-00'),
(630, 'OBJECT ORIENTED ANALYSIS AND DESIGN ( BTIT-604)', 5, 118, 'Class design:\nOverview of class design, designing algorithms recursing downward, refactoring, design\noptimization, Adjustment of Inheritance, Rectification of Behavior.', 1, '2021-08-10', '0000-00-00'),
(631, 'BIG DATA AND HADOOP (BTCS-702)', 5, 119, 'Monitoring The HadoopCluster , Monitoring Hadoop Cluster, Monitoring Hadoop Cluster\nwith Nagios, Monitoring Hadoop Cluster, Real Time Example in Hadoop , Apache Log viewer\nAnalysis , Market Basket AlgorithmsBig Data Analysis in Practice , Case Study , Preparation of\nCase Study Report and Presentation , Case Study Presentation', 1, '2021-08-10', '0000-00-00'),
(632, 'Next Generation Telecommunication Networks (BTCC-703)', 5, 120, 'NGN Service\nAspectsServices on an NGN, Service compatibility with PSTN and IN, Use of APIs and service\nprovider interfaces, Brief review of the principles of mobile networks, Relationship of mobile\ndevelopments to NGN', 1, '2021-08-10', '0000-00-00'),
(633, 'Soft computing (BTCS-711)', 5, 121, 'Neuro-Fuzzy and Soft Computing, Adaptive Neuro-Fuzzy Inference System Architecture,\nHybrid Learning Algorithm, Learning Methods thatCross-fertilize ANFIS and RBFN. Coactive\nNeuro Fuzzy Modeling, Framework Neuron Functions for Adaptive Networks, Neuro Fuzzy\nSpectrum. Hybridization of other techniques.', 1, '2021-08-10', '0000-00-00'),
(634, 'Quantum Computing (BTCS-715)', 5, 122, 'OSS Toolkits for implementing Quantum program:\nIBM quantum experience, Microsoft Q, Rigetti PyQuil (QPU/QVM)', 1, '2021-08-10', '0000-00-00'),
(635, 'Virtual Reality (BTCS-716)', 5, 123, 'VR Applications:\nIntroduction, Engineering, Entertainment, Science, Training. The Future: Virtual\nenvironment, modes of interaction', 1, '2021-08-10', '0000-00-00'),
(636, 'Project (BTCS-706)', 5, 124, 'Not Specified', 1, '2021-08-10', '0000-00-00'),
(637, 'Computer Graphics and Multimedia (BTCS-503)', 5, 125, 'Multimedia System:\nAn Introduction, Multimedia hardware, Multimedia System Architecture. Data & File Format\nstandards.i.e RTF, TIFF, MIDI, JPEG, DIB, MPEG,Audio: digital audio, MIDI, processing\nsound, sampling, compression. Video: Avi, 3GP,MOV, MPEG , compression standards,\ncompression through spatial and temporal redundancy. Multimedia Authoring .', 1, '2021-08-10', '0000-00-00'),
(638, 'Mobile and Cloud Security (BTICS-701)', 5, 126, 'Computing Paradigms:\nVirtualization Vulnerabilities, Hypervisor Security-Related Issues, Side Channel Attacks, Data\nSegregation, ubiquitous, grid, cloud, pervasive, green, ad hoc (mobile, vehicular, flying)\nnetworks.', 1, '2021-08-10', '0000-00-00'),
(639, 'Cyber Investigation and Digital Forensic (BTICS-702)', 5, 127, 'Mobile Device Forensics:\nEvidence in Cell Phone, PDA, Blackberry, iPhone, iPod, and MP3. Evidence in CD, DVD, Tape\nDrive, USB, Flash Memory, Digital Camera, Court Testimony, Testifying in Court, Expert\nWitness Testimony, Evidence Admissibility', 1, '2021-08-10', '0000-00-00'),
(640, 'DISTRIBUTED SYSTEM (BTIT-713)', 5, 128, 'PROCESS & RESOURCE MANAGEMENT\nProcess Management: Process Migration: Features, Mechanism, Threads: Models, Issues,\nImplementation. Resource Management: Introduction- Features of Scheduling Algorithms,\nTask Assignment Approach – Load Balancing Approach – Load Sharing Approach.', 1, '2021-08-10', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` int(255) NOT NULL,
  `units` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `units`) VALUES
(1, 'UNIT-I'),
(2, 'UNIT-II'),
(3, 'UNIT-III'),
(4, 'UNIT-IV'),
(5, 'UNIT-V');

-- --------------------------------------------------------

--
-- Table structure for table `yearorsem`
--

CREATE TABLE `yearorsem` (
  `id` int(255) NOT NULL,
  `evs` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `yearorsem`
--

INSERT INTO `yearorsem` (`id`, `evs`) VALUES
(1, 'year wise'),
(2, 'semester wise'),
(3, '3 Year course'),
(4, '2 Year course');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_data`
--
ALTER TABLE `admin_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment_reply`
--
ALTER TABLE `comment_reply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_data`
--
ALTER TABLE `contact_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `papers`
--
ALTER TABLE `papers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programes`
--
ALTER TABLE `programes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semsandyears`
--
ALTER TABLE `semsandyears`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects_details`
--
ALTER TABLE `subjects_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `syllabus`
--
ALTER TABLE `syllabus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `yearorsem`
--
ALTER TABLE `yearorsem`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_data`
--
ALTER TABLE `admin_data`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `comment_reply`
--
ALTER TABLE `comment_reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `contact_data`
--
ALTER TABLE `contact_data`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `papers`
--
ALTER TABLE `papers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `programes`
--
ALTER TABLE `programes`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `semsandyears`
--
ALTER TABLE `semsandyears`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=166;

--
-- AUTO_INCREMENT for table `subjects_details`
--
ALTER TABLE `subjects_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `syllabus`
--
ALTER TABLE `syllabus`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=643;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `yearorsem`
--
ALTER TABLE `yearorsem`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
